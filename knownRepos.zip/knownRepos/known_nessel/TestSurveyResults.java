package cs350Project;

import java.io.Serializable;

public class TestSurveyResults extends SurveyResults implements Serializable { //Not finished, will at some point aggregate test results

	TestSurveyResults(){
		super();
	}
}
