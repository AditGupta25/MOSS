import java.io.Serializable;

public class TrueFalse extends MultipleChoice{

	static String[] TFchoices = {"True", "False"};

	public TrueFalse(String prompt) {
		super(prompt, TFchoices);
	}
	
}
