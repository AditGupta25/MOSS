import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FilenameFilter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class IOFile{
	
	private Survey curSurvey = null;
	private int numOfvalidFiles; 
	private String[] SurveyFiles = null;
	
	File file = new File(".");
	
	/*Display current working directory with only Survey/Test files(.txt)*/
	//https://stackoverflow.com/questions/5751335/using-file-listfiles-with-filenameextensionfilter
	public Boolean displayValidFiles() {
		this.numOfvalidFiles = 0;//reset for each display
		this.SurveyFiles = file.list(new FilenameFilter() {
			
			public boolean accept(File dir, String fname) {
				if(fname.endsWith(".txt")) {
					return true;
				}else { return false;}
				
			}
		});
		
		if(this.SurveyFiles.length > 0)
			return true;
		return false;
	}
	
	//Displays Current Survey, error checks for no saved Survey
	public Boolean display() throws Exception {
		
		if(this.curSurvey == null) {
			return false;
		}
		
		displaySurvey();
		System.out.println();
		return true;
	}
	
	
	public void setCurrent(Survey sur) {
		curSurvey = sur;
	}
	
	//Loops through the Survey and displays questions/choices
	public void displaySurvey() {
		this.curSurvey.display();

		/*Possible Facade? User asks for display question, IOfile checks
		 * instance and displays each different question accordingly.
		 */
		for(int i = 0; i<this.curSurvey.questions.length ; i++) {
			Questions curQuestion = this.curSurvey.questions[i];
			
			/*Display prompt with formatted numbering*/
			System.out.format("%d) %s%n",(i+1),curQuestion.display());
			
			/*Check the instance of the question*/
			//Essay is the only variant, other questions have choices
			if(curQuestion instanceof MultipleChoice) {
				((MultipleChoice) curQuestion).displayChoices();
			}if(curQuestion instanceof Rank) {
				((Rank)curQuestion).displayChoices();
			}
			
			System.out.println("\n");
			//Test special case
			if(this.curSurvey instanceof Test) {
				System.out.println("The correct answer is: ");
				((Test)this.curSurvey).displayAnswer(i);
				System.out.println("\n");
			}
		}
	}
	
	
	public Boolean load() throws Exception{
		
		if(this.displayValidFiles() == false) {
			return false;
		}
		
		int chosenfile = Helper.menu1_interface(SurveyFiles) - 1;//(-1) options chosen are different from array access
		FileInputStream fileIn = new FileInputStream(this.SurveyFiles[chosenfile]);
		ObjectInputStream objIn = new ObjectInputStream(fileIn);
		this.curSurvey = (Survey)objIn.readObject();

		return true;		
	}
	
	public void modify(String Sur) {
		
	}
	
	public Boolean save() throws Exception{
		if(this.curSurvey == null) {
			return false;
		}
			
		File f = new File(this.curSurvey.surveyTitle + ".txt");

		FileOutputStream fileOut = new FileOutputStream(f);
		ObjectOutputStream objOut = new ObjectOutputStream(fileOut);
		objOut.writeObject(this.curSurvey);
		return true;
	}
}

