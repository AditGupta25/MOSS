import java.io.Serializable;

public class Questions implements Serializable{
	protected String prompt;
	
	public String display() {
		return prompt;
	}
	
	public void edit() {
		//Changes the prompt
	}
	
}
