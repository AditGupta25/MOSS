import java.util.Scanner;
public class Main_Menu {

	static Scanner menu2 = new Scanner(System.in);
	static IOFile iofile = new IOFile();
	
	static final String[] MENU1  = {"Survey", "Test"};
	static String[] YesNo = {"Y","N"};

	public static void main(String[] args) throws Exception {
		
		while(true) {//Program resets in menu1
			//Determine Survey or Test
			/* menu1_interface error checks and returns an integer */
			String menuType = (Helper.menu1_interface(MENU1) == 1) ? "Survey" : "Test";
			
			/*menu2_interface has same structure as menu1, but with different parameter checking */
			while(true) {//Program resets in menu2 -- error handling
				int test = menu2_interface(menuType);
				switch(test) {/* The case statement either involves the Survey/Test class(1,2), Iofile(4,5), or quit(6) */
					case(1):
					//Determine the number questions before constructing survey, survey then creates the questions
						while(true) {
							String SurName = Helper.getString("What is the name of the " + menuType + "?");
							int numberOfchoices = Helper.getInt("How many questions would you like to add?");
							System.out.format("Are you sure you want to add %d questions?%n", numberOfchoices);
							int confirm = Helper.menu1_interface(YesNo);//reuse menu1_interface for error checking
							if(confirm == 2) {
								continue;
							}else {
								//Dynamically decides if it is a Survey or Test
								Survey SurOrTest = (menuType == "Survey") ? new Survey(SurName, numberOfchoices): new Test(SurName, numberOfchoices);
								SurOrTest.create();						
								iofile.setCurrent(SurOrTest);
								iofile.save();//Saves newly created survey
								break;
							}
						}
					break;
					case(2)://Display a Survey
						//Return a Boolean to determine whether display worked, else repeat current menu2 options
						Boolean availableSurvey = iofile.display();
						if(availableSurvey) {
							break;
						}else {
							System.out.println("No loaded or recently created Survey/Test!");
							continue;
						}
					case(3)://Load a Survey
						Boolean availableLoad = iofile.load();
						if(availableLoad) {
							break;
						}else {
							System.out.println("No saved Survey/Test, please create one first.");
							System.out.println();
							continue;
						}
					case(4)://Save a Survey
						Boolean currentSurvey = iofile.save();
						if(currentSurvey) {
							break;
						}else {
							System.out.println("No loaded or recently created Survey/Test!");
							System.out.println();
							continue;
						}
					case(5)://Quit
						System.exit(0);	
				}
				break;
			}
		}			
	}
	
	
	public static int menu2_interface(String menuType) {
		int numberEntered = 0;

		while((numberEntered < 1) || (numberEntered > 5)) {
			System.out.format("1) Create a new %s%n", menuType);
			System.out.format("2) Display current file%n");
			System.out.format("3) Load a Survey/Test%n", menuType);
			System.out.format("4) Save current file%n");
			System.out.format("5) Quit%n");
			
			if(!menu2.hasNextInt()) {
				menu2.next();
				System.out.println("Enter a number between 1 and 5...");
			}else {
				numberEntered = menu2.nextInt();
			}
		}

		return numberEntered;
	}
}
