public class MultipleChoice extends Questions{
	private final int limitOfChoices = 26;
	
	private int numOfChoices;
	protected String[] choices;
	
	public MultipleChoice(String prompt, String[] choices) {
		this.prompt = prompt;
		this.choices = choices;
		this.numOfChoices = choices.length;
		
	}
	
	public MultipleChoice(String prompt) {
		this.prompt = prompt;
		numOfChoices = Helper.getInt("Enter the number of choices for "
				+ "your multiple choice question.(limit " + limitOfChoices + ")");
		//Error checking 
		while((this.numOfChoices > this.limitOfChoices) || (this.numOfChoices < 1)) {
			System.out.format("A number between 1 and %d", this.limitOfChoices);
			this.numOfChoices = Helper.getInt(null);
		}
		
		choices = new String[numOfChoices];
		for(int i = 0; i < numOfChoices; i++) {
			String str = String.format("Enter choice %s) ",(char)(65+i));
			choices[i] = Helper.getString(str);
			System.out.println();
		}
	}
		
	public void displayChoices() {
		int c = 65;//Typecast to present letters
		for(int i = 0; i < numOfChoices; i++) {
			System.out.format("%s) %s ",(char)c, choices[i]);
			c++;
		}
	}
	
	public int getNumberOfChoices() {
		return this.numOfChoices;
	}
	
}