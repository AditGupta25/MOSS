import java.io.Serializable;

public class Response_CA implements Serializable{
	//Array of answers for multiple answers
	private String[] answer;
	private int maxRes;
	
	
	public Response_CA(){
		
	}
	
	public Response_CA(int num){
		this.maxRes = num;
		answer = new String[this.maxRes];
	}
	
	public void display() {
		for(int i = 0; i < this.maxRes; i++) {
			System.out.format("%d) %s ",(i+1), this.answer[i]);
		}
	}
	
	public void add(int idx, String ans) {
		this.answer[idx] = ans;
	}
	
	public String[] getAnswers() {
		return this.answer;
	}
	
	//TODO: Edit/Comparing Answers
	public void edit() {
		
	}
	
	public Boolean compareRes(String Res) {
		return true;
	}

}
