import java.util.Scanner;

public class Helper {
	
	/*This class is used for general Error checking and userInput taking */
	
	static Scanner menu = new Scanner(System.in);

	static public int getInt(String request) {
		if(request != null) {
			System.out.println(request);
		}
		while(true) {
			if(!menu.hasNextInt()) {
				menu.next();
				System.out.println("Enter a number...");
			}else {
				int number = menu.nextInt();
				return number;
			}
		}
	}
	
	
	static public int menu1_interface(String[] options) {
		int numberEntered = -1;
		while((numberEntered < 1) || (numberEntered > options.length)) {
			for(int i = 0; i<options.length; i++) {
				System.out.format("%d) %s%n",i+1, options[i]);
			}
			
			if(!menu.hasNextInt()) {
				menu.next();
				System.out.format("Either a number between 1 and %d...%n", options.length);
			}else {
				numberEntered = menu.nextInt();
			}
		}
		return numberEntered;
	}
	
	static public String getString(String str) {
		System.out.println(str);
		String requested = "";
		
		while(requested.equals("")) {
			requested = menu.nextLine();
		}
		
		return requested;
	}
	
	public static char alphaBound(int numOfchoices) {
		char upperBoundLetter = (char)(65+numOfchoices-1);
		char userIn = 0;
		String temp = null;
		
		while((userIn < 'A') || (userIn > upperBoundLetter)) {
			if(menu.hasNextLine()) {
				temp = menu.nextLine();
				if((temp.length() == 1) && (temp.charAt(0) >= 'A') && (temp.charAt(0) <= upperBoundLetter)) {
					userIn = temp.charAt(0);
				}else {
					System.out.format("Enter a CAPITAL letter between 'A' and '%s'%n",upperBoundLetter);
					continue;
				}
			}
		}
		return userIn;
	}
	
	public static int menu3_interface() {
		int numberEntered = 0;

		while((numberEntered < 1) || (numberEntered > 6)) {
			System.out.println("1) Add a new T/F question");
			System.out.println("2) Add a new multiple choice question");
			System.out.println("3) Add a new short answer question");
			System.out.println("4) Add a new essay question");
			System.out.println("5) Add a new ranking question");
			System.out.println("6) Add a new matching question");
			
			if(!menu.hasNextInt()) {
				menu.next();
				System.out.println("Enter a number between 1 and 6...");
			}else {
				numberEntered = menu.nextInt();
			}
		}
		return numberEntered;
	}
}
