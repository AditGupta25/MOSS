public class Essay extends Questions{
	public Essay() {
		
	}
	
	
	public Essay(String prompt) {
		this.prompt = prompt;
	}
}
