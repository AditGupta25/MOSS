public class Results {
	private String answers;
	
	public void display() {
		
	}
}
