public class Test extends Survey {
	private Response_CA[] correctAns;
	static String[] YesNo = {"Y","N"};
	
	public Test(String name, int num) {
		super(name, num);
		this.correctAns = new Response_CA[this.numOfQuestions];
	}
	
	public void displayAnswer(int idx) {
		this.correctAns[idx].display();
	}
	
	public void create() {
		for(int i = 0; i < numOfQuestions; i++) {
			int chosenQuestion = Helper.menu3_interface();
			String prompt;
			int confirm;
			int numberOfchoices = 0;
			char chosenChoice = 0;
			
			//Similar, but extra error checking for Correct Answer setup
			switch(chosenQuestion) {
			case(1):
				prompt = Helper.getString("Enter the prompt for your True/False question:");
				questions[i] = new TrueFalse(prompt);
				numberOfchoices = ((TrueFalse)questions[i]).getNumberOfChoices();
				this.correctAns[i] = new Response_CA(1);

				System.out.println("What is the answer? [A:True | B:False]");
				chosenChoice = Helper.alphaBound(numberOfchoices);
				this.correctAns[i].add(0, (String)(chosenChoice+" "));
				
				break;
			case(2)://Multiple Answers
				prompt = Helper.getString("Enter the prompt for your MultipleChoice question:");
				questions[i] = new MultipleChoice(prompt);
				numberOfchoices = ((MultipleChoice)questions[i]).getNumberOfChoices();
				int UserIn = 0;
				
				String str = String.format("How many correct answers are there? Enter a number between 1 and %d%n",numberOfchoices);
				while((UserIn < 1) || (UserIn > numberOfchoices)) {
					UserIn = Helper.getInt(str);
				}
				
				this.correctAns[i] = new Response_CA(UserIn);
				
				//chosenChoice = Helper.alphaBound(numberOfchoices);
				//this.correctAns[i].add(0, (String)(chosenChoice+" "));					
				System.out.println("What is the answer(s)?");
				for(int j = 0; j<UserIn; j++) {
					chosenChoice = Helper.alphaBound(numberOfchoices);
					this.correctAns[i].add(j, (String)(chosenChoice+" "));
				}
				break;
				
			case(3):
				prompt = Helper.getString("Enter the prompt for your Short answer question:");
				questions[i] = new ShortAnswer(prompt);
				//The user have multiple correct answer for essay/short answer
				while(true) {
					numberOfchoices = Helper.getInt("How many correct answers are there?");
					System.out.format("Are you sure you want to add %d answers?%n", numberOfchoices);
					confirm = Helper.menu1_interface(YesNo);//reuse menu1_interface for error checking
					if(confirm == 2) {
						continue;
					}else {
						this.correctAns[i] = new Response_CA(numberOfchoices);
						break;
					}
				}
					
				for(int j = 0; j<numberOfchoices; j++) {
					String res = Helper.getString("Enter an answer.");
						this.correctAns[i].add(j, res);
				}
				
				break;
			case(4)://Multiple Answers
				prompt = Helper.getString("Enter the prompt for your Essay question:");
				questions[i] = new Essay(prompt);
				
				//The user have multiple correct answer for essay/short answer
				while(true) {
					numberOfchoices = Helper.getInt("How many correct answers are there?");
					System.out.format("Are you sure you want to add %d answers?%n", numberOfchoices);
					confirm = Helper.menu1_interface(YesNo);//reuse menu1_interface for error checking
					if(confirm == 2) {
						continue;
					}else {
						this.correctAns[i] = new Response_CA(numberOfchoices);
						break;
					}
				}
					
				for(int j = 0; j<numberOfchoices; j++) {
					String res = Helper.getString("Enter an answer.");
						this.correctAns[i].add(j, res);
				}
				
				break;
			case(5):
				prompt = Helper.getString("Enter the prompt for your Ranking question:");
				questions[i] = new Rank(prompt);
				numberOfchoices = ((Rank)questions[i]).getNumberOfChoices();
				this.correctAns[i] = new Response_CA(numberOfchoices);
				char[] temp = new char[numberOfchoices];
				
				for(int j = 0; j < numberOfchoices; j++) {
					System.out.format("Answer: Input the %d ranking letter.%n", j+1);
					while(true) {
						chosenChoice = Helper.alphaBound(numberOfchoices);
						for(int k = 0; k < numberOfchoices; k++) {
							if(temp[k] == chosenChoice) {
								System.out.println("Choice already used!");
								continue;
							}
						}
						temp[j] = chosenChoice;
						this.correctAns[i].add(j, (String)(chosenChoice+" "));
						break;
					}
				}
				
				break;
			case(6):
				prompt = Helper.getString("Enter the prompt for your Matching question:");
				questions[i] = new Matching(prompt);
				numberOfchoices = ((Matching)questions[i]).getNumberOfChoices();
				this.correctAns[i] = new Response_CA(numberOfchoices);
				int[] temp1 = new int[numberOfchoices];
				int numChoice = 0;
				
				for(int j = 0; j < numberOfchoices; j++) {
					System.out.format("Answer: Match a number with %s.%n", (char)(65+j));
					while(true) {
						while((numChoice < 1) || (numChoice > numberOfchoices)) {
							String str1 = String.format("Number between 1 and %d.%n", numberOfchoices);
							numChoice = Helper.getInt(str1);
						}
						
						for(int k = 0; k < numberOfchoices; k++) {
							if(temp1[k] == numChoice) {
								System.out.println("Choice already used!");
								continue;
							}
						}
						temp1[j] = numChoice;
						this.correctAns[i].add(j, (String)(numChoice+" "));
						numChoice = 0;
						break;
					}
				}
				break;
			}
		}
	}
	
	//Edit Correct Answers
	public void edit() {
		
	}
	
	
}
