import java.io.Serializable;
import java.util.Scanner;

public class Survey implements Serializable{
	public String surveyTitle;
	protected int numOfQuestions;
	protected Questions[] questions;
	protected Response_CA[] res;
	
	public Survey() {
		
	}
	
	public Survey(String name, int number) {
		this.surveyTitle = name;
		this.numOfQuestions = number;
		questions = new Questions[numOfQuestions];
		//TODO: res = new Response_CA[this.numOfChoices];
	}
	
	public String display() {
		return this.surveyTitle;
	}
	
	public void edit(String newName) {
		this.surveyTitle = newName;
	}
	
	public void create() {
		for(int i = 0; i < numOfQuestions; i++) {
			int chosenQuestion = Helper.menu3_interface();
			String prompt;

			switch(chosenQuestion) {
			case(1):
				prompt = Helper.getString("Enter the prompt for your True/False question:");
				questions[i] = new TrueFalse(prompt);
				break;
			case(2):
				prompt = Helper.getString("Enter the prompt for your MultipleChoice question:");
				questions[i] = new MultipleChoice(prompt);
				break;
			case(3):
				prompt = Helper.getString("Enter the prompt for your Short answer question:");
				questions[i] = new ShortAnswer(prompt);
				break;
			case(4):
				prompt = Helper.getString("Enter the prompt for your Essay question:");
				questions[i] = new Essay(prompt);
				break;
			case(5):
				prompt = Helper.getString("Enter the prompt for your Ranking question:");
				questions[i] = new Rank(prompt);
				break;
			case(6):
				prompt = Helper.getString("Enter the prompt for your Matching question:");
				questions[i] = new Matching(prompt);
				break;
			}
		}
	}
	
	

}
