public class ShortAnswer extends Essay {
	private final int limitOfCharacters = 140;
	
	public ShortAnswer() {
		
	}
	
	public ShortAnswer(String prompt) {
		while(prompt.length() > this.limitOfCharacters) {
			prompt = Helper.getString("Short Answer question limited to 140 characters");
		}
		this.prompt = prompt;
	}
}
