public class Rank extends Questions{
	protected final int limitOfOptions = 26;
	protected int numOfChoices;
	protected String[] leftColumnOptions;
	
	public Rank() {
		
	}
	
	public Rank(String prompt) {
		this.prompt = prompt;

		numOfChoices = Helper.getInt("Enter the number of choices for "
				+ "your ranking question.(limit " + limitOfOptions + ")");
		//Error checking 
		while((this.numOfChoices > this.limitOfOptions) || (this.numOfChoices < 1)) {
			System.out.format("A number between 1 and %d", this.limitOfOptions);
			this.numOfChoices = Helper.getInt(null);
		}
		
		this.leftColumnOptions = new String[this.numOfChoices];
		this.setLeftOptions();
	}
	
	protected void setLeftOptions(){
		int c = 65;//Typecast to present letters
		
		for(int i = 0; i < this.numOfChoices ; i++) {
			String str = String.format("Enter option for %s)",(char)c);
			this.leftColumnOptions[i] = Helper.getString(str);
			c++;
		}
		
	}
	
	
	public void displayChoices() {
		int c = 65;//Typecast to present letters
		for(int i = 0; i < numOfChoices; i++) {
			System.out.format("%s) %s ",
					(char)c, this.leftColumnOptions[i]);
			c++;
		}
	}
	
	//Used later for editing purposes
	public void display_A_LeftOption(int idx) {
		System.out.println(this.leftColumnOptions[idx]);
	}
	
	public int getNumberOfChoices() {
		return this.numOfChoices;
	}
	
}
