public class Matching extends Rank{
	private String [] rightColumnOptions;
	
	public Matching() {
		
	}
	
	public Matching(String prompt) {
		super(prompt);
		
		this.rightColumnOptions = new String[this.numOfChoices];
		setRightOptions();
		
	}
	
	private void setRightOptions(){
		for(int i = 0; i < this.numOfChoices ; i++) {
			String str = String.format("Enter option for %s)",(i+1));
			this.rightColumnOptions[i] = Helper.getString(str);
		}		
	}
	
	public void displayChoices() {
		int c = 65;//Typecast to present letters
		for(int i = 0; i < numOfChoices; i++) {
			System.out.format("%s) %-20s%d) %s%n",
					(char)c, this.leftColumnOptions[i], 
					(i+1), this.rightColumnOptions[i]);
			c++;
		}
	}
}
