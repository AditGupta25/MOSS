import java.io.Serializable;

/**
 * Created by Kirkland on 10/21/17.
 */
public abstract class Input<T> implements Serializable{

    public abstract T getInput();


}
