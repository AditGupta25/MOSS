/**
 * Created by Kirkland on 11/8/17.
 */
public class SetSameAnswerTwiceException extends Exception {

    public SetSameAnswerTwiceException() {

    }
}
