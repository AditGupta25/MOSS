package menuPackage;

import java.util.Vector;

import ioPackage.Output;
import surveyTestPackage.Survey;
import surveyTestPackage.Test;

public class LoadSurveyMenu extends Menu {
	boolean isTest;
	String type;
	
	public LoadSurveyMenu(String outputType, boolean isTest) {
		super(outputType);
		// Type denotes whether a survey is a test
		this.isTest = isTest;
		if(isTest) {
			type = "Test";
		} else {
			type = "Survey";
		}
		// Creating menu choices
		MenuChoice display = new MenuChoice("Display " + type, 0);
		MenuChoice modify = new MenuChoice("Modify " + type, 1);
		MenuChoice fillOut = new MenuChoice("Fill Out " + type, 2);
		MenuChoice tabulate = new MenuChoice("Tabulate " + type + " Results", 3);
		MenuChoice back = new MenuChoice("Back", 4);
		MenuChoice quit = new MenuChoice("Quit", 5);
		// Adding choices to list
		super.choices = new Vector<MenuChoice>();
		super.choices.add(display);
		super.choices.add(modify);
		super.choices.add(fillOut);
		super.choices.add(tabulate);
		super.choices.add(back);
		super.choices.add(quit);
	}
	
	/**
	 * Allows the user to select a MenuChoice
	 */
	public Menu select(int i) {
		switch(i) {
			case 1:
				// Go to DisplayMenu
				DisplayMenu display = new DisplayMenu(outputType);
				display.setSurvey(survey);
				return display;
			case 2:	
				// Go to ModifyQuestionMenu
				ModifySurveyMenu modifySurvey = new ModifySurveyMenu(outputType);
				modifySurvey.setSurvey(survey);
				return modifySurvey;
			case 3:
				// Go to FillOutSurveyMenu
				FillOutSurveyMenu fillOut = new FillOutSurveyMenu(outputType);
				fillOut.setSurvey(survey);
				return fillOut;
			case 4:
				// Go to TabulateSurveyMenu
				TabulateSurveyMenu tabulate = new TabulateSurveyMenu(outputType);
				tabulate.setSurvey(survey);
				return tabulate;
			case 5:
				// Go to back menu
				BackMenu back = new BackMenu(3, outputType);
				back.setSurvey(survey);
				return back;
			case 6:
				// Go to quit menu
				QuitMenu quit = new QuitMenu(outputType);
				return quit;
		}
		return null;
	}


}
