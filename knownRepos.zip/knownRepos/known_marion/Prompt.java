package questionPackage;

import java.io.Serializable;

import ioPackage.Output;

public abstract class Prompt implements Serializable {
	/**
	 * Creates a new Prompt for a question
	 */
	Object prompt;
	public Prompt() {
		
	}
	
	/**
	 * Return the prompt
	 * @return Object
	 */
	public Object getPrompt() {
		return prompt;
	}
	
	public void display(String outputType) {
		
	}
}
