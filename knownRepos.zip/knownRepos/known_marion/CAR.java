package questionPackage;
import java.io.Serializable;

import ioPackage.Output;
// CAR - Combined Answer Response
public abstract class CAR implements Serializable, Comparable<CAR> {
	Object response;
	/**
	 * Creates a new CAR (Correct Answer Response)
	 */
	public CAR() {
		
	}
	
	/**
	 * Allows two CARs to be compared
	 * Overwritten in subclasses
	 */
	public int compareTo(CAR response) {
		return 0;
	}
	
	/**
	 * Uses compareTo method to return a boolean if two CARs are equal
	 * @param response
	 * @return Boolean
	 */
	public boolean equals(CAR response) {
		if(this.compareTo(response) == 0) {
			return false;
		} else {
			return true;
		}
	}
	
	public Object getResponse() {
		return response;
	}
	
	/**
	 * Displays CAR response
	 * @param o
	 */
	public void display(String outputType) {
		
	}
}
