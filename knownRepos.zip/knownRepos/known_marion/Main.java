package surveyTestPackage;
import java.util.Arrays;
import java.util.Vector;

import ioPackage.AudioOutput;
import ioPackage.NumberToWord;
import ioPackage.Output;
import ioPackage.TerminalOutput;
import menuPackage.MenuManager;
//----------------For testing purposes---------------------
import questionPackage.CAR;
import questionPackage.Essay;
import questionPackage.Matching;
import questionPackage.MultipleChoice;
import questionPackage.Question;
import questionPackage.Ranking;
import questionPackage.ShortAnswer;
import questionPackage.StringCAR;
import questionPackage.StringPrompt;
import questionPackage.TrueFalse;

public class Main {
	public static void main(String [] args) {
		String outputType = "audio";
		
		SurveyManager surveyManager = new SurveyManager(outputType);
		MenuManager menuManager = new MenuManager(outputType);
		

		// FOR TESTING ONLY
		//createSurveyAndTest("Alex", "SampleTerminal", "terminal", surveyManager);
		//createSurveyAndTest("Alex", "SampleAudio", "audio", surveyManager);
		//*****************
		
		menuManager.start();
		
	}
	
	
	/**
	 * Method to create sample survey and test
	 * FOR TESTING PURPOSES ONLY
	 * NOT BEING USED IN ASSIGNMENT
	 * @param author
	 * @param title
	 * @param outputType
	 * @param surveyManager
	 */
	public static void createSurveyAndTest(String author, String title, String outputType, SurveyManager surveyManager) {
		// For testing purposes
		StringCAR a = new StringCAR("a");
		StringCAR b = new StringCAR("b");
		StringCAR c = new StringCAR("c");
		StringCAR d = new StringCAR("d");
		
		StringPrompt p1 = new StringPrompt("True or False?");
		StringPrompt p2 = new StringPrompt("Multiple Choice");
		StringPrompt p3 = new StringPrompt("Essay");
		StringPrompt p4 = new StringPrompt("Short Answer");
		StringPrompt p5 = new StringPrompt("Ranking");
		StringPrompt p6 = new StringPrompt("Matching");
		
		Vector<Vector<CAR>> correctAnswers = new Vector<Vector<CAR>>();
		
		// TrueFalse
		TrueFalse q1 = new TrueFalse(p1, outputType);
		Vector<CAR> q1Ans = new Vector<CAR>();
		q1Ans.add(q1.getResponse(0));	// Set correct response to True
		correctAnswers.add(q1Ans);
		
		// MultipleChoice
		CAR[] arr1 = {a, b, c, d};
		Vector<CAR> multChoiceRL = new Vector<CAR>(Arrays.asList(arr1));
		MultipleChoice q2 = new MultipleChoice(p2, multChoiceRL, outputType);
		q2.setMaxNumUserResponses(2);
		Vector<CAR> q2Ans = new Vector<CAR>();
		q2Ans.add(a);
		q2Ans.add(b);
		correctAnswers.add(q2Ans);
		
		// Essay
		Essay q3 = new Essay(p3, outputType);
		Vector<CAR> q3Ans = new Vector<CAR>();
		correctAnswers.add(q3Ans);
		
		// ShortAnswer
		ShortAnswer q4 = new ShortAnswer(p4, outputType);
		q4.setCharacterLimit(100);
		q4.setNumResponses(2);
		q4.setMaxNumUserResponses(2);
		StringCAR shortAns1 = new StringCAR("short answer 1");
		StringCAR shortAns2 = new StringCAR("short answer 2");
		Vector<CAR> q4Ans = new Vector<CAR>();
		q4Ans.add(shortAns1);
		q4Ans.add(shortAns2);
		correctAnswers.add(q4Ans);
		
		// Ranking
		Vector<CAR> rankingRL = new Vector<CAR>(Arrays.asList(arr1));
		Ranking q5 = new Ranking(p5, rankingRL, outputType);
		q5.setMaxNumUserResponses(rankingRL.size());
		Vector<CAR> q5Ans = new Vector<CAR>();
		q5Ans.add(a);
		q5Ans.add(b);
		q5Ans.add(c);
		q5Ans.add(d);
		correctAnswers.add(q5Ans);
		
		// Matching
		Vector<CAR> matchingRL1 = new Vector<CAR>(Arrays.asList(arr1));
		Vector<CAR> matchingRL2 = new Vector<CAR>(Arrays.asList(arr1));
		Matching q6 = new Matching(p6, matchingRL1, matchingRL2, outputType);
		q6.setMaxNumUserResponses(matchingRL1.size());
		StringCAR matchAns1 = new StringCAR("a a");
		StringCAR matchAns2 = new StringCAR("b b");
		StringCAR matchAns3 = new StringCAR("c c");
		StringCAR matchAns4 = new StringCAR("d d");
		Vector<CAR> q6Ans = new Vector<CAR>();
		q6Ans.add(matchAns1);
		q6Ans.add(matchAns2);
		q6Ans.add(matchAns3);
		q6Ans.add(matchAns4);
		correctAnswers.add(q6Ans);
		
		Question[] qst = {q1, q2, q3, q4, q5, q6};
		Vector<Question> questions = new Vector<Question>(Arrays.asList(qst));
		
		Test sampleTest = new Test(author, title + "Test", questions, correctAnswers, outputType);
		surveyManager.save(sampleTest);
		
		Survey sampleSurvey = new Survey("Alex", title + "Survey", questions, outputType);
		surveyManager.save(sampleSurvey);
	}
}
