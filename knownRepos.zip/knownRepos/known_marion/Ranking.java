package questionPackage;

import java.io.Serializable;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;

public class Ranking extends Matching implements Serializable{
	/**
	 * Creates a new Ranking Question with two empty response lists
	 */
	public Ranking(String outputType) {
		super(outputType);
		super.responseList1 = new Vector<CAR>();
		super.responseList0 = new Vector<CAR>();
	}
	
	/**
	 * Creates a new Ranking Question with the first response list initialized to (1-n), 
	 * where n is the size of the second response list
	 * @param prompt
	 * @param responseList1
	 */
	public Ranking(Prompt prompt, Vector<CAR> responseList1, String outputType) {
		super(prompt, outputType);
		super.prompt = prompt;
		super.responseList1 = responseList1;
		super.numResponses = responseList1.size();
		// Set responseList0 values to 1-n
		super.responseList0 = new Vector<CAR>();
		int n;
		for(int i = 0; i < responseList1.size(); i++) {
			n = i + 1;
			super.responseList0.add(new IntCAR(n));
		}
	}
	
	/**
	 * Creates a new Ranking Question with the first response list initialized to (1-n),
	 * where n is the size of the second response list
	 * @param responseList1
	 */
	public void setResponseList(Vector<CAR> responseList1) {
		this.responseList1 = responseList1;
		numResponses = responseList1.size();
		// Set responseList0 values to 1-n
		int n;
		for(int i = 0; i < responseList1.size(); i++) {
			n = i + 1;
			super.responseList0.add(new IntCAR(n));
		}
		super.numResponses = responseList1.size();
	}
	
	public Vector<CAR> getResponseList() {
		return responseList1;
	}
	
	/**
	 * Use in place of get input
	 * returns the user response for a matching list
	 * @return Vector<CAR>
	 */
	public Vector<CAR> getResponse() {
		Scanner in = new Scanner(System.in);
		Vector<CAR> userResponse = new Vector<CAR>();
		int menuVal;
			int ans = 0;
			Output.getOutput(outputType).displayString("Input response: ");
			for(int i = 0; i < numResponses; i++) {
				menuVal = i + 1;
				ans = 0;	// Reset ans to 0 every time to enter while loop
				while(ans < 1 || ans > numResponses) {
					// Loop testing for correct input
					Output.getOutput(outputType).displayString("Input ");
					Output.getOutput(outputType).displayNumbering(menuVal);
					Output.getOutput(outputType).displayString(": ");
					try {
						ans = in.nextInt();
					} catch(InputMismatchException e) {
						Output.getOutput(outputType).displayString("Incorrect input, number must be integer" + "\n");
						in.next();
						continue;
					}
					if(ans < 1 || ans > numResponses) {
						Output.getOutput(outputType).displayString("Incorrect input, number must be between 1 and " +numResponses + "\n");
					}
				}
				// Adding the correct answer from the response list to the correct answer list
				userResponse.add(responseList1.get(ans-1));
		}
			return userResponse;
	}
}
