package menuPackage;

import ioPackage.Output;
import surveyTestPackage.SurveyManager;

public class FillOutSurveyMenu extends Menu {
	private SurveyManager surveyManager;
	
	public FillOutSurveyMenu(String outputType) {
		super(outputType);
		surveyManager = new SurveyManager(outputType);
	}
	
	public Menu runMenu() {
		surveyManager.fillOut(survey);
		
		// Clear answers so that the survey can be filled out again
		survey.clearUserResponses();
		
		BackMenu back = new BackMenu(outputType);
		back.setSurvey(survey);
		return back;
		
	}

}
