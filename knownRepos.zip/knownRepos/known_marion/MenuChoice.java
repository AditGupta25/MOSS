package menuPackage;


public class MenuChoice {
	String choice;
	int choiceIndex;
	
	/**
	 * Create a menu choice with a String descriptor
	 * @param choice
	 */
	public MenuChoice(String choice) {
		this.choice = choice;
	}
	
	/**
	 * Create a menu choice with a String descriptor and an int index
	 * @param choice
	 * @param index
	 */
	public MenuChoice(String choice, int index) {
		this.choice = choice;
		this.choiceIndex = index;
	}
	
	/**
	 * Sets the String descriptor
	 * @param choice
	 */
	public void setChoice(String choice) {
		this.choice = choice;
	}
	
	/**
	 * Set the index of the choice
	 * @param i
	 */
	public void setIndex(int i) {
		this.choiceIndex = i;
	}
	
	/**
	 * Returns the String descriptor of the choice
	 * @return String
	 */
	public String getChoice() {
		return choice;
	}
	
	/**
	 * Returns the index of the choice
	 * @return int
	 */
	public int getIndex() {
		return choiceIndex;
	}
}
