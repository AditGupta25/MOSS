package questionPackage;

import java.io.Serializable;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;

public class Matching extends Question implements Serializable{
	Vector<CAR> responseList0;
	Vector<CAR> responseList1;
	/**
	 * Creates a new Matching Question with the two response lists initialized to empty vectors. 
	 */
	public Matching(String outputType) {
		super(outputType);
		responseList0 = new Vector<CAR>();
		responseList1 = new Vector<CAR>();
	}
	
	/**
	 * Creates a new Matching Question with a Prompt and the two response lists initialized to empty vectors. 
	 * @param prompt
	 */
	public Matching(Prompt prompt, String outputType) {
		super(prompt, outputType);
		responseList0 = new Vector<CAR>();
		responseList1 = new Vector<CAR>();
	}
	
	/**
	 * Creates a new Matching Question with two response lists and a prompt
	 * @param prompt
	 * @param responseList0
	 * @param responseList1
	 */
	public Matching(Prompt prompt, Vector<CAR> responseList0, Vector<CAR> responseList1, String outputType) {
		super(prompt, outputType);
		numResponses = responseList0.size();
		this.responseList0 = responseList0;
		this.responseList1 = responseList1;
	}

	
	public int getNumResponses() {
		return responseList0.size();
	}
	/**
	 * Add response adds a pair of responses to the matching question
	 * response0 is added to the first response list
	 * response1 is added to the second response list
	 * @param response0
	 * @param response1
	 */
	public void addResponse(CAR response0, CAR response1) {
		responseList0.add(response0);
		responseList1.add(response1);
		super.numResponses++;
	}

	
	/**
	 * Sets a response list, depending on the integer passed
	 * Only valid arguments are 0 and 1
	 */
	public void setResponseList(Vector<CAR> responseList, int i) {
		if(responseList.size() == numResponses) {
			if(i < 0 || i > 1) {
				// TODO: Response if invalid list number
				System.out.println("LIST NOT ADDED (INV NUM)");
			} else if(i == 0) {
				responseList0 = responseList;
				super.numResponses = responseList.size();
			} else if(i == 1) {
				responseList1 = responseList;
				super.numResponses = responseList.size();
			}
		} else {
			// TODO: Response if invalid list size
			System.out.println("LIST NOT ADDED (INV SIZE)");
		}
	}

	/**
	 * Returns one of the two response lists
	 * Only valid inputs are 0 and 1
	 * @param i
	 * @return
	 */
	public Vector<CAR> getResponseList(int i) {
		if(i < 0 || i > 1) {
			// TODO: Response if invalid list chosen
			return null;
		} else if(i == 0) {
			return responseList0;
		} else {
			return responseList1;
		}
	}
	
	
	/**
	 * Validates the user input for MatchingQuestion type questions
	 * Input must be of the form "a b" where a and b are digits in the range of the number of responses
	 * @param input
	 * @return boolean
	 */
	public boolean validateMatchingInput(String input) {
		// Function validates input for correct answer to a MatchingQuestion
		// Input must be in the form "a b" where a and b are digits within the response range
		
		// First test for correct input form
		String regex = "^[0-9]+\\s[0-9]+$";
		if(!input.matches(regex)) {
			return false;
		}
		
		// Test to see if numbers are in correct range
		// Split the input 
		String[] pair = input.split(" ");
		if(pair.length != 2) {
			// If there aren't exactly two elements in input its not valid
			return false;
		}
		int[] numPair = new int[2];
		for(int i = 0; i < pair.length; i++) {
			numPair[i] = Integer.parseInt(pair[i]);
			if(numPair[i] < 1 || numPair[i] > numResponses) {
				// If the numbers are out of range, return false;
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Use in place of get input
	 * returns the user response for a matching list
	 * @return Vector<CAR>
	 */
	public Vector<CAR> getResponse() {
		Scanner in = new Scanner(System.in);
		Vector<CAR> userResponse = new Vector<CAR>();
		int menuVal;
		String ans = "";
		Output.getOutput(outputType).displayString("Input response in space delimited form (ex: 1 2 would match the 1st item on the left to the 2nd on the right): " + "\n");
		for(int i = 0; i < numResponses; i++) {
			menuVal = i + 1;
			// Validate user input
			while(!validateMatchingInput(ans)) {
				Output.getOutput(outputType).displayString("Input ");
				Output.getOutput(outputType).displayNumbering(menuVal);
				Output.getOutput(outputType).displayString(": ");
				ans = in.nextLine().toString().trim();
				if(!validateMatchingInput(ans)) {
					Output.getOutput(outputType).displayString("Incorrect format" + "\n");
				}
			}
			// Add answer to list
			String[] ansIndex = ans.split(" ");
			int[] ansIndexNum = new int[2];
			String ansString = "";
			for(int j = 0; j < ansIndex.length; j++) {
				ansIndexNum[j] = Integer.parseInt(ansIndex[j]);
			}
			// Concatenate responses into string to add to correct answer list
			ansString += responseList0.get(ansIndexNum[0]-1).getResponse();
			ansString += " ";
			ansString += responseList1.get(ansIndexNum[1]-1).getResponse();
			// Add answer to correct answer list
			StringCAR matchAns = new StringCAR(ansString);
			userResponse.add(matchAns);
			ans = "";	// Reset ans to re enter while loop
		}	
		return userResponse;
	}
	
	/**
	 * Allow user to enter input to answer question
	 */
	public void answerQuestion() {
		userResponseList.addAll(getResponse());
	}
	
	/**
	 * Displays a Matching Question in the following format:
	 * Prompt.....
	 * 1) 1.1		1) 2.1
	 * 2) 1.2		2) 2.2
	 * 3) 1.3		3) 2.3
	 * 4) 1.4		4) 2.4
	 */
	public void display() {
		// TODO: Use printf to tab nicely 
		prompt.display(outputType);
		Output.getOutput(outputType).displayString("Select " + maxNumUserResponses + " response(s)" + "\n");
		int menuVal;
		for(int i = 0; i < responseList0.size(); i++) {
			menuVal = i + 1;
			// Display first list
			Output.getOutput(outputType).displayString(menuVal + ") ");
			responseList0.get(i).display(outputType);
			Output.getOutput(outputType).displayString("    ");
			// Display Second List
			Output.getOutput(outputType).displayString(menuVal + ") ");
			responseList1.get(i).display(outputType);
			Output.getOutput(outputType).displayString("\n");
		}
		Output.getOutput(outputType).displayString("\n");
	}
}

