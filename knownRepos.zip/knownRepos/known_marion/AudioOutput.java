package ioPackage;

import java.util.Vector;

import menuPackage.MenuChoice;
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;


public class AudioOutput extends Output {
	
	public final static AudioOutput INSTANCE  = new AudioOutput();
	// Declare voice for output
	private static final String VOICENAME_kevin = "kevin";
	private Voice voice;
	private VoiceManager voiceManager;
	
	/**
	 * Creates a new instance of AudioOutput
	 */
	protected AudioOutput() {
		voiceManager = VoiceManager.getInstance();
		voice = voiceManager.getVoice(VOICENAME_kevin);
		voice.allocate();
	}	 
	 
	/**
	 * Displays a string to the terminal
	 */
	public void displayString(String s) {
		voice.speak(s);
		TerminalOutput.INSTANCE.displayString(s);
	}
	
	/**
	 *  Displays an int to the terminal
	 */
	public void displayInt(int i) {
		voice.speak(Integer.toString(i));
		TerminalOutput.INSTANCE.displayInt(i);
	}
	
	/**
	 * Displays an ordinal number to the terminal
	 */
	public void displayNumbering(int i) {
		voice.speak(NumberToWord.convert(i));
		TerminalOutput.INSTANCE.displayNumbering(i);
	}
	
	/**
	 * Displays a Menu to the terminal
	 */
	public void displayMenu(Vector<MenuChoice> choices) {
		System.out.println("\n");
		System.out.println("===================================================");
		for(int i = 0; i < choices.size(); i++) {
			int t = i + 1;
			TerminalOutput.INSTANCE.displayString(t + ") " + choices.get(i).getChoice() + "\n");
		}
		System.out.println("===================================================");
	}
}
