package menuPackage;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;
import questionPackage.CAR;
import questionPackage.Essay;
import questionPackage.Matching;
import questionPackage.MultipleChoice;
import questionPackage.Prompt;
import questionPackage.Question;
import questionPackage.Ranking;
import questionPackage.ShortAnswer;
import questionPackage.StringCAR;
import questionPackage.StringPrompt;
import questionPackage.TrueFalse;
import surveyTestPackage.Survey;
import surveyTestPackage.Test;

public class AddQuestionMenu extends Menu {
	protected Question question;
	protected Survey survey;
	protected int numResponses;
	protected int numUserResponses;
	
	Scanner in;
	
	/**
	 * Creates a new AddQuestionMenu with desired output.
	 * A survey is passed as input to add the question to.
	 * A blank question of a specified type is passed as input. 
	 * @param outputType
	 * @param survey
	 * @param question
	 */
	public AddQuestionMenu(String outputType, Survey survey, Question question) {
		super(outputType);
		this.survey = survey;
		this.question = question;
		in = new Scanner(System.in);
	}
	
	/**
	 * Allows the user to input a prompt
	 * @return Prompt
	 */
	public Prompt inputPrompt() {
		String promptString = "";
		while(promptString.equals("")) {
			Output.getOutput(outputType).displayString("Input the question prompt: ");
			promptString = in.nextLine();
			if(promptString.equals("")) {
				Output.getOutput(outputType).displayString("Prompt cannot be blank" + "\n");
			}
		}
		Prompt prompt = new StringPrompt(promptString);
		return prompt;
	}
	
	/**
	 * Allows the user to input the number of responses to a question. 
	 * @return int
	 */
	public int inputNumResponses() {
		int numResponses = 0;
		while(numResponses < 1) {
			try {
				Output.getOutput(outputType).displayString("Input the number of responses: ");
				numResponses = in.nextInt();	
			} catch(InputMismatchException e) {
				Output.getOutput(outputType).displayString("Incorrect input, number must be integer > 0" + "\n");
				in.next();
				continue;
			}
			if(numResponses < 1) {
				Output.getOutput(outputType).displayString("Incorrect input, number must be integer > 0" + "\n");
			}
		}
		this.numResponses = numResponses;
		return numResponses;
	}
	
	/**
	 * Allows the user to input the maximum number of user responses allowed
	 * @return int
	 */
	public int inputNumUserResponses() {
		int numUserResponses = 0;
		while(numUserResponses < 1 || numUserResponses > numResponses) {
			try {
				Output.getOutput(outputType).displayString("Input the number of allowed user responses: ");
				numUserResponses = in.nextInt();	
			} catch(InputMismatchException e) {
				Output.getOutput(outputType).displayString("Incorrect input, number must be integer > 0" + "\n");
				in.next();
				continue;
			}
			if(numUserResponses < 1) {
				Output.getOutput(outputType).displayString("Incorrect input, number must be integer > 0" + "\n");
			} else if(numUserResponses > numResponses) {
				Output.getOutput(outputType).displayString("Number of user responses must be <= number of responses" + "\n");
			}

		}
		this.numUserResponses = numUserResponses;
		question.setMaxNumUserResponses(numUserResponses);
		return numUserResponses;
	}
	
	/**
	 * Displays which list the user is adding to
	 * @param i
	 */
	public void inputResponsesDisplayMessage(int i) {
		if(i >= 1) {
			Output.getOutput(outputType).displayString("Input the ");
			Output.getOutput(outputType).displayNumbering(i);
			Output.getOutput(outputType).displayString(" response list" + "\n");
		} else {
			Output.getOutput(outputType).displayString("Input the response list" + "\n");
		}

	}
	
	/**
	 * inputResponses takes user input to generate responseLists for questions. 
	 * @param multiLists
	 * multiLists is for the print statement. If multiple lists (for matching questions), displays what number list is being input.
	 * If 0 is input the program assumes only 1 list is needed.  
	 * @return responseList
	 */
	public Vector<CAR> inputResponses(int multiLists) {
		in = new Scanner(System.in);
		inputResponsesDisplayMessage(multiLists);
		Vector<CAR> responseList = new Vector<CAR>(numResponses);
		int responseNum;
		for(int i = 0; i < numResponses; i++) {
			responseNum = i + 1;
			Output.getOutput(outputType).displayString("Input the ");
			Output.getOutput(outputType).displayNumbering(responseNum);
			Output.getOutput(outputType).displayString(" response: ");
			String responseString = in.nextLine();
			while(responseString.equals("")) {
				Output.getOutput(outputType).displayString("Response cannot be blank: ");
				responseString = in.nextLine();
			}
			CAR response = new StringCAR(responseString);
			responseList.add(response);
		}
		return responseList;
	}
	
	/**
	 * Allows the user to input a character limit for ShortAnswer Questions
	 * @return int
	 */
	public int inputCharacterLimit() {
		int characterLimit = 0;
		while(characterLimit < 1) {
			try {
				Output.getOutput(outputType).displayString("Input the character limit: ");
				characterLimit = in.nextInt();
			} catch(InputMismatchException e) {
				Output.getOutput(outputType).displayString("Incorrect input, number must be integer > 0" + "\n");
				in.next();
				continue;
			}
			if(characterLimit < 1) {
				Output.getOutput(outputType).displayString("Incorrect input, number must be integer > 0" + "\n");
			}
		}
		return characterLimit;
	}
	
	/**
	 * Determines what should be input by the user depending on the type of question passed in the argument.
	 * Returns the question with all necessary inputs. 
	 * @param question
	 * @return Question
	 */
	public Question determineInput(Question question) {
		// Input is determined by the type of question
		// Get question prompt (ALL QUESTIONS)
		question.setPrompt(this.inputPrompt());
		
		// If a question is T/F or Essay, cannot set responses
		if(!(question instanceof TrueFalse) && !(question instanceof Essay)) {
			// Get number of responses
			question.setNumResponses(this.inputNumResponses());
		}
		
		// If a question is multiple choice or ranking it has one list of responses
		if((question instanceof MultipleChoice && !(question instanceof TrueFalse))|| question instanceof Ranking) {
			Vector<CAR> responseList = this.inputResponses(0);
			question.setResponseList(responseList);
		} else 
		// If a question is matching it has two lists of responses
		if(question instanceof Matching) {
			Vector<CAR> responseList1 = this.inputResponses(1);
			Vector<CAR> responseList2 = this.inputResponses(2);
			
			((Matching)question).setResponseList(responseList1, 0);
			((Matching)question).setResponseList(responseList2, 1);
		}
		
		if(question instanceof ShortAnswer) {
			question.setNumResponses(this.inputNumResponses());
			((ShortAnswer)question).setCharacterLimit(inputCharacterLimit());
		}
		// If a question is T/F or Essay, cannot set maximum num user responses
		if(!(question instanceof TrueFalse) && !(question instanceof Essay)) {
			// Get maximum number user responses
			question.setMaxNumUserResponses(this.inputNumUserResponses());
		}
		return question;
	}
	
	/**
	 * Runs the actions for the Menu
	 */
	public Menu runMenu() {
		this.question = determineInput(question);
		survey.enterQuestion(question);
		// Automatically go back once question is added 
		// This returns user to CreateSurveyMenu
		Menu back = new BackMenu(outputType);
		back.setSurvey(survey);
		return back;
	}

}
