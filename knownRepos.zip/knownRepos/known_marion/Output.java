package ioPackage;
import java.io.Serializable;
import java.util.Vector;

import menuPackage.MenuChoice;
/**
 * The Output class and subclasses are singleton classes
 *
 */
public abstract class Output implements Serializable {
	
	protected Output() {
	}
	
	/**
	 * Displays a string with desired output
	 * @param s
	 */
	public void displayString(String s) {
		
	}
	
	/**
	 * Displays a int with desired output
	 * @param i
	 */
	public void displayInt(int i) {
		
	}
	
	/**
	 * Displays a Menu with desired output
	 * @param choices
	 */
	public void displayMenu(Vector<MenuChoice> choices) {
		
	}
	
	/**
	 * Displays ordinal numbering with desired output
	 * @param i
	 */
	public void displayNumbering(int i) {
		
	}
	
	/**
	 * Return the specified type of output instance
	 * @param outputType
	 * @return
	 */
	public static Output getOutput(String outputType) {
		if(outputType.equalsIgnoreCase("terminal")) {
			return TerminalOutput.INSTANCE;
		} else if(outputType.equalsIgnoreCase("audio")) {
			return AudioOutput.INSTANCE;
		} else {
			// Return terminal output by default
			return TerminalOutput.INSTANCE;
		}
	}
}
