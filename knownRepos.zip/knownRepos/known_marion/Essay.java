package questionPackage;

import java.io.Serializable;
import java.util.Scanner;

import ioPackage.Output;

public class Essay extends Question implements Serializable{
	/**
	 * Creates a new Essay Question
	 */
	public Essay(String outputType) {
		super(outputType);
		super.maxNumUserResponses = 1;
	}
	
	/**
	 * Creates a new Essay Question with a prompt
	 * @param prompt
	 */
	public Essay(Prompt prompt, String outputType) {
		super(prompt, outputType);
		super.maxNumUserResponses = 1;
	}

	/**
	 * Cannot set a different number of user responses for Essay Questions 
	 */
	public boolean setMaxNumUserResponses(int nr) {
		return false;
	}
	
	/**
	 * Validate user input 
	 * @return boolean
	 */
	public boolean validateInput(String s) {
		if(s.isEmpty()) {
			return false;
		} else {
			return true;
		}
	}
	
	/**
	 * Used instead of getInput
	 * returns user response
	 * @return String
	 */
	public String getResponse() {
		Scanner in = new Scanner(System.in);
		String ans = "";
		while(!validateInput(ans)) {
			ans = in.nextLine();
			if(!validateInput(ans)) {
				Output.getOutput(outputType).displayString("Response cannot be blank" + "\n");
			}
		}
		return ans;
	}
	
	/**
	 * Allows user to answer question
	 */
	public void answerQuestion() {
		Output.getOutput(outputType).displayString("Enter question response: ");
		StringCAR ans = new StringCAR(getResponse());
		userResponseList.add(ans);
	}
	
	/**
	 * Displays an essay question in the following format:
	 * Prompt... 
	 */
	public void display() {
		prompt.display(outputType);
		Output.getOutput(outputType).displayString("\n");
	}

}
