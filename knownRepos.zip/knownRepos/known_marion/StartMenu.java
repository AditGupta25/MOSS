package menuPackage;

import java.util.Vector;

import ioPackage.Output;

public class StartMenu extends Menu {
	/**
	 * Creates a new StartMenu
	 * This Menu is the first to be run and offers the user either Survey or Test functions
	 * @param outputType
	 * @param manager
	 */
	public StartMenu(String outputType, MenuManager manager) {
		super(outputType, manager);
		
		// Creating menu choices
		MenuChoice survey = new MenuChoice("Survey", 0);
		MenuChoice test = new MenuChoice("Test", 1);
		MenuChoice quit = new MenuChoice("Quit", 2);
		// Adding choices to list
		super.choices = new Vector<MenuChoice>();
		super.choices.add(survey);
		super.choices.add(test);
		super.choices.add(quit);
	}
	
	/**
	 * Allows the user to select a MenuChoice
	 */
	public Menu select(int i) {
		boolean test;
		switch(i) {
			case 1:
				// Go to survey menu
				test = false;
				Menu surveyMenu = new SurveyTestMenu(outputType, manager, test);
				surveyMenu.setSurvey(survey);
				return surveyMenu;
			case 2:	
				// Go to test menu
				test = true;
				Menu testMenu = new SurveyTestMenu(outputType, manager, test);
				testMenu.setSurvey(survey);
				return testMenu;
			case 3:
				// Go to quit menu
				QuitMenu quit = new QuitMenu(outputType);
				return quit;
		}
		return null;
	}
}
