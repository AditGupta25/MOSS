package menuPackage;

import java.util.Vector;

import ioPackage.Output;
import surveyTestPackage.Survey;

public class MenuManager {
	Vector<Menu> menus;

	Vector<Menu> previousMenus;
	Menu currentMenu;
	Menu nextMenu;
	Survey currentSurvey;
	String outputType;
	
	/**
	 * Creates a MenuManager with desired output
	 * The MenuManager is responsible for running the Menus and storing an array of them.
	 * @param outputType
	 */
	public MenuManager(String outputType) {
		this.outputType = outputType;
		menus = new Vector<Menu>();
		menus.add(new StartMenu(outputType, this));
		
		previousMenus = new Vector<Menu>();
		currentMenu = menus.get(0);
		nextMenu = null;
		currentSurvey = new Survey(outputType);
	}
	
	/**
	 * Selects the first menu to run
	 */
	public void start() {
		this.runMenu(this.select(0));
	}
	
	/**
	 * Returns a Menu at index i
	 * @param i
	 * @return Menu
	 */
	public Menu select(int i) {
		return menus.get(i);
	}
	
	/**
	 * Executes the Menu functions.
	 * If a BackMenu is returned, the MenuManager loads the previous Menu
	 * If a QuitMenu is returned, the MenuManager quits the program
	 * If null is returned, the program is terminated
	 * @param menu
	 */
	public void runMenu(Menu menu) {
		boolean quit = false;
		int counter = 0;
		currentMenu = menu;
		menus.add(currentMenu);
		
		while(!quit) {
			// FOR TESTING PURPOSES
			//System.out.println(currentMenu.getClass().getName());
			
			// Keep track of the current survey to pass it back and forth between Menus
			currentSurvey = currentMenu.getSurvey();
			nextMenu = currentMenu.runMenu();
			// Test for null
			if(nextMenu == null) {
				nextMenu = new QuitMenu(outputType);
				nextMenu.runMenu();
				quit = true;
			} else 
			// Test for Quit
			if(nextMenu instanceof QuitMenu) {
				nextMenu.runMenu();
				quit = true;
			} else
			// Test for Back
			if(nextMenu instanceof BackMenu) {
				// If the number of steps is more than the available menus, cannot go back
				if(previousMenus.size() - ((BackMenu)nextMenu).getNumSteps() < 0) {
					Output.getOutput(outputType).displayString("Cannot go back any further!");
				} else {
					nextMenu.runMenu();
					// Return to the previous menu using the number of steps
					counter -= ((BackMenu) nextMenu).getNumSteps();
					currentMenu = previousMenus.get(counter);
					currentMenu.setSurvey(currentSurvey);
				}
			} else {
				// Otherwise, move on to next menu
				previousMenus.add(currentMenu);
				menus.add(nextMenu);
				currentMenu = nextMenu;
				counter++;
			}
		}
	}
}
