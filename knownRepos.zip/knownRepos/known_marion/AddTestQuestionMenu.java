package menuPackage;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;
import questionPackage.CAR;
import questionPackage.Essay;
import questionPackage.Matching;
import questionPackage.Question;
import questionPackage.Ranking;
import questionPackage.ShortAnswer;
import questionPackage.StringCAR;
import surveyTestPackage.Test;

public class AddTestQuestionMenu extends AddQuestionMenu {
	public AddTestQuestionMenu(String outputType, Test test, Question question) {
		super(outputType, test, question);
	}
	
	/**
	 * Allows the user to input the correct answer to a question.
	 * The user can input multiple correct answers as a list. 
	 * @return Vector<CAR>
	 */
	public Vector<CAR> inputCorrectAnswer() {
		Vector<CAR> correctAnswer = new Vector<CAR>();
		question.display();
		for(int i = 0; i < question.getMaxNumUserResponses(); i++) {
			// Must check if answer is is responseList
			int ans = 0;
			int menuVal = i + 1;
			// Answer must be between 1 and the number of responses
			while(ans < 1 || ans > question.getNumResponses()) {
				if(question.getMaxNumUserResponses() == 1) {
					// If only 1 correct response allowed, print statement accordingly
					Output.getOutput(outputType).displayString("Input the correct response: ");
				} else {
					// If multiple correct responses allowed print ordinal values
					Output.getOutput(outputType).displayString("Input the "); 
					Output.getOutput(outputType).displayNumbering(menuVal);
					Output.getOutput(outputType).displayString(" correct response: ");
				}
				try {
					ans = in.nextInt();
				} catch(InputMismatchException e) {
					Output.getOutput(outputType).displayString("Incorrect input, number must be integer" + "\n");
					in.next();
					continue;
				}
				if(ans < 1 || ans > question.getNumResponses()) {
					Output.getOutput(outputType).displayString("Incorrect input, number must be between 1 and " + question.getNumResponses() + "\n");
				}
			}
			// Adjust answer by 1 because answer vector starts at 0
			correctAnswer.add(question.getResponse(ans - 1));
		}
		return correctAnswer;
	}
	
	/**
	 * Allows the user to input the correct answers for a short answer question
	 * @return Vector<CAR>
	 */
	public Vector<CAR> inputCorrectShortAnswer() {
		Vector<CAR> CorrectAnswer = new Vector<CAR>();
		question.display();
		int menuVal;
		String ans = "";
		for(int i = 0; i < question.getNumResponses(); i++) {
			menuVal = i + 1;
			Output.getOutput(outputType).displayString("Input ");
			Output.getOutput(outputType).displayNumbering(menuVal);
			Output.getOutput(outputType).displayString(" correct answer: ");
			ans = in.nextLine();
			while(ans.equals("")) {
				Output.getOutput(outputType).displayString("Correct answer cannot be blank" + "\n");
				ans = in.nextLine();
			}
			StringCAR answer = new StringCAR(ans);
			CorrectAnswer.add(answer);
			ans = "";	// Reset ans to a blank string to enter the while loop again
		}
		return CorrectAnswer;
	}
	
	/**
	 * Allows the user to input correct answers for all MatchingQuestion type questions
	 * @return Vector<CAR>
	 */
	public Vector<CAR> inputCorrectMatchingAnswer() {
		in = new Scanner(System.in);	// Reset scanner
		Vector<CAR> correctAnswer = new Vector<CAR>();
		int menuVal;
		question.display();
		if(question instanceof Ranking) {
			int ans = 0;
			Output.getOutput(outputType).displayString("Input correct answer: ");
			for(int i = 0; i < question.getNumResponses(); i++) {
				menuVal = i + 1;
				ans = 0;	// Reset ans to 0 every time to enter while loop
				while(ans < 1 || ans > question.getNumResponses()) {
					// Loop testing for correct input
					Output.getOutput(outputType).displayString("Input ");
					Output.getOutput(outputType).displayNumbering(menuVal);
					Output.getOutput(outputType).displayString(": ");
					try {
						ans = in.nextInt();
					} catch(InputMismatchException e) {
						Output.getOutput(outputType).displayString("Incorrect input, number must be integer" + "\n");
						in.next();
						continue;
					}
					if(ans < 1 || ans > question.getNumResponses()) {
						Output.getOutput(outputType).displayString("Incorrect input, number must be between 1 and " + question.getNumResponses() + "\n");
					}
				}
				// Adding the correct answer from the response list to the correct answer list
				correctAnswer.add(question.getResponseList().get(ans-1));
			}
		} else {
			// Question is an instance of matching
			String ans = "";
			Output.getOutput(outputType).displayString("Input correct answer in space delimited form (ex: 1 2 would match the 1st item on the left to the 2nd on the right): " + "\n");
			for(int i = 0; i < question.getNumResponses(); i++) {
				menuVal = i + 1;
				// Validate user input
				while(!validateMatchingInput(ans)) {
					Output.getOutput(outputType).displayString("Input ");
					Output.getOutput(outputType).displayNumbering(menuVal);
					Output.getOutput(outputType).displayString(": ");
					ans = in.nextLine().toString().trim();
					if(!validateMatchingInput(ans)) {
						Output.getOutput(outputType).displayString("Incorrect format" + "\n");
					}
				}
				// Add answer to list
				String[] ansIndex = ans.split(" ");
				int[] ansIndexNum = new int[2];
				String ansString = "";
				for(int j = 0; j < ansIndex.length; j++) {
					ansIndexNum[j] = Integer.parseInt(ansIndex[j]);
				}
				// Concatenate responses into string to add to correct answer list
				ansString += ((Matching)question).getResponseList(0).get(ansIndexNum[0]-1).getResponse();
				ansString += " ";
				ansString += ((Matching)question).getResponseList(1).get(ansIndexNum[1]-1).getResponse();
				// Add answer to correct answer list
				StringCAR matchAns = new StringCAR(ansString);
				correctAnswer.add(matchAns);
				ans = "";	// Reset ans to re enter while loop
			}
		}
		return correctAnswer;
	}
	
	/**
	 * Validates the user input for MatchingQuestion type questions
	 * Input must be of the form "a b" where a and b are digits in the range of the number of responses
	 * @param input
	 * @return boolean
	 */
	public boolean validateMatchingInput(String input) {
		// Function validates input for correct answer to a MatchingQuestion
		// Input must be in the form "a b" where a and b are digits within the response range
		
		// First test for correct input form
		String regex = "^[0-9]+\\s[0-9]+$";
		if(!input.matches(regex)) {
			return false;
		}
		
		// Test to see if numbers are in correct range
		// Split the input 
		String[] pair = input.split(" ");
		if(pair.length != 2) {
			// If there aren't exactly two elements in input its not valid
			return false;
		}
		int[] numPair = new int[2];
		for(int i = 0; i < pair.length; i++) {
			numPair[i] = Integer.parseInt(pair[i]);
			if(numPair[i] < 1 || numPair[i] > question.getNumResponses()) {
				// If the numbers are out of range, return false;
				return false;
			}
		}
		return true;
	}
	
	
	/**
	 * Runs the actions for the Menu
	 */
	public Menu runMenu() {
		// A correct answer list must always be added to the test (even for essay) to keep the question index equal to the answer index
		Vector<CAR> correctAnswer = new Vector<CAR>();
		question = determineInput(question);
		if(!(question instanceof Essay) && !(question instanceof Matching)) {
			// Handle the input of T/F and Multiple Choice
			correctAnswer = this.inputCorrectAnswer();
			((Test)survey).addCorrectAnswerList(correctAnswer);
		} 
		if(question instanceof ShortAnswer) {
			// Handle the input of Short Answer
			correctAnswer = this.inputCorrectShortAnswer();
			((Test)survey).addCorrectAnswerList(correctAnswer);
		}
		if(question instanceof Matching) {
			// Handle the input of Matching and Ranking
			correctAnswer = this.inputCorrectMatchingAnswer();
			((Test)survey).addCorrectAnswerList(correctAnswer);
		}
		if(question instanceof Essay && !(question instanceof ShortAnswer)) {
			// Handle the input of Essay
			((Test)survey).addCorrectAnswerList(correctAnswer);
		}
		
		((Test)survey).enterQuestion(question);
		for(int i = 0; i < ((Test)survey).getAnswerList().size(); i++) {
			System.out.println();
		}
		BackMenu back = new BackMenu(outputType);
		back.setSurvey(survey);
		return back;
	}

}
