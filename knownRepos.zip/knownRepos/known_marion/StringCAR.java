package questionPackage;
import java.io.Serializable;

import ioPackage.Output;

public class StringCAR extends CAR implements Serializable, Comparable<CAR> {
	String response;
	
	/**
	 * Creates a new CAR with a String response
	 * @param response
	 */
	public StringCAR(String response) {
		this.response = response;
	}
	
	/**
	 * Returns the String response
	 * @return String
	 */
	public String getResponse() {
		return response;
	}
	
	/**
	 * Sets the String response
	 * @param response
	 */
	public void setResponse(String response) {
		this.response = response;
	}
	
	/**
	 * Allows a StringCAR to be compared to another CAR
	 * Returns 1 if equal.
	 * Returns 0 otherwise.
	 */
	public int compareTo(CAR response) {
		// Returning 0 is false
		// Returning 1 is true
		if(response instanceof StringCAR && this.response.equals(((StringCAR) response).getResponse())) {
			return 1;
		} else {
			return 0;
		}
	}

	/**
	 * Displays response as a String
	 */
	public void display(String outputType) {
		Output.getOutput(outputType).displayString(response);
	}
}
