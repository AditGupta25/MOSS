package menuPackage;
import ioPackage.Output;

public class BackMenu extends Menu {
	private int numSteps;
	/**
	 * Returns the user to the previous menu
	 * @param o
	 */
	public BackMenu(String outputType) {
		super(outputType);
		numSteps = 1;
		super.outputMessage = "Returning to previous menu... " + "\n";
	}
	
	/**
	 * Returns the user to n menus back (ex: numSteps = 2 will bring the user back twice)
	 * @param numSteps
	 * @param o
	 */
	public BackMenu(int numSteps, String outputType) {
		super(outputType);
		this.numSteps = numSteps;
		super.outputMessage = "Returning to previous menu... ";
	}
	/**
	 * Return the number of specified steps
	 * @return int
	 */
	public int getNumSteps() {
		return numSteps;
	}
	/**
	 * Runs the actions for the Menu
	 */
	public Menu runMenu() {
		this.outputMessage();
		return this;
	}
}
