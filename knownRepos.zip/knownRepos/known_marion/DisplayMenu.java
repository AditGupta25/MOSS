package menuPackage;

import ioPackage.Output;
import surveyTestPackage.Test;

public class DisplayMenu extends Menu{
	
	/**
	 * DisplayMenu takes the loaded survey and displays it
	 * @param outputType
	 */
	public DisplayMenu(String outputType) {
		super(outputType);
	}
	
	/**
	 * Runs the actions for the Menu
	 */
	public Menu runMenu() {
		if(survey instanceof Test) {
			((Test)survey).displayAnswers();
		} else {
			survey.display();
			
		}
		BackMenu back = new BackMenu(outputType);
		back.setSurvey(survey);
		return back;
		
	}
}
