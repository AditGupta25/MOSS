package questionPackage;

import java.io.Serializable;

import ioPackage.Output;

public class BooleanCAR extends CAR implements Serializable, Comparable<CAR> {
	private boolean response;
	
	/**
	 * Creates a new BooleanCAR with a boolean response
	 * @param response
	 */
	public BooleanCAR(boolean response) {
		this.response = response;
	}
	
	/**
	 * Sets the response to true or false
	 * @param response
	 */
	public void setResponse(boolean response) {
		this.response = response;
	}
	
	/**
	 * Returns the response
	 * @return boolean
	 */
	public Boolean getResponse() {
		return response;
	}
	
	/**
	 * Compares BooleanCAR to another CAR
	 * Returns 1 if equal
	 * returns 0 otherwise
	 */
	public int compareTo(CAR response) {
		// Returning 0 is false
		// Returning 1 is true
		if(response instanceof BooleanCAR && this.response == ((BooleanCAR) response).getResponse()){
			return 1;
		} else {
			return 0;
		}
	}

	/**
	 * Displays BooleanCAR as a String
	 */
	public void display(String outputType) {
		Output.getOutput(outputType).displayString(Boolean.toString(response));
	}
}
