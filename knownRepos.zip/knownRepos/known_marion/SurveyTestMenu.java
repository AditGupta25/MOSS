package menuPackage;
import java.util.Vector;

import ioPackage.Output;
import surveyTestPackage.Survey;
import surveyTestPackage.Test;

public class SurveyTestMenu extends Menu {
	String type;
	boolean isTest;
	/**
	 * Creates a SurveyTestMenu. This Menu gives options for creating, displaying, or loading a test/survey.
	 * @param outputType
	 * @param manager
	 * @param isTest
	 */
	public SurveyTestMenu(String outputType, MenuManager manager, boolean isTest) {
		super(outputType, manager);
		// Type denotes whether a survey is a test
		this.isTest = isTest;
		if(isTest) {
			type = "Test";
		} else {
			type = "Survey";
		}
		
		// Creating menu choices
		MenuChoice create = new MenuChoice("Create " + type, 0);
		MenuChoice load = new MenuChoice("Load " + type, 1);
		MenuChoice back = new MenuChoice("Back", 2);
		MenuChoice quit = new MenuChoice("Quit", 3);
		// Adding choices to list
		super.choices = new Vector<MenuChoice>();
		super.choices.add(create);
		super.choices.add(load);
		super.choices.add(back);
		super.choices.add(quit);
	}
	
	/**
	 * Allows the user to select a MenuChoice
	 */
	public Menu select(int i) {
		switch(i) {
			case 1:
				// Go to creation menu
				CreateSurveyMenu create;
				if(isTest) {
					Test test = new Test(outputType);
					create = new CreateTestMenu(outputType, test);
				} else {
					Survey survey = new Survey(outputType);
					create = new CreateSurveyMenu(outputType, survey);
				}
				return create;
			case 2:	
				// Go to display menu
				SelectSurveyMenu selectSurvey = new SelectSurveyMenu(outputType, isTest);
				selectSurvey.setSurvey(survey);
				return selectSurvey;
			case 3:
				// Go to back menu
				BackMenu back = new BackMenu(outputType);
				back.setSurvey(survey);
				return back;
			case 4:
				// Go to quit menu
				QuitMenu quit = new QuitMenu(outputType);
				return quit;
		}
		return null;
	}

}
