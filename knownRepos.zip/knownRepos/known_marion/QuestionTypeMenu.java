package menuPackage;

import java.util.Vector;
import ioPackage.Output;
import questionPackage.Essay;
import questionPackage.Matching;
import questionPackage.MultipleChoice;
import questionPackage.Question;
import questionPackage.Ranking;
import questionPackage.ShortAnswer;
import questionPackage.TrueFalse;
import surveyTestPackage.Survey;
import surveyTestPackage.Test;

public class QuestionTypeMenu extends Menu {
	private Survey survey;
	
	/**
	 * Creates a new QuestionTypeMenu.
	 * This Menu allows the user to choose a type of question to add to a Survey/Test
	 * @param outputType
	 * @param survey
	 */
	public QuestionTypeMenu(String outputType, Survey survey) {
		super(outputType);
		this.survey = survey;
		
		MenuChoice addTF = new MenuChoice("Add new T/F question", 0);
		MenuChoice addMultChoice = new MenuChoice("Add new multiple choice question", 1);
		MenuChoice addEssay = new MenuChoice("Add new essay question", 2);
		MenuChoice addShortAns = new MenuChoice("Add new short answer question", 3);
		MenuChoice addRanking = new MenuChoice("Add new ranking question", 4);
		MenuChoice addMatching = new MenuChoice("Add new matching question", 5);
		MenuChoice back = new MenuChoice("Back", 6);
		// Adding choices to list
		super.choices = new Vector<MenuChoice>();
		super.choices.add(addTF);
		super.choices.add(addMultChoice);
		super.choices.add(addEssay);
		super.choices.add(addShortAns);
		super.choices.add(addRanking);
		super.choices.add(addMatching);
		super.choices.add(back);
	}
	
	/**
	 * Allows the user to select a MenuChoice
	 */
	public Menu select(int i) {
		Question question = null;
		switch(i) {
			case 1:
				// Go to add question menu with T/F
				question = new TrueFalse(outputType);
				break;
			case 2:	
				// Go to add question menu with Multiple Choice
				question = new MultipleChoice(outputType);
				break;
			case 3:
				// Go to add question menu with Essay
				question = new Essay(outputType);
				break;
			case 4:
				// Go to add question menu with Short Answer
				question = new ShortAnswer(outputType);
				break;
			case 5:
				// Go to add question menu with Ranking
				question = new Ranking(outputType);
				break;
			case 6:
				// Go to add question menu with Matching
				question = new Matching(outputType);
				break;
			case 7:
				// Go back to CreateSurveyMenu
				CreateSurveyMenu create = new CreateSurveyMenu(outputType, survey);
				create.setSurvey(survey);
				return create;
		}
		AddQuestionMenu addQuestion;
		if(survey instanceof Test) {
			addQuestion = new AddTestQuestionMenu(outputType, (Test)survey, question);
		} else {
			addQuestion = new AddQuestionMenu(outputType, survey, question);
		}
		addQuestion.setSurvey(survey);
		return addQuestion;
	}
	
}
