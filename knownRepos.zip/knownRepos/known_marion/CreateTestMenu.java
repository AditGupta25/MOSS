package menuPackage;
import ioPackage.Output;
import surveyTestPackage.Test;

public class CreateTestMenu extends CreateSurveyMenu {
	Test test;
	/**
	 * This menu has the same functionality as the CreateSurveyMenu but returns a Test
	 * @param outputType
	 * @param test
	 */
	public CreateTestMenu(String outputType, Test test) {
		super(outputType, test);
	}
}
