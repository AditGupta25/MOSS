package questionPackage;

import ioPackage.Output;

public class StringPrompt extends Prompt{
	private String prompt;
	/**
	 * Creates a new String prompt for a Question
	 * @param prompt
	 */
	public StringPrompt(String prompt) {
		this.prompt = prompt;
	}
	
	/**
	 * Sets the prompt String
	 * @param prompt
	 */
	public void setPrompt(String prompt) {
		this.prompt = prompt;
	}
	
	/**
	 * Returns the prompt String
	 * @return String
	 */
	public String getPrompt() {
		return prompt;
	}
	
	/**
	 * Displays the Prompt as a String
	 */
	public void display(String outputType) {
		Output.getOutput(outputType).displayString(prompt + "\n");
	}
}
