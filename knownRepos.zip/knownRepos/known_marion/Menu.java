package menuPackage;

import java.io.InputStream;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;
import surveyTestPackage.Survey;

public abstract class Menu {
	private int numChoices;
	protected String outputMessage = "Enter menu choice: ";
	protected Vector<MenuChoice> choices;
	protected MenuManager manager;
	protected String outputType;
	protected Survey survey;
	
	/**
	 * Creates a Menu with the desired output
	 * @param output
	 */
	public Menu(String outputType) {
		this.outputType = outputType;
		choices = new Vector<MenuChoice>();
		survey = new Survey(outputType);
	}
	
	public Menu(String outputType, MenuManager manager) {
		this.outputType = outputType;
		this.manager = manager;
		choices = new Vector<MenuChoice>();
		survey = new Survey(outputType);
	}
	
	public Menu(Vector<MenuChoice> choices) {
		this.choices = choices;
		this.numChoices = choices.size();
		survey = new Survey(outputType);
	}
	
	/**
	 * Overridden in other Menu classes.
	 * Allows users to select an option from the menu. 
	 * @param i
	 * @return
	 */
	public Menu select(int i) {
		return null;
	}
	
	/**
	 * Returns the survey being passed to the Menu
	 * @return
	 */
	public Survey getSurvey() {
		return survey;
	}
	
	/**
	 * Sets the Survey passed to the Menu
	 * @param survey
	 */
	public void setSurvey(Survey survey) {
		this.survey = survey;
	}
	
	/**
	 * Get input from the user to make a menu selection
	 * @return
	 */
	public int getInput() {
		Scanner in = new Scanner(System.in);
		int i = 0;
		boolean intEntered = false;
		boolean validInput = false;
		while(!validInput) {
			try {
				i = in.nextInt();
				intEntered = true;
				validInput = validInput(i);
			} catch(InputMismatchException e) {
				Output.getOutput(outputType).displayString("Invalid input, input must be an integer" + "\n");
				in.next();
				continue;
			}
			if(!validInput(i)) {
				Output.getOutput(outputType).displayString("Invalid input, input must be from 1 to " + choices.size() + "\n");
			}
		}
		return i;
	}
	
	/**
	 * Checks for valid input.
	 * Returns true if input is valid, false otherwise.
	 * @param i
	 * @return
	 */
	public boolean validInput(int i) {
		if( i < 1 || i > choices.size()) {
			return false;
		} else {
			return true;
		}
	}
	
	/**
	 * Displays output message for Menu
	 */
	public void outputMessage() {
		Output.getOutput(outputType).displayString(outputMessage);
	}
	
	/**
	 * Displays menu choices
	 */
	public void display() {
		Output.getOutput(outputType).displayMenu(choices);
	}
	
	/**
	 * Runs the actions for the Menu
	 * By default displays the menu and allows for selection. 
	 * @param o
	 * @return
	 */
	public Menu runMenu() {
		this.display();
		this.outputMessage();
		int i = this.getInput();
		return this.select(i);
	}
}
