package questionPackage;
import java.io.Serializable;

import ioPackage.Output;

public class IntCAR extends CAR implements Serializable, Comparable<CAR> {
	int response;
	
	/**
	 * Creates a new CAR with an int response
	 * @param response
	 */
	public IntCAR(int response) {
		this.response = response;
	}
	
	/**
	 * Returns the int response
	 * @return int
	 */
	public Integer getResponse() {
		return response;
	}
	
	/**
	 * Sets the int response
	 * @param response
	 */
	public void setResponse(int response) {
		this.response = response;
	}
	
	/**
	 * Compares this CAR to another CAR
	 * Returns 1 if equal.
	 * Returns 0 otherwise.
	 */
	public int compareTo(CAR response) {
		// Returning 0 is false
		// Returning 1 is true
		if(response instanceof IntCAR && this.response == ((IntCAR) response).getResponse()) {
			return 1;
		} else {
			return 0;
		}
	}
	
	/**
	 * Displays the response as an int
	 */
	public void display(String outputType) {
		Output.getOutput(outputType).displayInt(response);
	}

}
