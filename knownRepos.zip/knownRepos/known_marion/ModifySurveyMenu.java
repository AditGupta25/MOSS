package menuPackage;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;
import questionPackage.CAR;
import questionPackage.Essay;
import questionPackage.Matching;
import questionPackage.MultipleChoice;
import questionPackage.Prompt;
import questionPackage.Question;
import questionPackage.Ranking;
import questionPackage.ShortAnswer;
import questionPackage.StringCAR;
import questionPackage.StringPrompt;
import questionPackage.TrueFalse;
import surveyTestPackage.Survey;
import surveyTestPackage.SurveyManager;
import surveyTestPackage.Test;
// TODO: finish modify survey implementation
public class ModifySurveyMenu extends Menu {
	protected Question question;
	private Scanner in;
	private MenuChoice yes;
	private MenuChoice no;
	/**
	 * Creates a new EditQuestionMenu with a specified output type and survey
	 * @param outputType
	 * @param survey
	 */
	public ModifySurveyMenu(String outputType) {
		super(outputType);
		in = new Scanner(System.in);
		
		yes = new MenuChoice("Yes", 0);
		no = new MenuChoice("No", 1);
		super.choices = new Vector<MenuChoice>();
		super.choices.add(yes);
		super.choices.add(no);
	}
	
	private int getInput(int range) {
		int num = 0;
		while(num < 1 || num > range) {
			try {
				num = in.nextInt();
			} catch (InputMismatchException e) {
				Output.getOutput(outputType).displayString("Incorrect input, number must be integer between 1 and " + range + "\n");
				in.next();
				continue;
			}
			if(num < 1 || num > range) {
				Output.getOutput(outputType).displayString("Incorrect input, number must be integer between 1 and " + range + "\n");	
			}
		}
		return num;
	}
	
	public Question selectQuestion(Survey survey) {
		super.choices.clear();
		String q;
		int menuVal = 0;
		for(int i = 0; i < survey.getNumQuestions(); i++) {
			menuVal += 1;
			q = survey.getQuestion(i).getPrompt().getPrompt().toString();
			super.choices.addElement(new MenuChoice(q, menuVal));
		}
		this.outputMessage = "Select question to modify: ";
		this.display();
		this.outputMessage();
		int n = getInput(survey.getNumQuestions());
		return survey.getQuestion(n - 1);
		
	}
	
	public StringCAR inputResponse() {
		StringCAR response;
		Output.getOutput(outputType).displayString("Enter response: ");
		String responseString = in.nextLine();
		while(responseString.equals("")) {
			Output.getOutput(outputType).displayString("Response cannot be blank: ");
			responseString = in.nextLine();
		}
		response = new StringCAR(responseString);
		return response;
	}
	
	public Menu runMenu() {
		// Select question to edit
		question = selectQuestion(survey);
		// Create AddQuestionMenu to use setters and getters
		AddQuestionMenu modifyQuestion = new AddQuestionMenu(outputType, survey, question);
		int response;
		// Clear menu choices and add yes or no selection
		super.choices.clear();
		super.choices.add(yes);
		super.choices.add(no);
		
		// Modify prompt
		this.outputMessage = "Modify question prompt?" + "\n";
		this.outputMessage();
		this.display();
		Output.getOutput(outputType).displayString("Enter menu choice: ");
		// Get either 1 or 2 as input
		response = getInput(2);
		if(response == 1) {
			// Input new prompt
			Prompt prompt = modifyQuestion.inputPrompt();
			question.setPrompt(prompt);
		}
		
		// Modify responses
		// Can only modify responses if not Essay and not TrueFalse
		if(!(question instanceof Essay) && !(question instanceof TrueFalse)) {
			this.outputMessage = "Modify question responses?" + "\n";
			this.outputMessage();
			this.display();
			Output.getOutput(outputType).displayString("Enter menu choice: ");
			// Get either 1 or 2 as input
			response = getInput(2);
			if(response == 1) {
				// Modify response list for multiple choice and ranking
				// Set menu choices to different responses
				super.choices.clear();
				int menuVal;
				Vector<CAR> responseList;
				int menuSelection = 0;
				if(question instanceof Matching && !(question instanceof Ranking)) {
					// Modify response list for matching
					super.choices.clear();
					super.choices.add(new MenuChoice("1", 0));
					super.choices.add(new MenuChoice("2", 1));
					this.outputMessage = "Select response list to modify: ";
					this.display();
					this.outputMessage();
					menuSelection = getInput(2);
					
					responseList = ((Matching)question).getResponseList(menuSelection - 1);
				} else {
					responseList = question.getResponseList();
				}
				
				super.choices.clear();
				this.outputMessage = "Enter response to modify: ";
				for(int i = 0; i < question.getNumResponses(); i++) {
					menuVal = i + 1;
					CAR respObj = responseList.get(i);
					String resp = ((StringCAR)respObj).getResponse();
					super.choices.add(new MenuChoice(resp, menuVal));
				}
				
				this.display();
				this.outputMessage();
				
				// Get input for new response 
				response = getInput(question.getNumResponses());
				System.out.println("Response: " + response);
				
				// Set the new response
				responseList.setElementAt(inputResponse(), response - 1);
				
				if(question instanceof Matching && !(question instanceof Ranking)) {
					((Matching)question).setResponseList(responseList, menuSelection - 1);
				} else {
					question.setResponseList(responseList);
				}
			}
		}
		
		// If the question is ShortAnswer, ask to modify character limit
		if(question instanceof ShortAnswer) {
			this.outputMessage = "Modify character limit?" + "\n";
			this.outputMessage();
			this.display();
			Output.getOutput(outputType).displayString("Enter menu choice: ");
			// Get either 1 or 2 as input
			response = getInput(2);
			if(response == 1) {
				int characterLimit = modifyQuestion.inputCharacterLimit();
				((ShortAnswer)question).setCharacterLimit(characterLimit);
			}
		}

		if(survey instanceof Test) {
			// Can only modify correct response if not Essay
			if(!(question instanceof Essay) || question instanceof ShortAnswer) {
				this.outputMessage = "Modify correct response?" + "\n";
				this.outputMessage();
				this.display();
				Output.getOutput(outputType).displayString("Enter menu choice: ");
				// Get either 1 or 2 as input
				response = getInput(2);
				if(response == 1) {
					AddTestQuestionMenu modifyTestQuestion = new AddTestQuestionMenu(outputType, ((Test)survey), question);
					System.out.println("Modifying correct response");
					Vector<CAR> newAnswerList = new Vector<CAR>();
					if(question instanceof MultipleChoice) {
						newAnswerList = modifyTestQuestion.inputCorrectAnswer();
					} else if(question instanceof Matching) {
						newAnswerList = modifyTestQuestion.inputCorrectMatchingAnswer();
					} else if(question instanceof ShortAnswer) {
						newAnswerList = modifyTestQuestion.inputCorrectShortAnswer();	
					}
					for(int i = 0; i < newAnswerList.size(); i++) {
						System.out.println(newAnswerList.get(i).getResponse());
					}
					((Test)survey).setAnswer(question, newAnswerList);
				}	
			}
		}
		
		// Save survey changes before returning
		SurveyManager surveyManager = new SurveyManager(outputType);
		surveyManager.save(survey);
		
		Menu back = new BackMenu(outputType);
		back.setSurvey(survey);
		return back;
	}

}
