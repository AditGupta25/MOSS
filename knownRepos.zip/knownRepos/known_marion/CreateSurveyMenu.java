package menuPackage;

import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;
import surveyTestPackage.Survey;
import surveyTestPackage.SurveyManager;
import surveyTestPackage.Test;

public class CreateSurveyMenu extends Menu {

	protected String author;
	protected String title;
	private SurveyManager surveyManager;
	
	/**
	 * The CreateSurveyMenu allows the user to create a survey
	 * From this menu the user can add, edit, remove, display, or save a survey
	 * @param outputType
	 * @param survey
	 */
	public CreateSurveyMenu(String outputType, Survey survey) {
		super(outputType);
		this.survey = survey;
		surveyManager = new SurveyManager(outputType);
		// Creating menu choices
		MenuChoice addQuestion = new MenuChoice("Add Question", 0);
		MenuChoice editQuestion = new MenuChoice("Edit Question", 1);
		MenuChoice removeQuestion = new MenuChoice("Remove Question", 2);
		MenuChoice displaySurvey = new MenuChoice("Display", 3);
		MenuChoice save = new MenuChoice("Save", 4);
		MenuChoice back = new MenuChoice("Back", 5);
		MenuChoice quit = new MenuChoice("Quit", 6);
		// Adding choices to list
		super.choices = new Vector<MenuChoice>();
		super.choices.add(addQuestion);
		super.choices.add(editQuestion);
		super.choices.add(removeQuestion);
		super.choices.add(displaySurvey);
		super.choices.add(save);
		super.choices.add(back);
		super.choices.add(quit);
	}
	
	/**
	 * Allows the user to set the author of the survey
	 * @param o
	 */
	public void setAuthor() {
		Output.getOutput(outputType).displayString("Enter Author: ");
		Scanner in = new Scanner(System.in);
		String author = in.nextLine();
		while(author.equals("")) {
			Output.getOutput(outputType).displayString("Author cannot be blank" + "\n");
			author = in.nextLine();
		}
		this.author = author;
		survey.setAuthor(this.author);
	}
	
	/**
	 * Allows the user to set the title of the survey
	 * @param o
	 */
	public void setTitle() {
		Output.getOutput(outputType).displayString("Enter Title: ");
		Scanner in = new Scanner(System.in);
		String title = in.nextLine();
		while(title.equals("")) {
			Output.getOutput(outputType).displayString("Title cannot be blank" + "\n");
			title = in.nextLine();
		}
		this.title = title;
		survey.setTitle(this.title);
	}
	
	/**
	 * Allows the user to select from the menu
	 */
	public Menu select(int i) {
		switch(i) {
			case 1:
				// Go to question type menu
				QuestionTypeMenu questionType = new QuestionTypeMenu(outputType, survey);
				survey.display();
				questionType.setSurvey(survey);
				return questionType;
			case 2:	
				// Go to edit question menu
				Output.getOutput(outputType).displayString("Available in Homework 3!" + "\n");
				return this;
			case 3:
				// Go to remove question menu
				Output.getOutput(outputType).displayString("Available in Homework 3!" + "\n");
				return this;
			case 4:
				if(survey instanceof Test) {
					((Test)survey).displayAnswers();
				} else {
					survey.display();
				}
				return this;
			case 5:
				// Save the survey and then go back twice
				surveyManager.save(survey);
				BackMenu backTwo = new BackMenu(2, outputType);
				backTwo.setSurvey(survey);
				return backTwo;
			case 6:
				// Go to back menu
				BackMenu back = new BackMenu(outputType);
				back.setSurvey(survey);
				return back;
			case 7:
				// Go to quit menu
				QuitMenu quit = new QuitMenu(outputType);
				return quit;
		}
		return null;
	}
	/**
	 * Runs the actions for the Menu
	 */
	public Menu runMenu() {
		if(survey.getAuthor().isEmpty()) {
			this.setAuthor();
		}
		if(survey.getTitle().isEmpty()) {
			this.setTitle();
		}

		this.display();
		this.outputMessage();
		int i = this.getInput();
		return this.select(i);
	}
}
