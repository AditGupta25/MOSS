package questionPackage;
import java.io.Serializable;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;

public class MultipleChoice extends Question implements Serializable {
	/**
	 * Creates a new multiple choice question with number of responses initialized to 0
	 */
	public MultipleChoice(String outputType) {
		super(outputType);
		numResponses = 0;
	}
	
	/**
	 * Creates a new multiple choice question with a prompt and number of responses initialized to 0
	 */
	public MultipleChoice(Prompt prompt, String outputType) {
		super(prompt, outputType);
		numResponses = 0;
	}
	
	/**
	 * Creates a new multiple choice question with a prompt and a responseList
	 */
	public MultipleChoice(Prompt prompt, Vector<CAR> responseList, String outputType) {
		super(prompt, responseList, outputType);
		this.numResponses = responseList.size();
	}

	/**
	 * Sets the responseList and sets the number of responses to the size
	 */
	public void setResponseList(Vector<CAR> responseList) {
		super.setResponseList(responseList);
		this.numResponses = responseList.size();
	}

	
	/**
	 * Allow user to enter input to answer question
	 */
	public void answerQuestion() {
		while(userResponseList.size() < maxNumUserResponses) {
			int i = getInput();
			userResponseList.add(responseList.get(i - 1));
		}
	}
	
	/**
	 * Displays the MultipleChoice question in the following format:
	 * Prompt........
	 * Select n response(s)
	 * 1) Option1	2) Option2	3) Option3 ....
	 */
	public void display() {
		prompt.display(outputType);
		Output.getOutput(outputType).displayString("Select " + maxNumUserResponses + " response(s)" + "\n");
		int menuVal;
		for(int i = 0; i < responseList.size(); i++) {
			menuVal = i + 1;
			Output.getOutput(outputType).displayString(menuVal + ") ");
			responseList.get(i).display(outputType);
			Output.getOutput(outputType).displayString("    ");
		}
		Output.getOutput(outputType).displayString("\n");
	}
}
