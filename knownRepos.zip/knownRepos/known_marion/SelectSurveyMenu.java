package menuPackage;

import java.io.File;
import java.io.FilenameFilter;
import java.util.InputMismatchException;
import java.util.Scanner;

import ioPackage.Output;
import surveyTestPackage.Survey;
import surveyTestPackage.SurveyManager;
import surveyTestPackage.Test;

public class SelectSurveyMenu extends Menu {
	private SurveyManager surveyManager;
	private String directories[];
	private String[] files;
	private String filePath;
	private Scanner in;
	private boolean isTest;
	private String patternString;
	
	public SelectSurveyMenu(String outputType, boolean isTest) {
		super(outputType);
		this.isTest = isTest;
		// Setting regular expression for file selection
		// If viewing tests, only tests appear and same for surveys
		if(isTest) {
			this.patternString = ".*\\.test";
		} else {
			this.patternString = ".*\\.survey";
		}
		
		surveyManager = new SurveyManager(outputType);
		in = new Scanner(System.in);
		filePath = "./SavedSurveys";
		files = null;
		File savedDirectory = new File(filePath);
		// Iterate through saved file directory creating list of authors to choose from
		String[] directories = savedDirectory.list(new FilenameFilter() {
			  public boolean accept(File current, String name) {
			    return new File(current, name).isDirectory();
			  }
			});
		this.directories = directories;
		// For every author, create a menu choice
		for(int i = 0; i < directories.length; i++) {
			MenuChoice choice = new MenuChoice(directories[i], i);
			choices.add(choice);
		}	
	}
	

	/**
	 * Allows the user to select an author to display a file from
	 * Returns the name of the author. 
	 * @return String
	 */
	private String selectAuthor() {
		in = new Scanner(System.in);
		int author = 0;
		while(author < 1 || author > directories.length) {
			Output.getOutput(outputType).displayString("Please select an author: ");
			try {
				author = in.nextInt();
			} catch (InputMismatchException e) {
				Output.getOutput(outputType).displayString("Input must be integer from 1 to " + directories.length + "\n");
				in.next();
				continue;
			}
			if(author < 1 || author > directories.length) {
				Output.getOutput(outputType).displayString("Input must be integer from 1 to " + directories.length + "\n");
			}
		}
		// Answer offset by 1 because array indexed at 0
		return directories[author-1];
	}
	
	/**
	 * Allows the user to select a file.
	 * Returns the name of the file.
	 * @return String
	 */
	private String selectFile() {
		in = new Scanner(System.in);
		int file = 0;
		while(file < 1 || file > files.length) {
			Output.getOutput(outputType).displayString("Please select an file: ");
			try {
				file = in.nextInt();
			} catch (InputMismatchException e) {
				Output.getOutput(outputType).displayString("Input must be integer from 1 to " + files.length + "\n");
				in.next();
				continue;
			}
			if(file < 1 || file > directories.length) {
				Output.getOutput(outputType).displayString("Input must be integer from 1 to " + files.length + "\n");
			}
		}
		// Answer offset by 1 because array indexed at 0
		return files[file-1];
	}
	
	/**
	 * Runs the actions for the Menu
	 */
	public Menu runMenu() {
		// If no saved files, return to previous menu
		if(directories.length < 1) {
			Output.getOutput(outputType).displayString("Nothing to display!" + "\n");
			BackMenu back = new BackMenu(outputType);
			return back;
		}
		this.display();
		String author = selectAuthor();
		
		// After author has been selected, display all files in directory
		File authorDirectory = new File("./SavedSurveys/" + author);
		String[] files = authorDirectory.list(new FilenameFilter() {
			  public boolean accept(File current, String name) {
				  if(name.matches(patternString)) {
					  return new File(current, name).isFile();
				  }
				  return false;
			  }
			});
		this.files = files;
		
		// If no saved files from author, return to previous menu
		if(files.length < 1) {
			Output.getOutput(outputType).displayString("Nothing to display!" + "\n");
			BackMenu back = new BackMenu(outputType);
			return back;
		}
		// Clearing the list of choices and adding files to menu choices
		choices.clear();
		int choiceNum = 0;
		for(int i = 0; i < files.length; i++) {
			// Select only test or survey files depending on what was chosen in the menu
				MenuChoice choice = new MenuChoice(files[i], choiceNum);
				choices.add(choice);
				choiceNum++;
		}
		// If none of the chosen file are present, go back
		if(choices.size() < 1) {
			Output.getOutput(outputType).displayString("Nothing to display!" + "\n");
			BackMenu back = new BackMenu(outputType);
			return back;
		}
		
		this.display();
		String file = selectFile();
		
		// Create final file path and display survey
		filePath = authorDirectory + "/" + file;
		Survey survey = surveyManager.load(filePath);
		
		LoadSurveyMenu load = new LoadSurveyMenu(outputType, isTest);
		load.setSurvey(survey);
		return load;
	}

}
