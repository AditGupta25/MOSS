package ioPackage;
import java.util.Vector;

import menuPackage.MenuChoice;

public class TerminalOutput extends Output {
	
	public final static TerminalOutput INSTANCE  = new TerminalOutput();
	
	protected TerminalOutput() {
		// Only purpose is to defeat new instantiation
	}
	
	/**
	 * Displays a string to the terminal
	 */
	public void displayString(String s) {
		System.out.print(s);
	}
	
	/**
	 *  Displays an int to the terminal
	 */
	public void displayInt(int i) {
		System.out.print(i);
	}
	
	/**
	 * Displays an ordinal number to the terminal
	 */
	public void displayNumbering(int i) {
		System.out.print(i);
		String[] suffixes = new String[] {"th", "st", "nd", "rd", "th", "th", "th", "th", "th", "th" };
		switch(i % 100) {
		case 11:
		case 12:
		case 13:
			System.out.print("th");
		default:
			System.out.print(suffixes[i % 10]);
		}
	}
	
	/**
	 * Displays a Menu to the terminal
	 */
	public void displayMenu(Vector<MenuChoice> choices) {
		System.out.println("===================================================");
		for(int i = 0; i < choices.size(); i++) {
			int t = i + 1;
			this.displayString(t + ") " + choices.get(i).getChoice() + "\n");
		}
		System.out.println("===================================================");
	}
}
