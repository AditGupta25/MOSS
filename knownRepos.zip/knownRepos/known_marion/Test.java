package surveyTestPackage;
import java.io.Serializable;
import java.util.Vector;

import ioPackage.Output;
import questionPackage.CAR;
import questionPackage.Essay;
import questionPackage.Question;
import questionPackage.ShortAnswer;

public class Test extends Survey implements Serializable{
	private float grade;
	private Vector<Vector<CAR>> correctAnswers;
	
	/**
	 * Creates a new Test
	 * @param o
	 */
	public Test(String outputType) {
		super(outputType);
		correctAnswers = new Vector<Vector<CAR>>();
	}
	
	/**
	 * Creates a new Survey
	 * @param author
	 * @param title
	 * @param o
	 */
	public Test(String author, String title, String outputType) {
		super(author, title, outputType);
		correctAnswers = new Vector<Vector<CAR>>();
	}
	
	/**
	 * Creates a new test with a given author, title, question list, and answer list
	 * @param author
	 * @param title
	 * @param q
	 * @param ans
	 * @param o
	 */
	public Test(String author, String title, Vector<Question> q, Vector<Vector<CAR>> ans, String outputType) {
		super(author, title, q, outputType);
		this.correctAnswers = ans;
	}
	
	/**
	 * Adds a correct answer to the correctAnswerList
	 * @param correctAnswerList
	 */
	public void addCorrectAnswerList(Vector<CAR> correctAnswerList) {
		correctAnswers.add(correctAnswerList);
	}
	
	/**
	 * Sets the correct answer to a given question
	 * @param question
	 * @param correctAnswer
	 */
	public void setAnswer(Question question, Vector<CAR> correctAnswer) {
		// TODO: Check if number of correct answers <= number of possible choices
		int i = questions.indexOf(question);
		if(i == -1) {
			// TODO: action if question doesn't exist
		} else {
			correctAnswers.set(i, correctAnswer);
		}
	}
	
	/**
	 * Sets the correctAnswers list
	 * @param correctAnswers
	 */
	public void setAnswerList(Vector<Vector<CAR>> correctAnswers) {
		this.correctAnswers = correctAnswers;
	}
	
	/**
	 * Return the correctAnswers list
	 * @return
	 */
	public Vector<Vector<CAR>> getAnswerList() {
		return correctAnswers;
	}
	
	/**
	 * Changes the answer of a selected question
	 * @param questionNum
	 * @param i
	 * @param correctAnswer
	 */
	public void editAnswer(int questionNum, int i, CAR correctAnswer) {
		correctAnswers.elementAt(questionNum).elementAt(i).equals(correctAnswer);
	}
	
	/**
	 * Displays the answers of the test underneath each question
	 */
	public void displayAnswers() {
		int menuVal;
		for(int i = 0; i < questions.size(); i++) {
			menuVal = i + 1;
			Output.getOutput(outputType).displayString("Q");
			Output.getOutput(outputType).displayInt(menuVal);
			Output.getOutput(outputType).displayString(": ");
			questions.get(i).display();
			displayAnswer(i);
			Output.getOutput(outputType).displayString("\n");
		}
	}
	
	/**
	 * Displays the answer to a selected question
	 * @param questionNum
	 */
	public void displayAnswer(int questionNum) {
		Output.getOutput(outputType).displayString("Correct Answer: ");
		for(int i = 0; i < correctAnswers.get(questionNum).size(); i++) {
			correctAnswers.get(questionNum).get(i).display(outputType);
			if (correctAnswers.get(questionNum).size() > 1) {
				Output.getOutput(outputType).displayString("\n");
			}
		}
		Output.getOutput(outputType).displayString("\n");
	}
	
	/**
	 * Checks a user response against the answer of a question
	 * @param questionNum
	 * @return boolean
	 */
	private boolean checkAnswer(int questionNum) {
		int numUserResponses = super.questions.get(questionNum).getUserResponseList().size();
		Question question = super.questions.get(questionNum);
		Vector<CAR> userResponseList = question.getUserResponseList();
		Vector<CAR> correctAnswer = this.correctAnswers.get(questionNum);
		
		if(userResponseList.size() != correctAnswer.size()) {
			return false;
		} else {
			for(int i = 0; i < numUserResponses; i++) {
				if(!userResponseList.get(i).equals(correctAnswer.get(i))) {
					return false;
				}
			}
			return true;
		}
	}
	
	/**
	 * Grades the test, weighting all questions equally
	 * @return double
	 */
	public float gradeTest() {
		Output.getOutput(outputType).displayString("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + "\n");
		Output.getOutput(outputType).displayString("~~~~~~~~~~~~~~~~~~~~~ RESULTS ~~~~~~~~~~~~~~~~~~~~~" + "\n");
		Output.getOutput(outputType).displayString("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + "\n");
		grade = 0;
		float pointsPerQuestion = (float)100/(float)questions.size();
		Output.getOutput(outputType).getOutput(outputType).displayString("Points per question: " + pointsPerQuestion + "\n");
		for(int i = 0; i < questions.size(); i++) {
			Output.getOutput(outputType).displayString(questions.get(i).getPrompt().getPrompt().toString());
			if(checkAnswer(i)) {
				grade += pointsPerQuestion;
				Output.getOutput(outputType).displayString(": Correct");
			} else if(questions.get(i) instanceof Essay && !(questions.get(i) instanceof ShortAnswer)) {
				Output.getOutput(outputType).displayString(": Not Graded");
			} else {
				Output.getOutput(outputType).displayString(": Incorrect");
			}
			Output.getOutput(outputType).displayString("\n");
		}
		return grade;
	}
	
	/**
	 * Allow user to input answers to survey questions 
	 */
	public void fillOut() {
		super.fillOut();
		grade = gradeTest();
		Output.getOutput(outputType).displayString("Grade: " + grade + "%" + "\n");
		Output.getOutput(outputType).displayString("*Note: All tests graded without Essays included" + "\n");
		Output.getOutput(outputType).displayString("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" + "\n");
	}
}
