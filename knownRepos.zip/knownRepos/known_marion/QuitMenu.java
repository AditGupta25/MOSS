package menuPackage;
import ioPackage.Output;

public class QuitMenu extends Menu {
	/**
	 * Creates a new QuitMenu.
	 * When QuitMenu is returned the program terminates. 
	 * @param outputType
	 */
	public QuitMenu(String outputType) {
		super(outputType);
		super.outputMessage = "Exiting Program";
	}
	
	/**
	 * Runs the actions for the Menu
	 */
	public Menu runMenu() {
		this.outputMessage();
		return null;
	}
}
