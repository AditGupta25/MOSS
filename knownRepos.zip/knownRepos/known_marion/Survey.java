package surveyTestPackage;
import java.io.Serializable;
import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;
import questionPackage.CAR;
import questionPackage.Essay;
import questionPackage.Matching;
import questionPackage.MultipleChoice;
import questionPackage.Prompt;
import questionPackage.Question;

public class Survey implements Serializable {
	private String author;
	private String title;
	protected Vector<Question> questions;
	private int numQuestions;
	private boolean filledOut;
	String outputType;
	
	/**
	 * Creates a new Survey with null title, author, and an empty vector of Questions
	 * @param outputType
	 */
	public Survey(String outputType) {
		this.outputType = outputType;
		this.title = "";
		this.author = "";
		questions = new Vector<Question>();
		numQuestions = 0;
		filledOut = false;
	}
	
	/**
	 * Creates a new Survey
	 * @param author
	 * @param title
	 * @param o
	 */
	public Survey(String author, String title, String outputType) {
		this.author = author;
		this.title = title;
		this.outputType = outputType;
		questions = new Vector<Question>();
		numQuestions = 0;
		filledOut = false;
	}
	
	/**
	 * Creates a new Survey
	 * @param author
	 * @param title
	 * @param q
	 * @param o
	 */
	public Survey(String author, String title, Vector<Question> q, String outputType) {
		this.author = author;
		this.title = title;
		this.questions = q;
		this.outputType = outputType;
		numQuestions = questions.size();
		filledOut = false;
	}
	
	/**
	 * Returns the author
	 * @return String
	 */
	public String getAuthor() {
		return this.author;
	}
	
	/**
	 * Sets the author
	 * @param author
	 */
	public void setAuthor(String author) {
		this.author = author;
	}
	
	/**
	 * Returns the title
	 * @return String
	 */
	public String getTitle() {
		return this.title;
	}
	
	/**
	 * Sets the title
	 * @param title
	 */
	public void setTitle(String title) {
		this.title = title;
	}
	
	/**
	 * Set whether or not the survey has been filled out
	 * @param f
	 */
	public void setFilledOut(boolean f) {
		filledOut = f;
	}
	
	/**
	 * Adds a question to the questions vector
	 * @param question
	 */
	public void enterQuestion(Question question) {
		questions.add(question);
		numQuestions++;
	}
	
	
	public void editQuestion(int i) {
		// TODO: Implement
	}
	
	/**
	 * Changes a Question Prompt
	 * @param i
	 * @param p
	 */
	public void editQuestionPrompt(int i, Prompt p) {
		questions.get(i).setPrompt(p);
	}
	
	/**
	 * Changes a Question response list
	 * @param i
	 * @param responseList
	 */
	public void editQuestionResponseList(int i, Vector<CAR> responseList) {
		questions.get(i).setResponseList(responseList);
	}
	
	/**
	 * Removes a question from the survey
	 * @param i
	 */
	public void removeQuestion(int i) {
		questions.remove(i);
		numQuestions--;
	}
	
	/**
	 * Returns a Question at the specified index
	 * @param i
	 * @return Question
	 */
	public Question getQuestion(int i) {
		return questions.get(i);
	}
	
	/**
	 * Get the number of questions the survey contains
	 * @return int
	 */
	public int getNumQuestions() {
		return questions.size();
	}
	
	/**
	 * Clear user response after survey is filled out to retake survey
	 */
	public void clearUserResponses() {
		for(Question question : questions) {
			question.clearUserResponse();
		}
	}
	
	/**
	 * Returns whether or not the survey has been filled out
	 * @return boolean
	 */
	public boolean isFilledOut() {
		return filledOut;
	}
	
	/**
	 * Displays the author as a String
	 */
	public void displayAuthor() {
		Output.getOutput(outputType).displayString("Author: " + this.author + "\n");	
	}
	
	/**
	 * Displays the title as a String
	 */
	public void displayTitle() {
		Output.getOutput(outputType).displayString("Title: " + this.title + "\n");
	}
	
	/**
	 * Displays all survey questions with the author and title at the top
	 */
	public void display() {
		displayAuthor();
		displayTitle();
		int menuVal;
		for(int i = 0; i < questions.size(); i++) {
			menuVal = i + 1;
			Output.getOutput(outputType).displayString("Q");
			Output.getOutput(outputType).displayInt(menuVal);
			Output.getOutput(outputType).displayString(": ");
			questions.get(i).display();
			Output.getOutput(outputType).displayString("\n");
		}
	}
	
	/**
	 * Allow user to input answers to survey questions 
	 */
	public void fillOut() {
		for(int i = 0; i < questions.size(); i++) {
			questions.get(i).display();
			questions.get(i).answerQuestion();
		}
		filledOut = true;
	}
	
	public void tabulate() {
		// TODO: Tabulate results from all instances of this survey
	}
}
