package questionPackage;

import java.io.Serializable;

import ioPackage.Output;

public class ShortAnswer extends Essay implements Serializable{
	private int characterLimit;
	/**
	 * Creates a new ShortAnswer question with the character limit per response set to 0
	 */
	public ShortAnswer(String outputType) {
		super(outputType);
		// Initialize character limit at 0
		characterLimit = 0;
		numResponses = 1;
	}
	
	/**
	 * Creates a new ShortAnswer question with the character limit per response set to 0
	 */
	public ShortAnswer(Prompt prompt, String outputType) {
		super(prompt, outputType);
		// Initialize character limit at 0
		characterLimit = 0;
		numResponses = 1;
	}
	
	/**
	 * Returns the character limit
	 * @return int
	 */
	public int getCharacterLimit() {
		return characterLimit;
	}
	
	/**
	 * sets the character limit
	 * @param characterLimit
	 */
	public void setCharacterLimit(int characterLimit) {
		this.characterLimit = characterLimit;
	}
	
	public void setNumResponses(int numResponses) {
		this.numResponses = numResponses;
		this.maxNumUserResponses = numResponses;
	}
	
	
	public int getNumResponses() {
		return numResponses;
	}
	
	public boolean validateInput(String s) {
		if(s.isEmpty()) {
			return false;
		} else if(s.length() > characterLimit) {
			return false;
		} else {
			return true;
		}
	}
	
	/**
	 * Allows user to answer question
	 */
	public void answerQuestion() {
		int menuVal;
		for(int i = 0; i < maxNumUserResponses; i++) {
			menuVal = i + 1;
			Output.getOutput(outputType).displayString("Enter ");
			Output.getOutput(outputType).displayNumbering(menuVal);
			Output.getOutput(outputType).displayString(" response: ");
			StringCAR ans = new StringCAR(getResponse());
			userResponseList.add(ans);
		}
	}
	
	/**
	 * Displays a ShortAnswer Question in the following format:
	 * Prompt...
	 * 1)
	 * 2)
	 * 3)
	 * ...
	 */
	public void display() {
		prompt.display(outputType);
		Output.getOutput(outputType).displayString("Character limit per response: " + this.characterLimit + "\n");
		int menuVal;
		for(int i = 0; i < numResponses; i++) {
			menuVal = i + 1;
			Output.getOutput(outputType).displayString(menuVal + ") ");
			Output.getOutput(outputType).displayString("\n");
		}
		Output.getOutput(outputType).displayString("\n");
	}
}
