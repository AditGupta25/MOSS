package questionPackage;
import java.io.Serializable;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.Vector;

import ioPackage.Output;

public abstract class Question implements Serializable {
	protected Prompt prompt;
	protected Vector<CAR> responseList;
	protected Vector<CAR> userResponseList;
	protected int numResponses;
	protected int maxNumUserResponses;
	protected String outputType;
	/**
	 * Creates a new Question
	 */
	public Question(String outputType) {
		this.outputType = outputType;
		responseList = new Vector<CAR>();
		userResponseList = new Vector<CAR>();
		// Automatically initialize max responses to 1
		maxNumUserResponses = 1;
		// Initialize numResponses to 0
		numResponses = 0;
	}
	
	/**
	 * Creates a new Question with a Prompt
	 * @param prompt
	 */
	public Question(Prompt prompt, String outputType) {
		this.prompt = prompt;
		this.outputType = outputType;
		responseList = new Vector<CAR>();
		userResponseList = new Vector<CAR>();	
		// Automatically initialize max responses to 1
		maxNumUserResponses = 1;
	}
	
	/**
	 * Creates a new Question with a Prompt and a response list
	 * @param prompt
	 * @param responseList
	 */
	public Question(Prompt prompt, Vector<CAR> responseList, String outputType) {
		this.prompt = prompt;
		this.responseList = responseList;
		this.outputType = outputType;
		
		userResponseList = new Vector<CAR>();
		maxNumUserResponses = 1;
	}
	
	//~~~~~~~~~~~~~ SETTERS ~~~~~~~~~~~~~
	/**
	 * Sets the Prompt
	 * @param prompt
	 */
	public void setPrompt(Prompt prompt) {
		this.prompt = prompt;
	}
	/**
	 * Sets the number of responses (the size of the response vector)
	 * @param numResponses
	 */
	public void setNumResponses(int numResponses) {
		this.numResponses = numResponses;
	}
	
	/**
	 * Adds a response if the size of the response list is less than the predetermined number of responses
	 * @param response
	 */
	public void addResponse(CAR response) {
		if(numResponses == 0) {
			// If the number of responses is 0, it hasn't been set to another value by the user
			responseList.add(response);
		} else if(responseList.size() < numResponses) {
			responseList.add(response);	
			//numResponses++;
		} else {
			// TODO: Action if response can't be added
		}
		numResponses = responseList.size();
	}
	
	/**
	 * Sets responseList for subclasses with one repsonseList
	 * (MultipleChoice, TrueFalse, Ranking)
	 * @param responseList
	 */
	public void setResponseList(Vector<CAR> responseList) {
		this.responseList = responseList;
		numResponses = responseList.size();
	}

	/**
	 * Sets the responseList for subclasses with more than one responseList
	 * (Matching)
	 * Allows for input of int to determine which responseList to input (0 or 1)
	 * @param l1
	 * @param i
	 */
	public void setResponseList(Vector<CAR> l1, int i) {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * Used to set the number of expected user responses. 
	 * Returns true if maxNumUserResponses < responseList size
	 * @param nr
	 * @return boolean
	 */
	public boolean setMaxNumUserResponses(int nr) {
		if(nr <= numResponses) {
			maxNumUserResponses = nr;
			return true;
		} else {
			return false;
		}
	}
	
	/**
	 * Adds a user response to the userResponseList
	 * @param response
	 */
	public void addUserResponse(CAR response) {
		if(userResponseList.size() < maxNumUserResponses) {
			userResponseList.add(response);
		}
	}
	
	/**
	 * Clear User response after survey is filled out to retake survey
	 */
	public void clearUserResponse() {
		userResponseList.clear();
	}

	//~~~~~~~~~~~~~ GETTERS ~~~~~~~~~~~~~
	/**
	 * Returns the question Prompt
	 * @return Prompt
	 */
	public Prompt getPrompt() {
		return prompt;
	}
	
	/**
	 * Returns the number of user responses entered
	 * @return int
	 */
	public int getNumUserResponses() {
		return userResponseList.size();
	}
	
	/**
	 * Returns the number of responses
	 * @return int
	 */
	public int getNumResponses() {
		return numResponses;
	}
	
	/**
	 * Returns a response at index i
	 * @param i
	 * @return CAR
	 */
	public CAR getResponse(int i) {
		return responseList.get(i);
	}
	
	/**
	 * Returns the responseList
	 * @return Vector<CAR>
	 */
	public Vector<CAR> getResponseList() {
		return responseList;
	}
	
	/**
	 * Returns the userResponseList
	 * @return Vector<CAR>
	 */
	public Vector<CAR> getUserResponseList() {
		return userResponseList;
	}
	
	/**
	 * Returns the maximum allowed user responses
	 * @return
	 */
	public int getMaxNumUserResponses() {
		return maxNumUserResponses;
	}
	
	//~~~~~~~~~~~~~~~ ANSWER METHODS ~~~~~~~~~~~~~~~~
	
	/**
	 * Validate user input 
	 * @return boolean
	 */
	public boolean validateInput(int i) {
		if(i < 1 || i > numResponses) {
			return false;
		} else {
			return true;	
		}
	}
	
	public int getInput() {
		Scanner in = new Scanner(System.in);
		int i = 0;
		while(!validateInput(i)) {
			Output.getOutput(outputType).displayString("Enter question response: ");
			try {
				i = in.nextInt();
			} catch(InputMismatchException e) {
				Output.getOutput(outputType).displayString("Input must be integer" + "\n");
				in.next();
				continue;
			}
			if(!validateInput(i)) {
				Output.getOutput(outputType).displayString("Input must be between 1 and " + numResponses + "\n");
			}
		}
		return i;
	}
	
	/**
	 * Allow user to enter input to answer question
	 * overridden in subclasses
	 */
	public void answerQuestion() {
		
	}
	
	//~~~~~~~~~~~~~ DISPLAY ~~~~~~~~~~~~~
	
	/**
	 * Displays a Question
	 * overridden in subclasses
	 */
	public void display() {
		
	}
}
