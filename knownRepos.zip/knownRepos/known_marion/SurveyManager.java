package surveyTestPackage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.Vector;

import ioPackage.Output;
import questionPackage.CAR;
import questionPackage.Essay;
import questionPackage.IntCAR;
import questionPackage.Matching;
import questionPackage.MultipleChoice;
import questionPackage.Question;
import questionPackage.Ranking;
import questionPackage.ShortAnswer;

public class SurveyManager {
	private String fileName;
	private int maxResults;
	String outputType;
	
	/**
	 * Creates a new SurveyManager
	 * @param output
	 */
	public SurveyManager(String outputType) {
		this.outputType = outputType;
		maxResults = 100;
	}
	
	public void fillOut(Survey survey) {
		survey.fillOut();
		this.save(survey);
	}
	
	/**
	 * Removes illegal characters from filenames
	 * @param s
	 * @return String
	 */
	public String stripForFilePath(String s) {
		s = s.replaceAll("[^a-zA-Z0-9.-]", "_");
		return s;
	}
	
	/**
	 * Saves a survey using serialization
	 * Returns the String filepath
	 * @param survey
	 * @return String
	 */
	public String save(Survey survey) {
		String filePathPrefix = "SavedSurveys";
		String author = stripForFilePath(survey.getAuthor());
		String title = stripForFilePath(survey.getTitle());
		// Get type of survey for file extension 
		String type;
		if(survey instanceof Test) {
			type = "test";
		} else {
			type = "survey";
		}
		
		// If the survey has been filled out, add Results to the end of the file extension
		// Ex: testResults, surveyResults
		if(survey.isFilledOut()) {
			type += "Results";
		}
		
		// File Addresses are formatted: /Author/Title.type
		String filePath = filePathPrefix + "/" + author + "/";
		String fileName = title;
		String extension = "." + type;
		
		// If the file path doesn't exist, create it
		File directory = new File(filePath);
		if(!directory.exists()) {
			try {
				directory.mkdirs();
			} catch (SecurityException e){
				e.printStackTrace();
			}
		}
		
		// If saving results, don't overwrite previous results file
		if(survey.isFilledOut()) {
			File file;
			// The for loop runs 100 times as the max number of times a survey can be taken
			for(int i = 0; i < maxResults; i++) {
				file = new File(filePath + fileName + i + extension);
				if(!file.exists()) {
					// If the file with the given name doesn't exist
					// Append the number to the filename and break
					fileName += i;
					break;
				}
			}
		}

		// Serialization 
		try {
			FileOutputStream fileOut = new FileOutputStream(filePath + fileName + extension);
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(survey);
			out.close();
			fileOut.close();
			Output.getOutput(outputType).displayString(type + " was saved to " + filePath + fileName + extension + "\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return filePath;
	}
	
	/**
	 * Loads a Survey using serialization
	 * Returns the Survey
	 * @param filePath
	 * @return Survey
	 */
	public Survey load(String filePath) {
		Survey survey = null;
		try {
			FileInputStream fileIn = new FileInputStream(filePath);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			survey = (Survey) in.readObject();
			in.close();
			fileIn.close();
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
		}
		return survey;
	}
	
	public void tabulate(Survey survey) {
		Vector<Survey> results = loadResults(survey);
		for(int i = 0; i < survey.getNumQuestions(); i++) {		// For each question in the survey
			
			// Enter method if question is not Essay
			// Essay questions do not tabulate answers, they just display each essay
			// -------------------------- MultipleChoice, TrueFalse, ShortAnswer, or Matching -------------------------- 
			if(!(survey.getQuestion(i) instanceof Essay) && !(survey.getQuestion(i) instanceof Ranking)|| survey.getQuestion(i) instanceof ShortAnswer) {
				// Create a HashMap to store response counts and initialize all values to 0
				HashMap<String, Integer> responseCounts = new HashMap<String, Integer>();
				
				if(survey.getQuestion(i) instanceof MultipleChoice) {
					// If the question is multiple choice pre load all possible answers to responseCounts
					Vector<CAR> responseList = survey.getQuestion(i).getResponseList();
					for(int j = 0; j < responseList.size(); j++) {
						responseCounts.put(responseList.get(j).getResponse().toString(), 0);
					}
				}

				// Iterate through survey responses to specified question counting number of times response is reported
				for(Survey resultSurvey : results) {	// For each survey in the results
					Vector<CAR> userResponses = resultSurvey.getQuestion(i).getUserResponseList();
					for(CAR userResponse : userResponses) {		// For each response in each question
						// Get the specified response and add 1 to the count
						if(responseCounts.containsKey(userResponse.getResponse().toString())) {
							responseCounts.put(userResponse.getResponse().toString(), responseCounts.get(userResponse.getResponse().toString())+1);
						} else {
							// Short Answer questions will not have added the user responses to the hashmap
							responseCounts.put(userResponse.getResponse().toString(), 1);
						}
					}
				}
				
				survey.getQuestion(i).getPrompt().display(outputType);
				for(String response : responseCounts.keySet()) {
					Output.getOutput(outputType).displayString(response + ": ");
					Output.getOutput(outputType).displayInt(responseCounts.get(response));
					Output.getOutput(outputType).displayString("\n");
				}
				Output.getOutput(outputType).displayString("\n");
	
			} else 	if(survey.getQuestion(i) instanceof Ranking) {
			// -------------------------- Ranking -------------------------- 
				// Create a hashmap to keep track of ranked order responses and the number of occurrences
				HashMap<Vector<String>, Integer> responseCounts = new HashMap<Vector<String>, Integer>();
				
				// For every survey add the response to a String vector
				for(Survey resultSurvey : results) {
					Vector<CAR> userResponses = resultSurvey.getQuestion(i).getUserResponseList();
					Vector<String> rankResponses = new Vector<String>();
					for(CAR userResponse : userResponses) {
						rankResponses.add(userResponse.getResponse().toString());
					}
					if(responseCounts.containsKey(rankResponses)) {
						// If the key already exists, increment by 1
						responseCounts.put(rankResponses, responseCounts.get(rankResponses) + 1);
					} else {
						// If the key doesn't exist, add it and set its count to 1
						responseCounts.put(rankResponses, 1);
					}
				}
				
				survey.getQuestion(i).getPrompt().display(outputType);
				for(Vector<String> rankResponses : responseCounts.keySet()) {
					// Display the number of occurrences 
					Output.getOutput(outputType).displayInt(responseCounts.get(rankResponses));
					Output.getOutput(outputType).displayString(") ");
					Output.getOutput(outputType).displayString("\n");
					// Display each response in order
					for(int j = 0; j < rankResponses.size(); j++) {
						Output.getOutput(outputType).displayString(rankResponses.get(j) + "\n");
					}
					Output.getOutput(outputType).displayString("\n");
				}
				Output.getOutput(outputType).displayString("\n");
				
			} else if(survey.getQuestion(i) instanceof Essay) {
			// -------------------------- Essay -------------------------- 
				// Iterate through survey responses to specified question counting number of times response is reported
				survey.getQuestion(i).getPrompt().display(outputType);
				for(Survey resultSurvey : results) {	// For each survey in the results
					Vector<CAR> userResponses = resultSurvey.getQuestion(i).getUserResponseList();
					for(CAR userResponse : userResponses) {		// For each response in each question
						userResponse.display(outputType);
						Output.getOutput(outputType).displayString("\n");
					}
				}
				Output.getOutput(outputType).displayString("\n");
			}
		}
	}
	
	public Vector<Survey> loadResults(Survey survey) {
		Vector<Survey> results = new Vector<Survey>();
		File directory = new File("SavedSurveys/" + survey.getAuthor() + "/");
		String resultsFileName = survey.getTitle();
		String patternString = resultsFileName + "[0-9]*";
		if(survey instanceof Test) {
			patternString += ".testResults";
		} else {
			patternString += ".surveyResults";
		}
		
		for(File file : directory.listFiles()) {
			if(file.getName().matches(patternString)) {
				results.add(this.load(file.getPath()));
			}
		}
		
		return results;
	}
}
