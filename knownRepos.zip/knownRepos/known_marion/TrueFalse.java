package questionPackage;

import java.io.Serializable;

import ioPackage.Output;

public class TrueFalse extends MultipleChoice implements Serializable {	
	/**
	 * Creates a new TrueFalse question
	 * Maximum number of user responses is always 1
	 * Response list is always set to true and false
	 */
	public TrueFalse(String outputType) {
		super(outputType);
		// Set the maximum number of user responses to 1
		super.maxNumUserResponses = 1;
		// Set the responseList to [True, False]
		StringCAR t = new StringCAR("True");
		StringCAR f = new StringCAR("False");
		super.responseList.add(t);
		super.responseList.add(f);
		super.numResponses = 2;
	}
	
	/**
	 * Creates a new TrueFalse question with a Prompt
	 * Maximum number of user responses is always 1
	 * Response list is always set to true and false
	 * @param prompt
	 */
	public TrueFalse(Prompt prompt, String outputType) {
		super(prompt, outputType);
		// Set the maximum number of user responses to 1
		super.maxNumUserResponses = 1;
		
		// Set the responseList to [True, False]
		BooleanCAR t = new BooleanCAR(true);
		BooleanCAR f = new BooleanCAR(false);
		super.responseList.add(t);
		super.responseList.add(f);
		super.numResponses = 2;
	}
	
	/**
	 * Cannot set a different number of user responses for TrueFalse Questions 
	 */
	public boolean setMaxNumUserResponses(int nr) {
		return false;
	}
	
	/**
	 * Cannot set a different number of responses for TrueFalse Question 
	 */
	public void setNumResponses(int numResponses) {
		Output.getOutput(outputType).displayString("Cant set num responses for true/false");
		super.numResponses = 2;
	}
}
