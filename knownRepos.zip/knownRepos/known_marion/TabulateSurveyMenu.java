package menuPackage;

import ioPackage.Output;
import surveyTestPackage.SurveyManager;
import surveyTestPackage.Test;

public class TabulateSurveyMenu extends Menu {
	private SurveyManager surveyManager;
	
	/**
	 * Creates a new TabulateSurveyMenu with an output and a survey manager
	 * @param outputType
	 */
	public TabulateSurveyMenu(String outputType) {
		super(outputType);
		surveyManager = new SurveyManager(outputType);
	}
	
	/**
	 * Runs the actions for the menu
	 * Tabulates the selected survey
	 */
	public Menu runMenu() {
		surveyManager.tabulate(survey);
		
		BackMenu back = new BackMenu(outputType);
		back.setSurvey(survey);
		return back;
		
	}

}
