package com.Benny.cs350;

import java.util.Arrays;

/**
 * This is an extension to the Question object. This is an object for a question where you rank each
 * item on a specified list
 * @author Benny Sitbon
 *
 */
public class Ranking extends Question{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String[] options;

	public Ranking(){
		super();
		SetOptions(createOptions());
	}
	public String[] getOptions() {
		return options;
	}
	public void SetOptions(String[] o) {
		options = o;
	}
	/**
	 * Prompts the user for the number of items in the list to be ranked, They must be 2 or more, up to 99.
	 * Sets the minimum number of answers to the size of the list, since user must rank all items.
	 * Then prompts the user for the items.
	 * @return
	 */
	public String[] createOptions(){
		Output.getInstance().displayMessage("How many items will be in the list?");
		setMinAnswerSize(DataValidation.getIntInputInRange(2, 99));
		setMaxAnswerSize(getMinAnswerSize());
		Output.getInstance().displayMessage(getCreateColumnPrompt());
		String[] options = DataValidation.getMultipleWordedAnswer("list item",getMinAnswerSize(),getMinAnswerSize(),false);
		return options;
	}
	/**
	 * Used to control having the right prompt when prompting the user, can be overridden in subclasses
	 * @return
	 */
	public String getCreateColumnPrompt(){
		return "Enter the items the user will rank, from top to bottom";
	}
	@Override
	public boolean[] modify(){
		boolean[] changed = {false,false};
		changed[0] = modifyPrompt();
		Output.getInstance().displayMessage("Do you wish to modify the list? Enter 1 for yes or 2 for no");
		int choice = DataValidation.getIntInputInRange(1, 2);
		if (choice==1){
			changed[1] =modifyOptions(); 
		}
		return changed;
		
	}
	/**
	 * Prompts the user to which list item s/he would like to change , and update the options array
	 * @return
	 */
	public boolean modifyOptions(){
		int choice =99;
		boolean changed = false;
		while(choice!=0){
			for(int i=0;i<options.length;i++){
				Output.getInstance().displayMessage((i+1)+")"+options[i]);
			}
			Output.getInstance().displayMessage("Which item would you like to change? Enter 0 to finish");
			choice = DataValidation.getIntInputInRange(0, options.length);
			if (choice!=0){
				String temp = DataValidation.getNonEmptyStringInput("Enter new list item to replace item "+choice);
				if(!(temp.equals(options[choice-1]))){
					changed = true;
				}
				options[choice-1] = temp;
			}
		}
		return changed;
	}
	@Override
	public void display(){
		Output.setType("tts");
		Output.getInstance().displayMessage(getPrompt());
		for (int i=0;i<options.length;i++){
			Output.getInstance().displayMessage((i+1)+")"+options[i]);
		}
		Output.setType("console");
	}
	
	@Override
	public Answer createCorrectAnswer() {
		Output.getInstance().displayMessage("\n-----Enter the correct ranking:-----\n");
		String[] ans = DataValidation.getMultipleNumericAnswer("ranking for item",getMinAnswerSize(),options.length, options.length,false);
		ans = ArrayMethods.selectionsToValues(ans,options);
		String[] asString = new String[1]; 
		asString[0] = Arrays.toString(ans);
		Answer answer = new Answer(asString);
		return answer;
	}
	@Override
	public Answer answerQuestion() {
		display();
		Output.getInstance().displayMessage("Rank each option in the list:" );
		String[] ans = DataValidation.getMultipleNumericAnswer("ranking for item",getMinAnswerSize(),options.length, options.length,false);
		ans = ArrayMethods.selectionsToValues(ans,options);
		String[] asString = new String[1]; 
		asString[0] = Arrays.toString(ans);
		Answer answer = new Answer(asString);
		return answer;
	}
}
