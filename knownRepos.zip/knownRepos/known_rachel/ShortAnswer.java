package com.Benny.cs350;

import java.util.Arrays;
/**
 * An extension to the Question object. This is a question where the user can enter multiple responses, via short sentences.
 * @author Benny Sitbon
 *
 */
public class ShortAnswer extends Question{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public ShortAnswer(){
		super();
		Output.getInstance().displayMessage("What is the MINIMUM # of answers you expect from the user for this question?");
		setMinAnswerSize(DataValidation.getIntInputInRange(1, 99));
		Output.getInstance().displayMessage("What is the MAXIMUM # of answers you expect from the user for this question?");
		setMaxAnswerSize(DataValidation.getIntInputInRange(getMinAnswerSize(), 99));
		
	}
	@Override
	public void display(){
		Output.setType("tts");
		Output.getInstance().displayMessage(getPrompt());
		Output.getInstance().displayMessage("");
		Output.setType("console");
	}
	@Override
	public boolean[] modify(){
		boolean[] changed = {false};
		changed[0] = modifyPrompt();
		return changed;
	}

	@Override
	public Answer createCorrectAnswer() {	
		Output.getInstance().displayMessage("\n-----Enter correct answer(s)-----\n");
		String[] answers;
		if(getMinAnswerSize()==getMaxAnswerSize()){//if an exact number of answers is expected 
			answers = DataValidation.getMultipleWordedAnswer("answer",getMinAnswerSize(),getMaxAnswerSize(),false);
		}
		else{
			answers = DataValidation.getMultipleWordedAnswer("answer",getMinAnswerSize(),getMaxAnswerSize(),true);
		}
		answers = DataValidation.arrayToUpper(answers);
		
		Arrays.sort(answers);
		Answer ans = new Answer(answers);
		return ans;
	}
	@Override
	public Answer answerQuestion() {
		display();
		String[] answers;
		if(getMinAnswerSize()==getMaxAnswerSize()){//if an exact number of answers is expected 
			answers = DataValidation.getMultipleWordedAnswer("answer",getMinAnswerSize(),getMaxAnswerSize(),false);
		}
		else{
			answers = DataValidation.getMultipleWordedAnswer("answer",getMinAnswerSize(),getMaxAnswerSize(),true);
		}
		answers = DataValidation.arrayToUpper(answers);
		Arrays.sort(answers);
		Answer ans = new Answer(answers);
		return ans;
	}
	
}
