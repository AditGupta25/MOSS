package com.Benny.cs350;

import java.util.Arrays;
/**
 * A static class thats in charge of every input data that should be validated for correctness
 * @author Benny Sitbon
 *
 */
public class DataValidation {
	
	/**
	 * Checks if input is in range, between bottomRange and topRange (inclusive)
	 *  return True if in range,False if not
	 * @param input
	 * @param bottomRange
	 * @param topRange
	 * @param io
	 * @return
	 */
	public static boolean inputInRange(int input,int bottomRange,int topRange){
		if ((bottomRange<=input)&& (input<=topRange)){
			return true;
		}
		return false;
	}
	/**
	 * Will prompt the user for a positive Integer and will return it
	 * Will keep prompting the user, until successful.
	 * @param io
	 * @return
	 */
	public static int getPositiveInteger(){
		int i = -1;
		while (i<0){
			i = Input.getInstance().getInteger();
			if (i<0){
				Output.getInstance().displayMessage("Please Enter a Positive Integer");
			}
		}
		return i;
	}
	/**
	 * Validates that a specific String value is indeed an integer
	 * @param input
	 * @return
	 */
	public static boolean isInteger(String input){
		try{
			Integer.parseInt(input);
			return true;
		}
		catch(Exception e){
			return false;
		}
	}
	
	/**
	 * Will prompt the user for an integer between the bottomRange and topRange (inclusive)
	 * validate that it is legal, and return the integer
	 * Will keep prompting the user, until successful.
	 * @param bottomRange
	 * @param topRange
	 * @param io
	 * @return
	 */
	public static int getIntInputInRange(int bottomRange,int topRange){
		boolean success = false;
		int returnInput = 100;
		while(!success){
			Output.getInstance().displayMessage("Enter a number between "+bottomRange+" and "+topRange);
			int tempNum = Input.getInstance().getInteger();
			if (inputInRange(tempNum,bottomRange,topRange)){
				success= true;
				returnInput = tempNum;
			}else{
				Output.getInstance().displayMessage("Not in Range or invalid,Try again");
			}
		}
		return returnInput;
	}
	/**
	 * Will prompt the user for a string, validate that it is not empty, and return it.
	 * Will keep prompting the user, until successful.
	 * @param prompt
	 * @param io
	 * @return
	 */
	public static String getNonEmptyStringInput(String prompt){
		String tempInput ="";
		while((tempInput.equals(null)) || (tempInput.equals(""))){
			Output.getInstance().displayMessage(prompt);
			tempInput = Input.getInstance().getString().trim();
			String checkSpaces = tempInput.replaceAll("\\s+", "");
			if((tempInput.equals("") || (tempInput.equals(null))||(checkSpaces.equals("")))){
				Output.getInstance().displayMessage("Invalid input");
			}
		}
		return tempInput;
	}
	/**
	 * Will prompt the user for a number of integer inputs (at least as many as minSize indicates) but 
	 * no more that maxSize, the options will range from 1 to topRange, zeroForExit decides if to give
	 * the option to stop upon a "0" input
	 * the method Will keep prompting the user, until successful.
	 * @param inputType
	 * @param minSize
	 * @param maxSize
	 * @param topRange
	 * @param zeroForExit
	 * @param io
	 * @return
	 */
	public static String[] getMultipleNumericAnswer(String inputType,int minSize,int maxSize,int topRange,boolean zeroForExit){
		String input= "";
		int counter = 0;
		int minRange = 0;
		String finisher =",or enter 0 when finished";
		if (!zeroForExit){
			minRange=1;
			finisher="";
		}
		String[] temp = new String[maxSize];
		
		while(!(input.equals("0"))){
			Output.getInstance().displayMessage("Enter "+inputType+" #"+(counter+1) + finisher);
			input = String.valueOf(getIntInputInRange(minRange,topRange)).trim();
			if (!(input.equals("0"))){
				if(!checkIfExistsInArray(temp,input)){
					temp[counter] = input;
					counter++;
				}
				else{
					Output.getInstance().displayMessage(inputType+" already exist, enter a different one and try again");
				}	
			}
			else {
				if(!zeroForExit){
					if(!checkIfExistsInArray(temp,input)){
						temp[counter] = input;
						counter++;
					}
					else{
						Output.getInstance().displayMessage(inputType+" already exist, enter a different one and try again");
					}
				}
			}
			if (counter>=maxSize){
				input="0";
			}
			if(input.equals("0")&&counter<minSize){
				Output.getInstance().displayMessage("You must enter at least "+minSize+" answer(s)");
				input = "na";
			}
		}
		String[] returnArray = Arrays.copyOfRange(temp, 0, counter);
		return returnArray;
	}
	/**
	 * Checks if a string is acceptable file name according the Windows OS accepted filenames.
	 * @param input
	 * @return
	 */
	public static boolean checkStandardFileNameInput(String input){
		String temp = input.replaceAll("[\\s+/:<>*?\"|]+", "");
		if (temp.equals(input)){
			return true;
		}
		else{
			return false;
		}
	}
	/**
	 * Will get a accepted file name input from the user, according to standard Windows OS accepted filenames.
	 * Will keep prompting the user, until successful.
	 * @param prompt
	 * @param io
	 * @return
	 */
	public static String getStandardizedFileNameInput(String prompt){
		String input="/";
		while (!(checkStandardFileNameInput(input))){
			input = getNonEmptyStringInput(prompt+"\nInput cannot include \\,/,:,<,>,*,?,\",| or spaces");
		}
		return input;
	}
	/**
	 * Will prompt the user for multiple String inputs, there must be at least as many as minSize inputs
	 * and as many as maxSize inputs. zeroForExit decides if to give the option to stop upon a "0" input.
	 * The method will keep prompting the user, until successful.
	 * @param inputType
	 * @param minSize
	 * @param maxSize
	 * @param zeroForExit
	 * @param io
	 * @return
	 */
	public static String[] getMultipleWordedAnswer(String inputType,int minSize,int maxSize,boolean zeroForExit){
		String input= "";
		int counter = 0;
		String finisher = ", or enter 0 when finished";
		if (!zeroForExit){
			finisher="";
		}
		String[] temp = new String[maxSize];
		while(!(input.equals("0"))){
			input = getNonEmptyStringInput("Enter "+inputType+" #"+(counter+1) + finisher);
			if (!(input.equals("0"))){			
				if(!checkIfExistsInArray(temp,input)){
					temp[counter] = input.trim();
					counter++;
				}
				else{
					Output.getInstance().displayMessage(inputType+" already exist, enter a different one and try again");
				}
			}
			else {
				if(!zeroForExit){
					if(!checkIfExistsInArray(temp,input)){
						temp[counter] = input.trim();
						counter++;
					}
					else{
						Output.getInstance().displayMessage(inputType+" already exist, enter a different one and try again");
					}
				}
			}
			if(input.equals("0")&&counter<minSize&&zeroForExit){
				Output.getInstance().displayMessage("You must enter at least "+minSize+" answer(s)");
				input = "na";
			}
			if(input.equals("0")&&(!zeroForExit)){
				input="na";
			}
			if (counter>=maxSize){
				input="0";
			}
		}
		String[] returnArray = Arrays.copyOfRange(temp, 0, counter);
		return returnArray;
		
	}
	/**
	 * A helper method that checks if a specific string value exists in a string array
	 * @param arr
	 * @param value
	 * @return
	 */
	public static boolean checkIfExistsInArray(String[] arr,String value){
		boolean exist= false;
		for (int i=0;i<arr.length;i++){
			if(arr[i]!=null){
				if(arr[i].equals(value)){
					exist = true;
				}
			}
		}
		return exist;
	}
	/**
	 * Changes a String array to upper class 
	 * @param s
	 * @return
	 */
	public static String[] arrayToUpper(String[] s){
		for (int i=0;i<s.length;i++){
			s[i] = s[i].toUpperCase();
		}
		return s;
	}
}
