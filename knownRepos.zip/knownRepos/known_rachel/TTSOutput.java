package com.Benny.cs350;
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;

public class TTSOutput extends Output{
	private static String voiceName = "kevin16";
	private static Voice voice;
	private static Output instance;
	
	private TTSOutput() {
		VoiceManager voiceManager = VoiceManager.getInstance();
        voice = voiceManager.getVoice(voiceName);
        voice.allocate();
	}
	
	public static Output getInstance(){
		if (instance==null) instance=new TTSOutput();
		return instance;
	}
	@Override
	public void displayMessage(String msg) {
		
	    voice.speak(msg);
	    //voice.deallocate();
		
	}
	
}
