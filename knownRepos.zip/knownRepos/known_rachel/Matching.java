package com.Benny.cs350;

import java.util.Arrays;

/**
 * An extension to the Ranking object. it is a Question of matching, where there are two columns
 * and the testee should state which one on the options(left) columns belong with what on the matching(right) column
 * @author Benny Sitbon
 *
 */
public class Matching extends Ranking{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String[] matchingOptions;
	
	public Matching(){
		super();
		setMatchingOptions(createMatchingOptions());
	}
	@Override
	public boolean[] modify(){
		boolean[] changed = super.modify();		
		int choice =99;
		Output.getInstance().displayMessage("Would you like to change the match-to list? Enter 1 for yes or 2 for no");
		int decision = DataValidation.getIntInputInRange(1, 2);
		if(decision==1){
			while(choice!=0){
				for(int i=0;i<matchingOptions.length;i++){
					Output.getInstance().displayMessage((i+1)+")"+matchingOptions[i]);
				}
				Output.getInstance().displayMessage("Which item would you like to change? Enter 0 to finish");
				choice = DataValidation.getIntInputInRange(0, matchingOptions.length);
				if (choice!=0){
					String temp = DataValidation.getNonEmptyStringInput("Enter new list item to replace item "+choice);
					if(!temp.equals(matchingOptions[choice-1])){
						changed[1] = true;
					}
					matchingOptions[choice-1] = temp;
				}
			}
		}
		return changed;		
	}
	public void setMatchingOptions(String[] opts){
		matchingOptions = opts;
	}
	
	public String[] getMatchingOptions() {
		return matchingOptions;
	}
	/**
	 * Creates the "right" column, the list which will be matched to, and return it as String[]
	 * @return
	 */
	public String[] createMatchingOptions(){
		Output.getInstance().displayMessage("Enter the list items the user will match TO, from top to bottom");
		String[] opts = DataValidation.getMultipleWordedAnswer("list item",getMinAnswerSize(),getMinAnswerSize(),false);
		return opts;
	}
	@Override
	public void display(){
		Output.setType("tts");
		Output.getInstance().displayMessage(getPrompt());
		for (int i=0;i<getOptions().length;i++){
			Output.getInstance().displayMessage((i+1)+")"+getOptions()[i]);
		}
		Output.getInstance().displayMessage("Match to");
		for (int j=0;j<getOptions().length;j++){
			Output.getInstance().displayMessage((j+1)+")"+matchingOptions[j]);
		}
		Output.setType("console");
	}
	@Override
	public String getCreateColumnPrompt(){
		return "Enter the items that the user will be matching FROM, from top to bottom";
	}
	@Override
	public Answer createCorrectAnswer() {
		Output.getInstance().displayMessage("\n-----Enter the correct matching:-----\n");
		String[] ans = DataValidation.getMultipleNumericAnswer("matching for item",getMinAnswerSize(),getMinAnswerSize(), getMinAnswerSize(),false);
		String[] temp = concatArraysValues(getOptions(),ArrayMethods.selectionsToValues(ans,matchingOptions));
		String[] asString = new String[1]; 
		asString[0] = Arrays.toString(temp);
		Answer answer = new Answer(asString);
		return answer;
	}
	@Override
	public Answer answerQuestion() {
		display();
		Output.getInstance().displayMessage("Match each item in the left coloumn with an item in the right column" );
		String[] ans = DataValidation.getMultipleNumericAnswer("matching for item",getMinAnswerSize(),getOptions().length, getOptions().length,false);
		String[] temp = concatArraysValues(getOptions(),ArrayMethods.selectionsToValues(ans,matchingOptions));
		String[] asString = new String[1]; 
		asString[0] = Arrays.toString(temp);
		Answer a = new Answer(asString);
		return a;
	}
	/**
	 * Takes two arrays and make the parallel elements in them into one separated by ":", then 
	 * returns the response as an array
	 * @param a
	 * @param b
	 * @return
	 */
	private String[] concatArraysValues(String[] a, String[] b){
		String[] ret = null;
		if (a.length==b.length){
			ret = new String[a.length];
			for(int i=0;i<a.length;i++){
				ret[i] = a[i]+":"+b[i];
			}
		}
		return ret;
	}
}
