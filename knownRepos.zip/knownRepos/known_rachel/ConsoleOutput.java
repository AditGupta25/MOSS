package com.Benny.cs350;

public class ConsoleOutput extends Output{
	
	private static ConsoleOutput instance;
	private ConsoleOutput(){}
	
	public static Output getInstance(){
		if (instance==null) instance=new ConsoleOutput();
		return instance;
	}
	@Override
	public void displayMessage(String msg){
		System.out.println(msg);
	}


}
