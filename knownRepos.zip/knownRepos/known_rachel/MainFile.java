package com.Benny.cs350;

import java.io.File;
import java.util.Scanner;
public class MainFile {
	private static String[] options = {"Create a new Survey","Create a new Test","Display currently loaded Survey/Test",
		"Load a Survey","Load a Test","Save currently loaded Survey/Test","Modify a Survey","Modify a Test","Take a Survey",
		"Take a Test","Grade a Test","Tabulate a Survey/Test","Quit"};
	private static Survey currentSurvey;
	//private static ConsoleIO io = new ConsoleIO();
	private static SaveLoad sl =new SaveLoad();
	
	public static void main(String[] args) {
		Input.setType("console");
		Output.setType("console");
		boolean on = true;
		while (on ==true){
			handleMenu();
		}
		Scanner s = new Scanner(System.in); //used to close the scanner stream
		s.close();
	}
	
	/**Handles the input from the user regarding the menu, uses a switch statement that check by string instead of 
	 * option number. This will make it easier to add option to the menu and check them(not necessary to shift all)
	 * WORKS ONLY ON JAVA 1.7 AND UP!
	 */
	private static void handleMenu(){
		Output.getInstance().displayMessage("\n******************************");
		Output.getInstance().displayMessage("*Welcome to SurveyMaker 3000!*");
		Output.getInstance().displayMessage("******************************\n");
		if(currentSurvey==null){
			Output.getInstance().displayMessage("No Survey/Test currently in memory\n");
		}
		else{
			//The substring is used to get rid of the T_ or S_ prefix
			Output.getInstance().displayMessage("Current Survey/Test:"+currentSurvey.getName().substring(2)+"\n");
		}
		for (int i=1;i<=options.length;i++){
			//Output.setType("tts");
			Output.getInstance().displayMessage(String.valueOf(i)+")"+options[i-1]);
			
		}
		//Output.setType("console");
		Output.getInstance().displayMessage("");
		String option = options[DataValidation.getIntInputInRange(1, options.length)-1];
		switch(option){
			//Cases to create a survey/test, will save the test/survey after creation
			case "Create a new Survey":{
				Survey sur = new Survey();
				currentSurvey = sur;
				sl.save(sur);
				break;
			}
			case "Create a new Test":{
				Test test = new Test();
				currentSurvey = test;
				sl.save(test);
				break;
			}
			//Cases for displaying currently loaded survey/test
			case "Display currently loaded Survey/Test":{
				if (currentSurvey!=null){
					currentSurvey.display();
				}else{
					Output.getInstance().displayMessage("Error: No Survey/Test in memory\nLoad a Survey/Test first, then try again\n");
				}
				break;
			}
			//A feature that might be used in the future, I created it to play around with the singleton pattern
			case "Print survey to file":{
				if(currentSurvey!=null){
					Input.setType("textout");
					currentSurvey.display();
					Input.setType("console");
				}else{
					Output.getInstance().displayMessage("Error: No Survey/Test in memory\nLoad a Survey/Test first, then try again\n");
				}
				break;
			}
			//Cases for loading a survey/test
			case "Load a Survey":{
				String name = DataValidation.getNonEmptyStringInput("Enter Survey name to load");
				Survey temp = sl.load("S_"+name);
				if (temp!=null){
					currentSurvey=temp;
				}
				break;
			}
			case "Load a Test":{
				String name = DataValidation.getNonEmptyStringInput("Enter Test name to load");
				Test temp =  (Test) sl.load("T_"+name);
				if( temp != null){
					currentSurvey = temp;
				}					
				break;
			}
			//Cases for saving a survey/test
			case "Save currently loaded Survey/Test":{
				if (currentSurvey!=null){
					sl.save(currentSurvey);
				}
				else{
					Output.getInstance().displayMessage("Error in Saving: No Survey/Test currently in memory\n");
				}
				break;
			}
			//Cases for modifying an survey/test, will clean the survey from memory after modifying
			case "Modify a Survey":{
				Output.getInstance().displayMessage("WARNING: ANY CHANGE TO THE SURVEY WILL LEAD TO DELETION OF ALL ANSWER SHEETS");
				String name = DataValidation.getNonEmptyStringInput("Enter Survey name to modify");
				Survey temp = sl.load("S_"+name);
				if (temp!=null){
					boolean[] changed = temp.modify();
					if (changed[0]||changed[1]){
						deleteAnswerSheets(temp);
					}
					sl.save(temp);
					currentSurvey=null;
				}
				break;
			}
			case "Modify a Test":{
				Output.getInstance().displayMessage("WARNING: ANY CHANGE TO THE SURVEY WILL LEAD TO DELETION OF ALL ANSWER SHEETS");
				String name = DataValidation.getNonEmptyStringInput("Enter Test name to modify");
				Survey temp = sl.load("T_"+name);
				if (temp!=null){
					boolean[] changed = temp.modify();
					if (changed[0]||changed[1]){
						deleteAnswerSheets(temp);
					}
					sl.save(temp);
					currentSurvey=null;
				}
				break;
			}
				
			//Cases for taking a survey/test
			case "Take a Survey":{
				String name = DataValidation.getNonEmptyStringInput("Enter Survey name to load");
				Survey temp = sl.load("S_"+name);
				if( temp != null){
					temp.take();
				}
				break;
				
			}
			case "Take a Test":{
				String name = DataValidation.getNonEmptyStringInput("Enter Test name to load");
				Test temp =  (Test) sl.load("T_"+name);
				if( temp != null){
					temp.take();
				}
				break;
			}
			//Case for grading a test
			case "Grade a Test":{
				if (currentSurvey!=null){
					Test t = null;
					try{
						t = (Test)currentSurvey;
					}
					catch(Exception e){
						Output.getInstance().displayMessage("Error: This is not a test, load a test and try again");
					}
					if(t!=null){
						Output.getInstance().displayMessage("Enter the name of the testee");
						String name = Input.getInstance().getString();
						AnswerSheet as =sl.loadAnswerSheet(name.replaceAll("\\s+", ""),currentSurvey.getName());
						if(as!=null){
							t.gradeTest(as);
						}
					}
				}
				else{
					Output.getInstance().displayMessage("Error: No Test in memory\nLoad a Test first into memory, then try again\n");
				}
				break;
			}
			//Case for tabulating a test
			case "Tabulate a Survey/Test":{
				if(currentSurvey!=null){
					currentSurvey.tabulate();
				}
				else{
					Output.getInstance().displayMessage("Error: No Survey/Test in memory\nLoad a Survey/Test first into memory, then try again\n");
				}
				break;
			}
			
			case "Quit":{
				System.exit(0);
				break;
			}					
		
	
		}
	}
	/**
	 * Deletes all answer sheets for a specific survey
	 * @param sur
	 */
	private static void deleteAnswerSheets(Survey sur){
		String workingDir = System.getProperty("user.dir");
		String path = workingDir+"/sur/Answers/"+sur.getName();
		File folder = new File(path);
		for(File file: folder.listFiles()) file.delete();
		Output.getInstance().displayMessage("All answer sheets deleted");
	}
}
