package com.Benny.cs350;

import java.util.Arrays;
/**
 * A extension to the Quesion Class, this class handles multiple choice questions, which have
 * an array of choices to choose from.
 * @author Benny Sitbon
 *
 */
public class Multi extends Question implements java.io.Serializable{
	
	private static final long serialVersionUID = 1L;
	protected String[] choices;

	
	public Multi(){
		super();
		setChoices();
	}
	/**
	 * Prompts the user for number of question, then gets the different choices and sets them in the respected
	 * array.
	 * Will also set the minimum number of answers expected from the user.
	 */
	protected void setChoices(){
		Output.getInstance().displayMessage("How many choices will the question have?");
		int size = DataValidation.getPositiveInteger();
		choices = DataValidation.getMultipleWordedAnswer("choice", size, size, false);
		setMinMaxAnswers(size);
	}

	@Override
	public void display(){
		Output.setType("tts");
		Output.getInstance().displayMessage(getPrompt());
		for(int i=0;i<choices.length;i++){
			Output.getInstance().displayMessage((i+1)+") "+choices[i]);
		}
		Output.getInstance().displayMessage("");
		Output.setType("console");
	}

	/**Displaying the question and collect the answer from the user and returns it*/
	@Override
	public Answer createCorrectAnswer() {
		Output.getInstance().displayMessage("\n-----Enter Correct Answer(s)-----\n");
		String[] tempAnswer;
		if (getMinAnswerSize()==getMaxAnswerSize()){ //If the admin is expecting a specific number of answers, don't let user to quit
			tempAnswer = DataValidation.getMultipleNumericAnswer("answer",getMinAnswerSize(),getMaxAnswerSize(), choices.length,false);
		}
		else {
			tempAnswer = DataValidation.getMultipleNumericAnswer("answer",getMinAnswerSize(),getMaxAnswerSize(), choices.length,true);
		}
		String[] answer = ArrayMethods.selectionsToValues(tempAnswer,choices);
		Arrays.sort(answer);
		Answer ans = new Answer(answer);
		return ans;
	}
	@Override
	public Answer answerQuestion() {
		display();
		String[] tempAnswer;
		if (getMinAnswerSize()==getMaxAnswerSize()){ //If an exact number of answers is expected
			tempAnswer = DataValidation.getMultipleNumericAnswer("answer",getMinAnswerSize(),getMaxAnswerSize(), choices.length,false);
		}
		else {
			tempAnswer = DataValidation.getMultipleNumericAnswer("answer",getMinAnswerSize(),getMaxAnswerSize(), choices.length,true);
		}
		String[] answers = ArrayMethods.selectionsToValues(tempAnswer,choices);
		Arrays.sort(answers);
		Answer ans = new Answer(answers);
		return ans;
	}
	/**
	 * Will modify the choices of the MC. return true if anything was changed or false if not
	 * @return
	 */
	public boolean modifyChoices(){
		int choice =99;
		boolean change = false;
		while(choice!=0){
			display();
			Output.getInstance().displayMessage("Which choice would you like to change? Enter 0 to finish");
			choice = DataValidation.getIntInputInRange(0, choices.length);
			if (choice!=0){
				change = true;
				String temp = DataValidation.getNonEmptyStringInput("Enter choice to replace option "+choice);
				choices[choice-1] = temp;
			}
		}
		return change;
	}
	/**
	 * Removes and adds choices for this question
	 * @return
	 */
	public boolean addRemoveChoices(){
		int choice =99;
		boolean change = false;
		while(choice!=0){
			display();
			Output.getInstance().displayMessage("Would you like to:\n 1)Add a choice     2)Remove a choice     0) Exit add/remove menu");
			choice = DataValidation.getIntInputInRange(0, 2);
			if (choice==1){
				change = true;
				String temp = DataValidation.getNonEmptyStringInput("Enter a new choice to add");
				choices=ArrayMethods.addToArray(choices, temp);
			}
			else{
				if (choice==2){		
					Output.getInstance().displayMessage("Which choice would you like to remove? Enter 0 to cancel");
					choice = DataValidation.getIntInputInRange(0, choices.length);
					if(choice!=0){
						if(choices.length>2){
							change = true;
							choices = ArrayMethods.removeIndex(choices, choice-1);
						}
						else{
							Output.getInstance().displayMessage("----ERROR removing choice: Cannot have less than 2 choices----");
						}
					}
					else{
						choice = -99;
					}
				}
			}
		}
		return change;
	}
	@Override
	public boolean[] modify() {
		boolean[] changed = {false,false};
		changed[0] = modifyPrompt();
		Output.getInstance().displayMessage("Do you wish to add/remove choices? Entere 1 for yes or 2 for no");
		int choice = DataValidation.getIntInputInRange(1, 2);
		if (choice==1){
			if(addRemoveChoices()){
				changed[1]= true;
			}
		}
		Output.getInstance().displayMessage("Do you wish to modify the choices? Enter 1 for yes or 2 for no");
		choice = DataValidation.getIntInputInRange(1, 2);
		if (choice==1){
			if(modifyChoices()){
				changed[1]=true;
			}
		}
		if(changed[1]==true){
			setMinMaxAnswers(choices.length);
		}
		return changed;
	}
	/**
	 * A helper method for the multiple choice class. A maximum size is passed to it, and it 
	 * will prompt the user to set the minimum and maximum number of answers for the question
	 * and set them
	 * @param maxNum
	 */
	private void setMinMaxAnswers(int maxNum){
		Output.getInstance().displayMessage("What is the MINIMUM # of answers you expect from the user for this question?");
		setMinAnswerSize(DataValidation.getIntInputInRange(1, (maxNum-1)));
		Output.getInstance().displayMessage("What is the MAXIMUM # of answers you expect from the user for this question?");
		setMaxAnswerSize(DataValidation.getIntInputInRange(getMinAnswerSize(), maxNum));
	}
}
