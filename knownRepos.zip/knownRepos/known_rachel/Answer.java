package com.Benny.cs350;

/**
 * The class which holds the answer for a question.
 * @author Benny Sitbon
 *
 */
public class Answer implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String[] answer;
	
	public Answer(String[] ans){
		setAnswer(ans);	
	}
	 
	public String[] getAnswer(){
		return answer;
	}
	public void setAnswer(String[] ans){
		answer=ans;
	}
}
