package com.Benny.cs350;
/**
 * An abstract singleton used to access the different types of input/output
 * that will be available with the program 
 * @author Benny Sitbon
 *
 */
abstract public class Input {
	
	static private Input instance;
	static private String type = "console";
	protected Input() {};
	
	abstract int getInteger();
	abstract String getString();
	//abstract void displayMessage(String msg);
	/**
	 * Chooses the kind of singleton to return/instantiate according to the variable "type"
	 * @return
	 */
	public static Input getInstance(){
		if(type=="console"){
			instance = ConsoleInput.getInstance();
		}
		/*else if(type=="textout"){
			instance =TextoutIO.getInstance();
		}*/
		return instance;
	}
	
	public static void setType(String str){
		type = str;
	}

}
