package com.Benny.cs350;


/**
 * An extension to the Survey class. Keeps an correct answer key, can grade user answers.
 * @author Benny Sitbon
 *
 */
public class Test extends Survey {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Answer[] answerKey;
	
	public Test(){
		super();
		
	}
	/**
	 * Displays the test.
	 * Will query the user if the correct answers to the questions are to be displayed as well
	 */
	public void display(){
		Output.getInstance().displayMessage("Would you like to see the answers along with the test? enter 1 for yes or 2 for no");
		int choice = DataValidation.getIntInputInRange(1, 2);
		if(choice==1){
			displayWithAnswers();
		}
		else{
			displayQuestions();
		}
	}
	/**
	 * Displays the test with the answers
	 */
	public void displayWithAnswers(){
		for (int i=0;i<getQuestionArray().length;i++){
			Output.getInstance().displayMessage("--------------------------------------");
			Output.getInstance().displayMessage("Question "+(i+1)+"\n");
			getQuestionArray()[i].display();
			if (answerKey[i]!=null){
				Output.getInstance().displayMessage("Correct Answer(s):");
				String[] s =  answerKey[i].getAnswer();
				for(int j=0;j<s.length;j++){
					Output.getInstance().displayMessage(s[j]);
				}
			}
		}
	}
	
	public Answer[] getAnswerKey() {
		return answerKey;
	}

	public void setAnswerKey(Answer[] ans) {
		answerKey = ans;
	}
	/**
	 * Used to change the name the user input into a standardized file name, to ease loading and saving
	 * and prevent duplications and overwrites between tests and surveys.
	 */
	public String standardizeName(String name){
		name= "T_"+name;
		return name;	
	}
	/**
	 * Handles the creation of the Question array, will prompt for the number of Questions,
	 * Display the menu, and will create the question according to choice
	 */
	@Override
	public Question[] createQuestionArray(){
		Output.getInstance().displayMessage("How many questions will the test have?");
		//Scanner s = new Scanner(System.in);
		int numQuestions = DataValidation.getPositiveInteger();
		answerKey = new Answer[numQuestions];//see if you can somehow implement this in the constructor
		Question[] qa = new Question[numQuestions];
		for (int i=0;i<numQuestions;i++){
			displayQuestionPickMenu(getMenuOptions());
			String choice = getMenuOptions()[DataValidation.getIntInputInRange(1, getMenuOptions().length)-1];
			qa[i] = createQuestion(choice,i);
		}
		return qa;
	}
	
	/** Create the Question object selected and passed into this method and its corresponding
	 * Answer and inserts it into the answer key. 
	 * */
	protected Question createQuestion(String choice,int indexInArray){
		Output.getInstance().displayMessage("You Chosen "+choice);
		Output.getInstance().displayMessage("");
		switch (choice){
			case "True/False":
				TF tf = new TF();
				answerKey[indexInArray] = tf.createCorrectAnswer();
				return tf;
			case "Multiple Choice":
				Multi mul = new Multi();
				answerKey[indexInArray]=mul.createCorrectAnswer();
				return mul;
			case "Essay":
				Essay es = new Essay();
				answerKey[indexInArray] = es.createCorrectAnswer();
				return es;
			case "Short Answer":
				ShortAnswer sa = new ShortAnswer();
				answerKey[indexInArray] = sa.createCorrectAnswer();
				return sa;
			case "Matching":
				Matching ma = new Matching();
				answerKey[indexInArray] = ma.createCorrectAnswer();
				return ma;
			case "Ranking":
				Ranking ra = new Ranking();
				answerKey[indexInArray] = ra.createCorrectAnswer();
				return ra;
		}
		Question def = new TF(); //default
		return def;
	}

	/**Takes a UserAnswers object and grades the test. 
	 * outputs a print with the grade and notes about essays, if any exist.
	 * */
	public void gradeTest(AnswerSheet ua){
		int ungradeables=0;
		int numCorrect =0;
		int numGraded =0;
		Question[] qAr= getQuestionArray();
		double questionWeight = (100.0/qAr.length);
		Answer[] userAnswers = ua.getUserAnswers();
		int[] grade;
		for (int i=0;i<qAr.length;i++){
			grade = qAr[i].gradeQuestion(userAnswers[i], answerKey[i]);
			numCorrect+=grade[0];
			numGraded+=grade[1];
			if((grade[0]==0)&&(grade[1])==0){ 
				ungradeables+=1;
			}
		}
		Output.getInstance().displayMessage("Grade:");
		Output.getInstance().displayMessage(String.valueOf(Math.round(numCorrect*questionWeight))+"/"+String.valueOf(Math.round(numGraded*questionWeight))+"points, and "+String.valueOf(ungradeables)+" answer to grade by hand");
	}
	/**
	 * modifies a test. will return an array of boolean where index 0 is indicator if the prompt changed
	 * index 1 will indicate if the options/list has changed
	 */
	public boolean[] modify(){
		
		int choice = 99;
		boolean[] changed = {false,false};
		boolean[] ret = {false,false};
		while (choice!=0){
			displayWithAnswers();
			Output.getInstance().displayMessage("Which question would you like to modify? Enter an existing question or 0 to exit");
			choice = DataValidation.getIntInputInRange(0, getQuestionArray().length);
			if(choice!=0){
				changed = getQuestionArray()[choice-1].modify();
				answerModificationHandler(changed,choice);
				if(changed[0]){
					ret[0]=true;
				}
				if(changed.length>1){
					if(changed[1]){
						ret[0]=true;
					}		
				}
			}
		}
		return ret;
	}
	/**
	 * Handles the business logic of how to handle the effect of the answerKey as 
	 * a result of a modification in a question
	 * @param changed
	 * @param choice
	 */
	private void answerModificationHandler(boolean[] changed, int choice){
		if (!(getAnswerKey()[choice-1]==null)){ //makes sure there is an answer
			if (changed.length>1){ //makes sure there is an index which indicates if choices/lists were changed
				if(changed[1]){
					Output.getInstance().displayMessage("OPTIONS IN QUESTIONS HAVE BEEN CHANGED,ANSWERS MUST BE RE-ENTERED");
					getQuestionArray()[choice-1].display();
					getAnswerKey()[choice-1]=getQuestionArray()[choice-1].createCorrectAnswer();
				}
				else{
					if (!(getAnswerKey()[choice-1]==null)){ //makes sure there is an answer
						Output.getInstance().displayMessage("Would you like to modify the answer? enter 1 for yes or 2 for no");
						int mod = DataValidation.getIntInputInRange(1, 2);
						if (mod==1){
							getQuestionArray()[choice-1].display();
							getAnswerKey()[choice-1]=getQuestionArray()[choice-1].createCorrectAnswer();
						}
					}
				}
			}
			else{
				Output.getInstance().displayMessage("Would you like to modify the answer? enter 1 for yes or 2 for no");
				int mod = DataValidation.getIntInputInRange(1, 2);
				if (mod==1){
					getQuestionArray()[choice-1].display();
					getAnswerKey()[choice-1]=getQuestionArray()[choice-1].createCorrectAnswer();
				}
			}
		}
	}
}
