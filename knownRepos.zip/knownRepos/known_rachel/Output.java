package com.Benny.cs350;
/**
 * An abstract singleton used to access the different types of input/output
 * that will be available with the program 
 * @author Benny Sitbon
 *
 */
abstract public class Output {

	static private Output instance;
	static private String type = "console";
	protected Output() {};
	
	//abstract int getInteger();
	//abstract String getString();
	abstract void displayMessage(String msg);
	/**
	 * Chooses the kind of singleton to return/instantiate according to the variable "type"
	 * @return
	 */
	public static Output getInstance(){
		if(type=="console"){
			instance = ConsoleOutput.getInstance();
		}
		else if(type=="tts"){
			instance = TTSOutput.getInstance();
		}
		/*else if(type=="textout"){
			instance =TextoutIO.getInstance();
		}*/
		return instance;
	}
	
	public static void setType(String str){
		type = str;
	}
}
