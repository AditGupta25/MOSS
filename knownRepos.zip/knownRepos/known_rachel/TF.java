package com.Benny.cs350;

/**
 * An extension to the Multi class. This is a type of question that has only two choices : True and False.
 * @author Benny Sitbon
 *
 */
public class TF extends Multi implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public TF() {
		super();
	}
	
	@Override
	public Answer answerQuestion() {
		display();
		String[] answers = DataValidation.getMultipleNumericAnswer("answer",1,1,2,false);
		answers = ArrayMethods.selectionsToValues(answers,choices);
		Answer ans = new Answer(answers);
		return ans;
	}
	@Override
	protected void setChoices(){
		choices = new String[2];
		choices[0] = "True";
		choices[1]= "False";
	}
	@Override
	public Answer createCorrectAnswer(){
		Output.getInstance().displayMessage("Enter Correct Answer, 1)True or 2)False");
		String[] temp = {choices[DataValidation.getIntInputInRange(1, 2)-1]};
		
		Answer ans = new Answer(temp);
		return ans;
	}
	@Override
	public boolean[] modify() {
		boolean[] changed = {false,false};
		changed[0] = modifyPrompt();
		return changed;
		
	}

}
