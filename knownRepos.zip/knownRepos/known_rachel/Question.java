package com.Benny.cs350;

/**
 * The base class for Questions 
 * @author Benny Sitbon
 *
 */
abstract class Question implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String prompt="Default Prompt";
	private int minAnswerSize=1; //minimum number of answers wanted
	private int maxAnswerSize=1;//maximum number of answers wanted
	
	public Question(){
		setPrompt(DataValidation.getNonEmptyStringInput("Enter Question Prompt:"));
	}
	
	protected void setPrompt(String p){
		prompt = p;
	}
	protected String getPrompt(){
		return prompt;
	}
	public void setMinAnswerSize(int i ){
		minAnswerSize = i;
	}
	public int getMinAnswerSize(){
		return minAnswerSize;
	}
	public void setMaxAnswerSize(int i){
		maxAnswerSize = i;
	}
	public int getMaxAnswerSize(){
		return maxAnswerSize;
	}
	/**
	 * Will Change the Question's prompt, and every other aspect it has like : choices, lists
	 * returns a boolean array where index 0 indicates if the prompt have changed and index 1
	 * indicates if lists,choices or other have changed
	 */
	abstract public boolean[] modify();
	/**
	 * Will create a correct answer to the question and return it
	 * @return
	 */
	abstract public Answer createCorrectAnswer();
	/**
	 * Will prompt the user for the answer to the Question and return it
	 * @return
	 */
	abstract public Answer answerQuestion();
	/**
	 * Will display the question using the IO method supplied to the question
	 */
	abstract public void display();
	/**
	 * Will compare the user answer with the correct answer supplied from the answerKey
	 * a correct answer will return as {1,1}, an incorrect answer will return as {0,1}
	 * an ungradeable answer will return as {0,0}
	 * @param userAnswer
	 * @param correctAnswer
	 * @return
	 */
	public int[] gradeQuestion(Answer userAnswer,Answer correctAnswer){
		int[] grade = new int[2];
		grade[0] = 1;
		grade[1] = 1;
		String[] userAns = userAnswer.getAnswer();
		String[] corAns = correctAnswer.getAnswer();
		if(userAns.length==corAns.length){
			for(int i=0;i<corAns.length;i++){
				if(!corAns[i].equals(userAns[i])){
					grade[0]=0;
				}
			}
		}
		else{
			grade[0]=0;
		}
		return grade;
	}
	/**
	 * Modifies the prompt for the question. 
	 * @return true if changed or false if not changed.
	 */
	public boolean modifyPrompt(){
		boolean change = false;
		Output.getInstance().displayMessage("-----Prompt-----");
		Output.getInstance().displayMessage(prompt+"\n");
		Output.getInstance().displayMessage("Do you wish to modify this prompt? Enter 1 for yes or 2 for no");
		int choice = DataValidation.getIntInputInRange(1, 2);
		if (choice==1){
			change= true;
			String newPrompt = DataValidation.getNonEmptyStringInput("Enter New Prompt:");
			setPrompt(newPrompt);
		}
		return change;
	}

}
