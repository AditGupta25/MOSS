package com.Benny.cs350;

/**
 * A class that holds an array of question, and is linked to a specific test/survey
 * by keeping the name of the survey/test and links to a user by keeping the name of the user 
 * @author Benny Sitbon
 *
 */
public class AnswerSheet implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String surveyName;
	private String userName;
	private Answer[] userAnswers;
	
	
	public AnswerSheet(int numberOfQuestions,String survName){
		userAnswers = new Answer[numberOfQuestions];
		surveyName = survName;
		userName = DataValidation.getStandardizedFileNameInput("Please enter your first and last name");
	}
	protected void insertAnswer(int questionNumber,Answer answer){
		userAnswers[questionNumber] = answer;
	}

	protected void setUserName(String name){
		userName = name;
	}
	protected void setSurveyName(String name){
		surveyName = name;
	}
	protected Answer[] getUserAnswers(){
		return userAnswers;
	}
	protected String getUserName(){
		return userName;
	}
	protected String getSurveyName(){
		return surveyName;
	}
	
	
}
