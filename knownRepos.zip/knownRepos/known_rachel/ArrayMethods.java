package com.Benny.cs350;

import java.util.Arrays;
/**
 * A helper Class for handling different methods for manipulating arrays
 * @author Benny Sitbon
 *
 */
public class ArrayMethods {

	public ArrayMethods() {
		
	}
	/**
	 * Will remove a specific index from an array and shift all other indexes. 
	 * @param array
	 * @param index
	 * @return a reference to the new resized array (it is different from the one went in)
	 */
	public static String[] removeIndex(String[] array,int index){
		if(index<array.length){
			try{
				for (int i=index;i<array.length-1;i++){
					array[i] = array[i+1];
				}
				String[] newArray = Arrays.copyOf(array, array.length-1);
				return newArray;
			}
			catch (Exception e){
				Output.getInstance().displayMessage("Error in removing index");
				String[] newArray = array;
				return newArray;
			}
		}
		else{
			Output.getInstance().displayMessage("index out of bounds");
			String[] newArray = array;
			return newArray;
		}		
	}
	/**
	 * Takes user numeric selections for answers (i.e. 1)choice 1 2) choice 2 etc... )
	 * and returns an array with their string counterpart  instead
	 * @param from
	 * @param to
	 * @return
	 */
	
	public static String[] selectionsToValues(String[] from,String[] to){
		String[] ret = null;
		try{
			ret = new String[from.length];
			for(int i=0;i<ret.length;i++){
				ret[i] = to[Integer.parseInt(from[i])-1];
			}
		}
		catch(Exception e){
			Output.getInstance().displayMessage("Error changing selections to values");
		}
		return ret;
	}
	/**
	 * Takes a non-null String array and String variable and adds the string var to the end of the
	 * array.
	 * @param array
	 * @param str
	 * @return
	 */
	public static String[] addToArray(String[] array,String str){
		if (array!=null && str!=null){
			try{
				String[] newArray = Arrays.copyOf(array, array.length+1);
				newArray[array.length] = str;
				return newArray;
			}
			catch(Exception e){
				Output.getInstance().displayMessage("Error adding to array");
				String[] newArray = array;
				return newArray;
			}
		}
		else{
			Output.getInstance().displayMessage("Error adding to array");
			String[] newArray = array;
			return newArray;
		}
	}
}
