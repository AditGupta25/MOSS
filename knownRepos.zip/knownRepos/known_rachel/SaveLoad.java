package com.Benny.cs350;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
/**
 * Serves all the program needs for saving and loading.
 * @author Benny Sitbon
 *
 */
public class SaveLoad implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public SaveLoad(){}
	/**
	 * Serializes and saves a Survey/Test in the folder "sur" in the current working folder
	 * @param s
	 */
	public void save(Survey s){
		try{
			String workingDir = System.getProperty("user.dir");
			FileOutputStream fileOut = new FileOutputStream(workingDir+"/sur/"+s.getName()+".ser");
			ObjectOutputStream out  = new ObjectOutputStream(fileOut);
			out.writeObject(s);
			out.close();
			fileOut.close();
			Output.getInstance().displayMessage("File saved in "+workingDir+"\\sur\\"+s.getName()+".ser");
			File dir = new File(workingDir+"/sur/Answers/"+s.getName());
			dir.mkdirs();
			Output.getInstance().displayMessage("Created a folder for answers at "+dir.getAbsolutePath());
		}catch(IOException i){
			Output.getInstance().displayMessage("Problem in Saving Survey/Test\n");
		}
	}
	
	/**Load a serialized survey/test - Takes the full name of the survey (i.e. with the T_ or S_ prefix)
	 * 
	 */
	public Survey load(String name){
		Survey surv=  null;		
		try{
			String workingDir = System.getProperty("user.dir");
			String filePath = workingDir+"\\sur\\"+name+".ser";
			FileInputStream fileIn = new FileInputStream(filePath);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			surv = (Survey) in.readObject();
			in.close();
			fileIn.close();
			Output.getInstance().displayMessage("Load Succesful");
		} catch (Exception e) {
			Output.getInstance().displayMessage("Test/Survey not found\n");
		}
		return surv;
	}
	/**
	 * Serialize and Saves the AnswerSheet supplied to it. Will serve it in: (workingDir)/sur/Answers/(surveyName)/Answer(userName)(surveyName).ser 
	 * @param ur
	 */
	public void saveAnswerSheet(AnswerSheet ur){
		String surveyName = ur.getSurveyName();
		String userName = ur.getUserName();
		try{
			String workingDir = System.getProperty("user.dir");
			FileOutputStream fileOut = new FileOutputStream(workingDir+"/sur/Answers/"+surveyName+"/Answer"+userName+surveyName+".ser");
			ObjectOutputStream out  = new ObjectOutputStream(fileOut);
			out.writeObject(ur);
			out.close();
			fileOut.close();
			Output.getInstance().displayMessage("Answer Sheet saved in "+workingDir+"/sur/answers/Answers/"+surveyName+"/Answer"+userName+surveyName+".ser");
		}catch(IOException i){
			Output.getInstance().displayMessage("Problem in Saving Answer Sheet\n");
		}
	}
	/**
	 * Loads a serialized AnswerSheet using the relative path:(workingDir)/sur/Answers/(surveyName)/Answer(userName)(surveyName).ser
	 * using the user name and survey name ,and returns it 
	 * @param userName
	 * @param surveyName
	 * @return
	 */
	public AnswerSheet loadAnswerSheet(String userName,String surveyName){
		AnswerSheet ua =null;
		String workingDir = System.getProperty("user.dir");
		try{
			FileInputStream fileIn = new FileInputStream(workingDir+"/sur/Answers/"+surveyName+"/Answer"+userName+surveyName+".ser");
			ObjectInputStream in = new ObjectInputStream(fileIn);
			ua = (AnswerSheet) in.readObject();
			in.close();
			fileIn.close();
			Output.getInstance().displayMessage(ua.getUserName()+"'s answer sheet loaded\n");
			return ua;
		}
		catch(Exception e){
			Output.getInstance().displayMessage("Error in loading answer sheets\n");
		}
		return ua;
	}
	/**
	 * Loads a serialized AnswerSheet using the relative path:(workingDir)/sur/Answers/(surveyName)/Answer(userName)(surveyName).ser
	 * by being passed the file to load.
	 * @param file
	 * @return
	 */
	public AnswerSheet loadAnswerSheet(File file){
		AnswerSheet ua=  null;
		try{
			FileInputStream fileIn = new FileInputStream(file);
			ObjectInputStream in = new ObjectInputStream(fileIn);
			ua = (AnswerSheet) in.readObject();
			in.close();
			fileIn.close();
			Output.getInstance().displayMessage(ua.getUserName()+"'s answer sheet loaded\n");
			return ua;
		}
		catch(Exception e){
			Output.getInstance().displayMessage("Error in loading answer sheets\n");
		}
		return ua;
	}
}
