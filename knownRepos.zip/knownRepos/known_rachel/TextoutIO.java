package com.Benny.cs350;
/**
 * A extension to the IO singleton, this concerete singleton will print a survey to a txt file
 */
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class TextoutIO extends Input {
	private static TextoutIO instance;
	private static String fileName = "output.txt";
	
	private TextoutIO(){}
	
	public static Input getInstance(){
		if (instance==null) instance=new TextoutIO();
		return instance;
	}
	@Override
	public int getInteger(){
		String str = "";
		Scanner s = new Scanner(System.in);
		while (!(DataValidation.isInteger(str))){
			str = s.nextLine();
			if(!(DataValidation.isInteger(str))){
				displayMessage("This is not an Integer,Please Type an Integer and try again");
			}
		}
		int re = Integer.parseInt(str);
		return re;
	}
	/**
	 * Gets a string from console input.
	 * @return
	 */
	@Override
	public String getString(){
		Scanner s = new Scanner(System.in);
		String str = s.nextLine();
		return str;
	}

	void displayMessage(String msg) {
		try {
		    PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(fileName, true)));
		    out.println(msg);
		    out.close();
		} catch (IOException e) {
		    System.out.println("Error in printing to file");
		}
	}

}
