package com.Benny.cs350;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
/**
 * 
 * @author Benny Sitbon
 *
 */
public class Survey implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Question[] qArray;
	protected String surveyName;
	//Holds all the types of questions possible
	private String[] questionMenuOptions = {"True/False","Multiple Choice","Essay","Short Answer","Ranking","Matching"};
	protected SaveLoad sl;
	
	public Survey(){
		super();
		sl = new SaveLoad();
		String tempName = DataValidation.getStandardizedFileNameInput("Enter a Name for the Survey/Test");
		setName(tempName);
		Output.getInstance().displayMessage("Name Chosen is: "+tempName);
		setQuestionArray(createQuestionArray());
		
	}
	protected String getName(){
		return surveyName;
	}
	/**
	 * Will make sure the name passed to set conforms to the name limitations, and set the variable if it is ok.
	 * @param name
	 */
	public void setName(String name){
		if (DataValidation.checkStandardFileNameInput(name)){
			surveyName=standardizeName(name);
		}
		else{
			Output.getInstance().displayMessage("Name not standarized, not saved");
		}
	}
	/**
	 * Will take a regular string and add the Standardize it
	 * @param name
	 * @return
	 */
	public String standardizeName(String name){
		name = "S_"+name;
		return name;	
	}
	
	protected Question[] getQuestionArray(){
		return qArray;
	}
	public void setQuestionArray(Question[] qa){
		qArray = qa;
	}
	public String[] getMenuOptions(){
		return questionMenuOptions;
	}
	/**
	 * Prompts the user to the number of questions to create, then displays a menu and, and react according to selection
	 * returns a Question array
	 * @return
	 */
	public Question[] createQuestionArray(){
		Output.getInstance().displayMessage("How many questions will the survey have?");
		int numQuestions = DataValidation.getPositiveInteger();
		Question[] qa = new Question[numQuestions];
		for (int i=0;i<numQuestions;i++){
			displayQuestionPickMenu(getMenuOptions());
			String choice = getMenuOptions()[DataValidation.getIntInputInRange(1, getMenuOptions().length)-1];
			qa[i] = createQuestion(choice);
		}
		return qa;
	}
	
	/** Create the Question object by the string passed and returns it
	 *  WORKS ONLY ON JAVA 1.7 AND UP! 
	 */
	protected Question createQuestion(String choice){
		Output.getInstance().displayMessage("You Chosen "+choice);
		Output.getInstance().displayMessage("");
		switch (choice){
			case "True/False":
				TF tf = new TF();
				return tf;
			case "Multiple Choice":
				Multi mul = new Multi();
				return mul;
			case "Essay":
				Essay es = new Essay();
				return es;
			case "Short Answer":
				ShortAnswer sa = new ShortAnswer();
				return sa;
			case "Matching":
				Matching ma = new Matching();
				return ma;
			case "Ranking":
				Ranking ra = new Ranking();
				return ra;
		}
		Question def = null;
		return def;
	}
	/**
	 * Running this method will display each question in the survey/test followed by prompt for answer
	 */
	public void take(){
		AnswerSheet ua = new AnswerSheet(qArray.length,surveyName);
		Output.getInstance().displayMessage("Answer The Following Questions\n");
		for (int i=0;i<qArray.length;i++){
			Output.getInstance().displayMessage("\n********Question #"+(i+1)+"********\n");
			ua.insertAnswer(i, qArray[i].answerQuestion());
		}
		sl.saveAnswerSheet(ua);
	}
	/**
	 * Displays the Survey out
	 */
	public void display(){
		displayQuestions();
	}
	public void displayQuestions(){
		for (int i=0;i<getQuestionArray().length;i++){
			Output.getInstance().displayMessage("--------------------------------------");
			Output.getInstance().displayMessage("Question "+(i+1)+"\n");
			getQuestionArray()[i].display();
		}
	}
	/**This methods will try to imitate a tabulating of a real test. i.e. going through test by test,question by question
	 * and inserting the answer to the right bin of answers for the specific question. In case the bin already exist,
	 * increment its corresponding counter. Will create a array with a HashMap cell for each question.
	 * Will iterate over all the answered surveys/tests and insert their information into the the "bins".
	 */
	public void tabulate(){
		HashMap<String, Number>[] tableau = (HashMap<String,Number>[]) new HashMap<?,?>[qArray.length];
		//Sets up the HashMaps - each question has a its own HashMap (bins)
		for (int i=0;i<qArray.length;i++){
			tableau[i] = new HashMap<String,Number>();
		}
		File[] answerSheets = getAnswerFiles();
		if(answerSheets!=null){
			for (int k=0;k<answerSheets.length;k++){
				AnswerSheet ua = sl.loadAnswerSheet((answerSheets[k]));
				for (int i=0;i<qArray.length;i++){
					String[] answerArray = ua.getUserAnswers()[i].getAnswer();
					for (int j=0;j<answerArray.length;j++){
						if (tableau[i].containsKey(answerArray[j])){
							int num = tableau[i].get(answerArray[j]).intValue()+1;
							tableau[i].put(answerArray[j], num);
						}
						else{
							tableau[i].put(answerArray[j], 1);
						}
					}
				}
			}
		}else{
			Output.getInstance().displayMessage("No answer sheets found for survey/test");
		}
		printTabulation(tableau);
		
	}
	/**
	 * Given a String array, will print them as list with a number to the left of each item
	 * @param options
	 */
	public void displayQuestionPickMenu(String[] options){
		Output.getInstance().displayMessage("Please Select a Question Type:");
		for (int i=1;i<=options.length;i++){
			Output.getInstance().displayMessage(i+") Add a new "+options[i-1]+" question");
		}
	}
	/**
	 * Takes an array of type HashMap<String,Number> and prints it to output
	 * @param hash
	 */
	private void printTabulation(HashMap<String,Number>[] hash){
		Output.getInstance().displayMessage("*************************");
		Output.getInstance().displayMessage("Tabulation for "+getName());
		Output.getInstance().displayMessage("*************************");
		for (int i=0;i<hash.length;i++){
			Output.getInstance().displayMessage("\nQuestion "+(i+1));
			Output.getInstance().displayMessage("Prompt:\n"+getQuestionArray()[i].getPrompt());
			Output.getInstance().displayMessage("Answers:");
			Iterator<?> it = hash[i].entrySet().iterator();
			while(it.hasNext()){
				Map.Entry pair = (Map.Entry)it.next();
				Output.getInstance().displayMessage(pair.getKey()+ " - "+pair.getValue()+" times");
				it.remove();
			}
		}
	}
	/**
	 * Return all the AnswerSheets for current survey/Test
	 * @return
	 */
	private File[] getAnswerFiles(){
		String workingDir = System.getProperty("user.dir");
		File folder = new File(workingDir+"/sur/Answers/"+surveyName);
		return folder.listFiles(); 
	}
	/**
	 * modifies a test. will return an array of boolean where index 0 is indicator if the prompt changed
	 * index 1 will indicate if the options/lists have changed
	 */
	public boolean[] modify(){
		
		int choice = 99;
		boolean[] changed = {false,false};
		boolean[] ret = {false,false};
		while (choice!=0){
			display();
			Output.getInstance().displayMessage("--------------------------------------");
			Output.getInstance().displayMessage("Which question would you like to modify? Enter an existing question or 0 to exit");
			choice = DataValidation.getIntInputInRange(0, getQuestionArray().length);
			if(choice!=0){
				changed = getQuestionArray()[choice-1].modify();
			}
			if (changed[0]){
				ret[0]=true;
			}
			if(changed.length>1){
				if(changed[1]){
					ret[0]=true;
				}		
			}
		}
		return ret;
	}
}
