package com.Benny.cs350;
/**
 * an extension to the Short Answer object. It must be graded by hand, and no answer should be inserted
 * when creating it in a test.
 * @author Benny Sitbon
 *
 */
public class Essay extends ShortAnswer{
	
	private static final long serialVersionUID = 1L;
	public Essay(){
		super();
	}
	@Override
	public int[] gradeQuestion(Answer userAnswer,Answer correctAnswer){
		int[] grade = {0,0};
		return grade;
	}
	@Override
	public Answer createCorrectAnswer(){
		Answer ans = null;
		return ans;
	}
}
