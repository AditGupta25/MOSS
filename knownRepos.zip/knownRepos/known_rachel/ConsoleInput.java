package com.Benny.cs350;

import java.util.Scanner;
/**
 * An input/output for console singleton
 * @author Benny Sitbon
 *
 */
public class ConsoleInput extends Input implements java.io.Serializable{
	/**
	 * 
	 */
	private static ConsoleInput instance;
	private ConsoleInput(){}
	
	private static final long serialVersionUID = 1L;
	
	public static Input getInstance(){
		if (instance==null) instance=new ConsoleInput();
		return instance;
	}
	/*public void displayMessage(String msg){
		System.out.println(msg);
	}*/
	/**
	 * Will prompt the user for an integer and validate using DataValidation class, that it is an Integer
	 * Will keep prompting the user, until successful.
	 * @return
	 */
	@Override
	public int getInteger(){
		String str = "";
		Scanner s = new Scanner(System.in);
		while (!(DataValidation.isInteger(str))){
			str = s.nextLine();
			if(!(DataValidation.isInteger(str))){
				Output.getInstance().displayMessage("This is not an Integer,Please Type an Integer and try again");
			}
		}
		int re = Integer.parseInt(str);
		return re;
	}
	/**
	 * Gets a string from console input.
	 * @return
	 */
	@Override
	public String getString(){
		Scanner s = new Scanner(System.in);
		String str = s.nextLine();
		return str;
	}

	
	
	
}
