import java.io.*;
import java.util.Scanner;
import java.util.Vector;

public class LoadMenuTest extends Menu{

    public LoadMenuTest()
    {
        choices=2;
        Vector<String> temp=new Vector<String>();
        temp.add("Test1");
        temp.add("Test2");
        MenuChoice=temp;
    }
    //Loads serialized file
    public Test load() throws IOException, ClassNotFoundException {
        System.out.println("Select the file you would like to load:");
        for (int i=0;i<choices;i++)
        {
            System.out.println(i+1+")"+MenuChoice.get(i));
        }

        Scanner scanner = new Scanner(System.in);
        String selected=scanner.nextLine();
        String Menuselect=MenuChoice.get(Integer.parseInt(selected)-1);

        FileInputStream fi = new FileInputStream(new File("src/"+Menuselect+".txt"));
        ObjectInputStream oi = new ObjectInputStream(fi);
        System.out.println("The File has been loaded!");
        return (Test)oi.readObject();
    }
}
