import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.IOException;
import java.util.Vector;

/*
Zachary Jung
CS350
HW2
5/9/2018
*/
public class Main {

    public static void main(String[] args) throws TransformerException, ParserConfigurationException, IOException {
        FirstMenu menu2=new FirstMenu();
        menu2.display();
        String Selection=menu2.getAnswer();
        if(Selection.equals("Test"))//If user selects test
        {
            Test Test=new Test();
            TestMenu menu = new TestMenu();
            String selection1="temp";

            while(selection1!="Quit") {//Allows for the program to keep creating new questions
                menu.display();
                selection1 = menu.getAnswer();
                if (selection1.equals("Create")) {
                    CreateMenu create = new CreateMenu();
                    create.setTest(true);

                    create.display();
                    String Questiontype = create.getAnswer();
                    if (Questiontype.equals("T/F")) {
                        TF Truefalse = new TF();
                        Truefalse.isTest(true);
                        Truefalse.prompt();
                        Test.addQuestion(Truefalse);
                    } else if (Questiontype.equals("Multiple")) {
                        MultipleChoice question = new MultipleChoice();
                        question.isTest(true);
                        question.prompt();
                        Test.addQuestion(question);
                    } else if (Questiontype.equals("Short")) {
                        ShortAnswer shortanswer = new ShortAnswer(50);
                        shortanswer.isTest(true);
                        shortanswer.prompt();
                        Test.addQuestion(shortanswer);
                    } else if (Questiontype.equals("Essay")) {
                        Essay essay = new Essay();
                        essay.isTest(true);
                        essay.prompt();
                        Test.addQuestion(essay);
                    } else if (Questiontype.equals("Ranking")) {
                        Ranking rank = new Ranking();
                        rank.isTest(true);
                        rank.prompt();
                        Test.addQuestion(rank);
                    } else if (Questiontype.equals("Matching")) {
                        Matching match = new Matching();
                        match.isTest(true);
                        match.prompt();
                        Test.addQuestion(match);
                    }
                } else if (selection1.equals("Display")) {
                    Test.display();


                } else if (selection1.equals("Load")) {
                    LoadMenuTest load = new LoadMenuTest();
                    try {
                        Test=load.load();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                } else if (selection1.equals("Save")) {

                        Test.save(Test);

                } else if (selection1.equals("Quit")) {
                    System.exit(0);
                }
            }
        }
        else if(Selection.equals("Survey"))//If User selects survey
        {
            SurveyMenu menu1=new SurveyMenu();
            Survey survey = new Survey();
            String selection1="temp";

            while(selection1!="Quit") {//Allows for the program to keep creating new questions
                menu1.display();
                selection1 = menu1.getAnswer();

                if (selection1.equals("Create")) {
                    CreateMenu create = new CreateMenu();
                    create.setTest(false);
                    create.display();
                    String Questiontype = create.getAnswer();
                    if (Questiontype.equals("T/F")) {
                        TF Truefalse = new TF();
                        Truefalse.isTest(false);
                        Truefalse.prompt();
                        survey.addQuestion(Truefalse);
                    } else if (Questiontype.equals("Multiple")) {
                        MultipleChoice question = new MultipleChoice();
                        question.isTest(false);
                        question.prompt();
                        survey.addQuestion(question);
                    } else if (Questiontype.equals("Short")) {
                        ShortAnswer shortanswer = new ShortAnswer(50);
                        shortanswer.isTest(false);
                        shortanswer.prompt();
                        survey.addQuestion(shortanswer);
                    } else if (Questiontype.equals("Essay")) {
                        Essay essay = new Essay();
                        essay.isTest(false);
                        essay.prompt();
                        survey.addQuestion(essay);
                    } else if (Questiontype.equals("Ranking")) {
                        Ranking rank = new Ranking();
                        rank.isTest(false);
                        rank.prompt();
                        survey.addQuestion(rank);
                    } else if (Questiontype.equals("Matching")) {
                        Matching match = new Matching();
                        match.isTest(false);
                        match.prompt();
                        survey.addQuestion(match);
                    }
                } else if (selection1.equals("Display")) {
                    survey.display();

                } else if (selection1.equals("Load")) {
                    LoadMenuSurvey load = new LoadMenuSurvey();
                    try {
                        survey=load.load();
                    } catch (ClassNotFoundException e) {
                        e.printStackTrace();
                    }

                } else if (selection1.equals("Save")) {
                    survey.save(survey);

                }
            }
        }






    }
}
