import java.util.Scanner;
import java.util.Vector;

public class CreateMenu extends Menu{
    private String Creator;
    private String Title;
    private int choices;
    private String Answer;
    private Boolean isTest;
    CreateMenu()
    {
        choices=6;
        Vector<String> temp=new Vector<String>();
        temp.add("Add a new T/F");
        temp.add("Add a new Multiple Choice");
        temp.add("Add a new Short Answer");
        temp.add("Add a new Essay Question");
        temp.add("Add a new Ranking Question");
        temp.add("Add a new Matching Question");
        MenuChoice=temp;
    }

    public void display(){
        for (int i=0;i<choices;i++)
        {
            System.out.println(i+1+")"+MenuChoice.get(i));

        }
        Scanner scanner=new Scanner(System.in);
        String answer = scanner.next();
        Selection(answer);

    }
    public void Selection(String selected)
    {
        if(selected.equals("1"))
        {
            Answer = "T/F";
        }
        else if(selected.equals("2"))
        {
            Answer = "Multiple";
        }
        else if(selected.equals("3"))
        {
            Answer = "Short";
        }
        else if(selected.equals("4"))
        {
            Answer = "Essay";
        }
        else if(selected.equals("5"))
        {
            Answer = "Ranking";
        }
        else if(selected.equals("6"))
        {
            Answer = "Matching";
        }
        else
        {
            System.out.println("You entered in an invalid selection");
            display();
        }
    }

    public String getAnswer() {
        return Answer;
    }

    public void setTest(Boolean test) {
        isTest = test;
    }
}
