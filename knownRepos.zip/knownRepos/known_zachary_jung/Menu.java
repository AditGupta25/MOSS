import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Vector;

public class Menu {
    protected int choices;
    protected Vector<String> MenuChoice;
    private String Selection;
    public void display() throws FileNotFoundException, IOException, ClassNotFoundException {
        for (int i=0;i<choices;i++)
        {
            System.out.println(i+1+")"+MenuChoice.get(i));
        }

    }
}
