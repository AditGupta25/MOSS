import java.awt.*;
import java.util.Scanner;
import java.util.Vector;

public class TF extends MultipleChoice{
    private int Choices=2;
    public void TF(){
        Choices=2;
        Type="TF";
        Vector<String> templist = new Vector<String>();
        templist.add("True");
        templist.add("False");
        responses=templist;
    }
    public void prompt()
    {

        Vector<String> templist = new Vector<String>();
        System.out.println("Enter the question here: ");
        Scanner scanner=new Scanner(System.in);
        question = scanner.nextLine();
        if(isTest==true)
        {
            System.out.println("Type in the Answer for the "+Type+" question (True/False)");
            Scanner scanner2 =  new Scanner(System.in);
            Answer=scanner2.nextLine();
        }
    }
    public void display()
    {
        System.out.println("True or False Question");
        System.out.println(question);
        System.out.println("True or False");
        if(isTest==true) {
            System.out.println("The correct answer is "+getAnswer());
        }
    }



}
