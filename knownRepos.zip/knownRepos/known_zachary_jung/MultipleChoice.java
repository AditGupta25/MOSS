import java.util.Scanner;
import java.util.Vector;

public class MultipleChoice extends Question {
    protected int Choices;
   protected Vector<String> responses;
    public MultipleChoice()
    {
        Type="MultipleChoice";
        Choices=4;

    }
    public void display()
    {
        System.out.println("Multiple Choice Question");
        System.out.println(question);
        for(int i=0; i<responses.size();i++)
        {
            System.out.print(i+1+")"+responses.get(i)+"\t");
        }
        System.out.println("");
        if(isTest==true) {
            System.out.println("\nThe correct answer is "+getAnswer());
        }
    }
    public void prompt()
    {
        Vector<String> templist = new Vector<String>();
        System.out.println("Enter the question here: ");
        Scanner scanner=new Scanner(System.in);
        question = scanner.nextLine();
        System.out.println(question);
        for (int i=1;i<=Choices;i++)
        {
            System.out.println("Enter Choice #"+i);
            Scanner scanner1=new Scanner(System.in);
           String temp=scanner1.nextLine();
           templist.add(temp);
        }
        responses=templist;
        if(isTest==true)
        {
            System.out.println("Type in the Answer");
            Scanner scanner2 =  new Scanner(System.in);
            Answer=scanner2.nextLine();
        }
    }

}
