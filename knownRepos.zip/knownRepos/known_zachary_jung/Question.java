import java.io.Serializable;
import java.util.Vector;

public class Question implements Serializable {
    protected String Type;
    private String response;
    protected String question;
    public boolean isTest;
    private String prompt;
    protected String Answer;
    public Question()
    {

    }
    public void display()
    {
        System.out.println(prompt);
    }

    public void setPrompt(String prompt) {
        this.prompt = prompt;
    }


    public void isTest(Boolean Test)
    {
        this.isTest= Test;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return Answer;
    }

    public String getType() {
        return Type;
    }
}
