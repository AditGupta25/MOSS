import java.util.Scanner;

public class ShortAnswer extends Essay {
    private int sizeLimit;
    public ShortAnswer( int limit)
    {
        Type="ShortAnswer";
        sizeLimit=limit;
    }
    public void setLimit(int limit)
    {

    }
    public void getLimit(int limit)
    {

    }
    public void prompt()
    {
        System.out.println("Enter the question here: ");
        Scanner scanner=new Scanner(System.in);
        question = scanner.nextLine();

        if(isTest==true)
        {
            System.out.println("Type in the Answer for the "+Type+" question");
            Scanner scanner2 =  new Scanner(System.in);
            Answer=scanner2.nextLine();
        }
    }
    public void display()
    {
        System.out.println("Short Answer Question");
        System.out.println(question);
        if(isTest==true) {
            System.out.println("The correct answer is "+getAnswer());
        }
    }

}
