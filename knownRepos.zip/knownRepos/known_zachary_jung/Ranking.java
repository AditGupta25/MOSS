import java.util.Scanner;
import java.util.Vector;

public class Ranking extends Matching {
    public Ranking()
    {
        Type="Ranking";
    }
    public void display()
    {
        System.out.println("Ranking Question");
        System.out.println(question);
        for(int i=0; i<responses.size();i++)
        {
            System.out.print(i+1+")"+responses.get(i)+"\t");
        }
        System.out.println("");
        if(isTest==true) {
            System.out.println("\nThe correct answer is "+getAnswer());
        }
    }
    public void prompt() {

        Vector<String> templist = new Vector<String>();
        Vector<String> templist1 = new Vector<String>();
        System.out.println("Enter the question here: ");
        Scanner scanner = new Scanner(System.in);
        question = scanner.nextLine();
        for (int i = 1; i <= Choices; i++) {
            System.out.println("Enter Option #" + i);
            Scanner scanner1 = new Scanner(System.in);
            String temp = scanner1.nextLine();
            templist.add(temp);
        }
        responses = templist;
        if(isTest==true)
        {
            System.out.println("Type in the Answer that match up with the choices respectively (Delimited by commas)");
            Scanner scanner2 =  new Scanner(System.in);
            Answer=scanner2.nextLine();
        }
    }

}
