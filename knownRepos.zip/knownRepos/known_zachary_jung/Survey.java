import sun.text.normalizer.NormalizerBase;

import java.io.*;
import java.util.Scanner;
import java.util.Vector;

public class Survey implements Serializable {
    private String Title;
    private int numberQuestion;
    protected Vector<Question> Questionslist;

    public Survey()
    {
        Vector<Question> temp=new Vector<Question>();
        Questionslist=temp;

    }
    public void addQuestion(Question quest)
    {
        Questionslist.add(quest);
    }
    public void removeQuestion()
    {

    }
    public void getQuestion()
    {

    }

    public Vector<Question> getQuestionslist() {
        return Questionslist;
    }

    public void display()
    {
        for(int i =0;i<Questionslist.size();i++)
        {
            Question quest=Questionslist.get(i);
            System.out.print(i+1+") ");
            quest.display();
            System.out.println("\n");
        }
        System.out.print("\n\n\n");
    }
    public void tabulate()
    {

    }
    //Creates serialized file
    public void save(Survey survey) throws IOException {
        System.out.println("Type in the path of the file");
        Scanner scanner1=new Scanner(System.in);
        String path=scanner1.nextLine();

        System.out.println("Type in the name of the file (without .txt)");

        path=path+"\\"+scanner1.nextLine()+".txt";

        File f =new File(path);
        FileOutputStream fos = new FileOutputStream(f);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(survey);
        System.out.println("The Survey has been serialized to file...");


    }
}
