
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.util.Scanner;
import java.util.Vector;


public class Test extends Survey implements Serializable{
    private Float Score;

    public Test()
    {

    }
    /*public Test(String Title) {
        super(Title);

    }*/

    public void addCorrect()
    {

    }
    public void setAnswer(Question question)
    {

    }
    /*public float getScore()
    {

    }
    private boolean check()
    {

    }*/
    public void display()
    {
        for(int i =0;i<Questionslist.size();i++)
        {
            Question quest=Questionslist.get(i);
            System.out.print(i+1+") ");
            quest.display();
            System.out.println("\n");
        }
        System.out.print("\n\n\n");
    }
    public void save(Test test) throws IOException {
        System.out.println("Type in the path of the file");
        Scanner scanner1=new Scanner(System.in);
        String path=scanner1.nextLine();

        System.out.println("Type in the name of the file (without .txt)");

        path=path+"\\"+scanner1.nextLine()+".txt";

        File f =new File(path);
        FileOutputStream fos = new FileOutputStream(f);
        ObjectOutputStream oos = new ObjectOutputStream(fos);
        oos.writeObject(test);

        System.out.println("The Test has been serialized to a file...");

    }
}
