import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.Scanner;
import java.util.Vector;

public class LoadMenuSurvey extends Menu{
    public LoadMenuSurvey()
    {
        choices=2;
        Vector<String> temp=new Vector<String>();
        temp.add("Survey1");
        temp.add("Survey2");
        MenuChoice=temp;
    }
    //Loads serialized file
    public Survey load() throws IOException, ClassNotFoundException {
        System.out.println("Select the file you would like to load:");
        for (int i=0;i<choices;i++)
        {
            System.out.println(i+1+")"+MenuChoice.get(i));
        }

        Scanner scanner = new Scanner(System.in);
        String selected=scanner.nextLine();
        String Menuselect=MenuChoice.get(Integer.parseInt(selected)-1);

        FileInputStream fi = new FileInputStream(new File("src/"+Menuselect+".txt"));
        ObjectInputStream oi = new ObjectInputStream(fi);
        return (Survey)oi.readObject();
    }
}
