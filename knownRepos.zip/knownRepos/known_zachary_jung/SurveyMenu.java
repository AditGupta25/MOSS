import java.util.Scanner;
import java.util.Vector;

public class SurveyMenu extends Menu{
    private int choices;
    private Vector<String> MenuChoice;
    private String Answer;

    SurveyMenu()
    {
        choices=5;
        Vector<String> temp=new Vector<String>();
        temp.add("Create a new Survey");
        temp.add("Display a Survey");
        temp.add("Load a Survey");
        temp.add("Save a Survey");
        temp.add("Quit");
        MenuChoice=temp;
    }

    public void display(){
        for (int i=0;i<choices;i++)
        {
            System.out.println(i+1+")"+MenuChoice.get(i));
        }
        Scanner scanner=new Scanner(System.in);
        String answer = scanner.next();
        Selection(answer);

    }
    public void Selection(String selected)
    {
        if(selected.equals("1"))
        {
            Answer = "Create";
        }
        else if(selected.equals("2"))
        {
            Answer = "Display";
        }
        else if(selected.equals("3"))
        {
            Answer = "Load";
        }
        else if(selected.equals("4"))
        {
            Answer = "Save";
        }
        else if(selected.equals("5"))
        {
            System.exit(0);
        }
        else
        {
            System.out.println("You entered in an invalid selection");
            display();
        }

    }
    public String getAnswer() {
        return Answer;
    }
}
