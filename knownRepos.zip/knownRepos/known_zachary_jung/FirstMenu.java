import java.util.Scanner;
import java.util.Vector;

public class FirstMenu extends Menu{
    private int choices;
    private Vector<String> MenuChoice;
    private String Answer;
    FirstMenu()
    {
        choices=2;
        Vector<String> temp=new Vector<String>();
        temp.add("Survey");
        temp.add("Test");
        MenuChoice=temp;
    }

    public void display(){
        for (int i=0;i<choices;i++)
        {
            System.out.println(i+1+")"+MenuChoice.get(i));

        }
        Scanner scanner=new Scanner(System.in);
        String answer = scanner.next();
        Selection(answer);

    }
    public void Selection(String selected)
    {
        if(selected.equals("1"))
        {
            Answer = "Survey";
        }
        else if(selected.equals("2"))
        {
            Answer = "Test";
        }
        else
        {
            System.out.println("You entered in an invalid selection");
            display();
        }
    }

    public String getAnswer() {
        return Answer;
    }
}
