import java.util.Scanner;

public class Essay extends Question {
    private int Responses=1;
    public Essay(){
        Type="Essay";
    };
    public void prompt()
    {
        System.out.println("Enter the question here: ");
        Scanner scanner=new Scanner(System.in);
        question = scanner.nextLine();

        if(isTest==true)
        {
            Answer="The answer will be graded at a later date.";
        }
    }
    public void display()
    {
        System.out.println("Essay Question");
        System.out.println(question);
        if(isTest==true) {
            System.out.println(getAnswer());
        }
    }
}
