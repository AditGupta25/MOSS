public class IO {

    private static IO ourInstance = new IO();

    public static IO getInstance() {
        return ourInstance;
    }

    private IO() { }

    public void show(String s) {
        Output.getInstance().consoleShow(s);
    }

    public String prompt() {
        Output.getInstance().consoleShowPrompt();
        return Input.getInstance().consoleRead();
    }

    public String read() {
        return Input.getInstance().consoleRead();
    }

}
