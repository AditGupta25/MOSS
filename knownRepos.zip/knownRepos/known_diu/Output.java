public class Output {
    private static Output ourInstance = new Output();

    public static Output getInstance() {
        return ourInstance;
    }

    private Output() {
    }
    public void consoleShow(String s) {
        System.out.println(s);
    }

    public void consoleShowPrompt() { System.out.print("> ");}


}
