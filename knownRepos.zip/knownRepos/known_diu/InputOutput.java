public abstract class InputOutput implements java.io.Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 2990361242666838173L;

	public InputOutput()
	{
	}

	public void display(String stream)
	{
	}

}