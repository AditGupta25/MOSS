import java.io.Serializable;

public class IntResponse extends QuestionResponse implements Serializable {

    private static final long serialVersionUID = 710L;


    public IntResponse(int i) {
        this.value = i;
    }

    public boolean equals(String r){
        return Integer.toString(value ).equals(r);
    };

    public String toString() {
        return Integer.toString(value);
    }

    public int getValue() {

        return value;
    }

    public void setValue(int value)
    {
        this.value = value;
    }

    private int value;
}
