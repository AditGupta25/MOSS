import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.io.*;


public class SurveyFileManager extends FileIOManager {

    private final String SURVEY_FILE_PREFIX = "survey-";
    private final String DIRECTORY = System.getProperty("user.dir") + File.separator + "surveys";

    public SurveyFileManager() {
        File directory = new File(DIRECTORY);
        if (!directory.exists()) {
            directory.mkdirs();
        }
    }


    public Survey loadSurvey(String name) {
        String fileName = DIRECTORY + File.separator + SURVEY_FILE_PREFIX + name.replace(' ', '.');
        Survey s = null;
        ObjectInputStream iStream = null;
        try {
            // Reading the object from a file
            FileInputStream file = new FileInputStream(fileName);
            ObjectInputStream in = new ObjectInputStream(file);

            // Method for deserialization of object
            s = (Survey)in.readObject();

            in.close();
            file.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return s;
    }

    ;

    public void saveSurvey(Survey s) {
        String fileName = DIRECTORY + File.separator + SURVEY_FILE_PREFIX + s.getTitle().replace(' ', '.');
        try {
            FileOutputStream fileOut = new FileOutputStream(fileName);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(s);
            out.close();
            fileOut.close();
        } catch (Exception e) {

        }
    }

    public boolean surveyExists(String s) {
        ArrayList<String> currentSurveyNames = getCurrentSurveyNames();
        for(int i = 0; i < currentSurveyNames.size(); i++) {
            currentSurveyNames.set(i, currentSurveyNames.get(i).toLowerCase());
        }
        return currentSurveyNames.contains(s.toLowerCase());
    }

    public ArrayList<String> getCurrentSurveyNames() {
        File[] files = new File(DIRECTORY).listFiles();
        ArrayList<String> surveyNames = new ArrayList<>();
        for (File file : files) {
            if (file.getName().startsWith(SURVEY_FILE_PREFIX)) {
                String surveyName;
                surveyName = file.getName().substring(SURVEY_FILE_PREFIX.length());
                surveyNames.add(surveyName.replace('.', ' '));
            }
        }
        return surveyNames;
    }
}
