import java.io.Serializable;
import java.util.ArrayList;

public class SurveyResponse implements Serializable {
    public SurveyResponse() {}

    public SurveyResponse(String surveyName, int numQuestions) {

    }

    public SurveyResponse(String surveyName, int numQuestions, ArrayList<QuestionResponse> responses) {

    }

    public void addResponse(ArrayList<QuestionResponse> response) {}

    private ArrayList<ArrayList<QuestionResponse>> responseList;
    private int numQuestions;
    private String surveyTitle;
}
