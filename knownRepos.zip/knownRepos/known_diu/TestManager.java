import java.util.ArrayList;

public class TestManager extends DisplayManager {

    private static TestFileManager fileManager = new TestFileManager();
    private Test test;


    private boolean isLoaded() {
        return this.test != null;
    }

    public boolean showMainMenu() {
        ArrayList<String> testMenuItems = new ArrayList<>();
        testMenuItems.add("Create a new Test");
        testMenuItems.add("Display a Test");
        testMenuItems.add("Load a Test");
        testMenuItems.add("Save a Test");
        testMenuItems.add("Go Back to first menu");
        testMenuItems.add("Quit");
        int response = -1;
        boolean done = false;
        boolean quitFlag = false;
        while(!done) {
            for (int i = 1; i <= testMenuItems.size(); i++) {
                io.show((i) + ". " + testMenuItems.get(i-1));
            }
            response = InputSanitationManager.getIntValue(1, testMenuItems.size());
            switch (response) {
                case 1:
                    create();
                    break;
                case 2:
                    display();
                    break;
                case 3:
                    load();
                    break;
                case 4:
                    save();
                    break;
                case 5:
                    done = true;
                    break;
                case 6:
                    done = true;
                    quitFlag = true;
                    break;
            }
        }
        return quitFlag;

    }
    public void load() {
        ArrayList<String> tests = fileManager.getCurrentTestNames();
        if (tests.size() > 0) {
            io.show("Select a test to load.");
            for (int i = 0; i < tests.size(); i++) {
                io.show(i + 1 + ") " + tests.get(i));
            }
            int response = InputSanitationManager.getIntValue(1, tests.size());

            String selection = tests.get(response - 1);
            this.test = fileManager.loadTest(selection);
            io.show("Loaded test: " + selection);
        } else {
            io.show("No tests to load.");
        }
    }


    public void display() {
        if (isLoaded()) {
            int questionNum = 0;
            ArrayList<ArrayList<QuestionResponse>> correctAnswers = test.getCorrectAnswers();
            for (Question question : test.getQuestions()) {
                questionNum++;
                io.show(questionNum + ") " + question.toString());
                ArrayList<QuestionResponse> answers = correctAnswers.get(questionNum - 1);
                StringBuilder correctAnswersStr = new StringBuilder();
                for (QuestionResponse response : answers) {
                    correctAnswersStr.append(response.getDisplayVal());
                }
                if(correctAnswersStr.toString().length() > 0) {
                    io.show("The correct answer(s) is:\n" + correctAnswersStr.toString());
                }
                else {
                    io.show("");
                }
            }
        } else {
            io.show("No test currently loaded. Please load a test before trying to display it.");
        }

    }


    public void save() {
        if (isLoaded()) {
            fileManager.saveTest(this.test);
            io.show("Saved test: " + this.test.getTitle());
        } else {
            io.show("No test to save. Please load or create a test before trying to save it.");
        }
    }


    public void create() {
        try {
            io.show("Enter a name for the new test.");
            String title = InputSanitationManager.getTitle();
            boolean surveyExists = fileManager.testExists(title);
            while (surveyExists) {
                io.show("Test with name: " + title + " already exists. Please enter another name");
                title = InputSanitationManager.getTitle();
                surveyExists = fileManager.testExists(title);
            }

            this.test = new Test(title);
            this.test.setQuestions(createQuestionsMenu());
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    protected MultipleChoice createMultipleChoice() {
        MultipleChoice question = super.createMultipleChoice();
        final int ASCII_OFFSET = 64;
        ArrayList<QuestionResponse> correctAnswers = new ArrayList<>();
        for (int i = 0; i < question.getNumAnswers(); i++) {
            io.show("Enter correct choice #" + (i + 1) + " (as a number)");
            int response = InputSanitationManager.getIntValue(1, question.getChoices().size());
            IntResponse intRes = new IntResponse(response);
            intRes.setDisplayVal((char) (intRes.getValue() + ASCII_OFFSET) + ". " + question.getChoices().get(response - 1) + "\n");
            correctAnswers.add(intRes);
        }
        test.addCorrectAnswer(correctAnswers);
        return question;
    }

    protected TrueFalse createTrueFalse() {
        TrueFalse question = super.createTrueFalse();
        io.show("Enter correct response (T or F)");
        boolean response = InputSanitationManager.getTrueFalse();
        ArrayList<QuestionResponse> correctAnswer = new ArrayList<>();
        BooleanResponse boolRes = new BooleanResponse(response);
        boolRes.setDisplayVal(boolRes.toString() + "\n");
        correctAnswer.add(boolRes);
        test.addCorrectAnswer(correctAnswer);
        return question;
    }

    protected Essay createEssay() {
        Essay question = super.createEssay();
        ArrayList<QuestionResponse> correctAnswers = new ArrayList<>();
        for (int i = 0; i < question.getNumAnswers(); i++) {
            StringResponse strRes = new StringResponse("");
            strRes.setDisplayVal("");
            correctAnswers.add(strRes);
        }
        test.addCorrectAnswer(correctAnswers);
        return question;
    }

    protected ShortAnswer createShortAnswer() {
        ShortAnswer question = super.createShortAnswer();
        ArrayList<QuestionResponse> correctAnswers = new ArrayList<>();
        for (int i = 0; i < question.getNumAnswers(); i++) {
            io.show("Enter correct answer #" + (i + 1));
            String response = InputSanitationManager.getCharLimitedString(question.getCharLimit());
            StringResponse strRes = new StringResponse(response);
            strRes.setDisplayVal(((i + 1) + ". " + response + "\n").replaceAll("(.{100})", "$1\n"));
            correctAnswers.add(strRes);
        }
        test.addCorrectAnswer(correctAnswers);
        return question;
    }

    protected Ranking createRanking() {
        Ranking question = super.createRanking();
        ArrayList<QuestionResponse> correctAnswers = new ArrayList<>();
        ArrayList<Integer> rankingValues = new ArrayList<>();
        StringBuilder displayVal = new StringBuilder();
        for (int i = 0; i < question.getLeft().size(); i++) {
            io.show("Enter item at rank #" + (i + 1));
            int response = InputSanitationManager.getIntValue(1, question.getLeft().size());
            boolean isNewResponse = !rankingValues.contains(response);
            while(!isNewResponse) {
                io.show("Value has already been used in ranking order. Please choose an unused value");
                response = InputSanitationManager.getIntValue(1, question.getLeft().size());
                isNewResponse = !rankingValues.contains(response);
            }
            rankingValues.add(response);
            displayVal.append(response + "\n");
        }
        IntListResponse intListResponse = new IntListResponse(rankingValues);
        intListResponse.setDisplayVal(displayVal.toString());
        correctAnswers.add(intListResponse);
        test.addCorrectAnswer(correctAnswers);
        return question;
    }

    protected Matching createMatching() {
        Matching question = super.createMatching();
        ArrayList<QuestionResponse> correctAnswers = new ArrayList<>();
        ArrayList<Integer> matchingValues = new ArrayList<>();
        StringBuilder displayVal = new StringBuilder();
        int numItems = question.getLeft().size();
        for(int i = 0; i < numItems; i++) {
            io.show("Enter correct match value for #" + (i + 1));
            int response = InputSanitationManager.getMatchingResponse(numItems);
            boolean isNewResponse = !matchingValues.contains(response);
            while(!isNewResponse) {
                    io.show("Match for that value already specified. Please input a different value.");
                    response = InputSanitationManager.getMatchingResponse(numItems);
                    isNewResponse = !matchingValues.contains(response);

            }
            matchingValues.add(response);
            displayVal.append((i + 1) + " " + (char) (response) + "\n");
        }
        IntListResponse intListResponse = new IntListResponse(matchingValues);
        intListResponse.setDisplayVal(displayVal.toString());
        correctAnswers.add(intListResponse);
        test.addCorrectAnswer(correctAnswers);
        return question;
    }

    //TODO: Implement in HW3
    protected void modifyMatching(Matching question) {
    }

    protected void modifyMultipleChoice(MultipleChoice question) {
    }

    protected void modifyRanking(Ranking question) {
    }

    protected void modifyShortAnswer(ShortAnswer question) {
    }

    protected void modifyEssay(Essay question) {
    }

    protected void modifyTrueFalse(TrueFalse question) {
    }

    public void modify() {
        //loop over questions
        //modify prompts + choices for MC

    }


    public void take() {
    }


    public void tabulate() {
    }

    public void grade() {
        //foreach question, compute grade
    }
}






