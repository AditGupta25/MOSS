import java.util.Scanner;

public class Input {
    private static Input ourInstance = new Input();

    public static Input getInstance() {
        return ourInstance;
    }

    private Input() {
    }

    public String consoleRead() {
        Scanner scanner = new Scanner(System. in);
        return scanner.nextLine();
    }

}
