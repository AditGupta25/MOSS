import java.io.Serializable;

public class StringResponse extends QuestionResponse implements Serializable {

    private static final long serialVersionUID = 47264L;

    public StringResponse(String val) {
        this.value = val;
    }

    public boolean equals(String r){
        return value.equals(r);
    };

    public String toString() {
        return value;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    private String value;

}


