import java.io.*;
import java.util.ArrayList;

public class TestFileManager extends FileIOManager {

    private final String TEST_FILE_PREFIX = "test-";
    private final String DIRECTORY = System.getProperty("user.dir") + File.separator + "tests";


    public Test loadTest(String name) {
        String fileName = DIRECTORY + File.separator + TEST_FILE_PREFIX + name.replace(' ', '.');
        Test t = null;
        ObjectInputStream iStream = null;
        try {
            FileInputStream file = new FileInputStream(fileName);
            ObjectInputStream in = new ObjectInputStream(file);

            t = (Test)in.readObject();

            in.close();
            file.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return t;
    };

    public void saveTest(Test t) {
        String fileName = DIRECTORY + File.separator + TEST_FILE_PREFIX + t.getTitle().replace(' ', '.');
        try {
            FileOutputStream fileOut = new FileOutputStream(fileName);
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            out.writeObject(t);
            out.close();
            fileOut.close();
        } catch (Exception e) {

        }

    }

    public boolean testExists(String s) {
        ArrayList<String> currentTestNames = getCurrentTestNames();
        for(int i = 0; i < currentTestNames.size(); i++) {
            currentTestNames.set(i, currentTestNames.get(i).toLowerCase());
        }
        return currentTestNames.contains(s.toLowerCase());
    }

    public ArrayList<String> getCurrentTestNames() {
        File[] files = new File(DIRECTORY).listFiles();
        ArrayList<String> testNames = new ArrayList<>();
        for (File file : files) {
            if (file.getName().startsWith(TEST_FILE_PREFIX)) {
                String testName = file.getName().substring(TEST_FILE_PREFIX.length());
                testNames.add(testName.replace('.', ' '));
            }
        }
        return testNames;
    }

}



