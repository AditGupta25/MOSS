import java.io.Serializable;
import java.util.ArrayList;

public class IntListResponse extends QuestionResponse implements Serializable {

    private static final long serialVersionUID = 702L;

    public IntListResponse(ArrayList<Integer> value) {
        this.value = value;
    }

    public boolean equals(String r){
        boolean matching = true;
        String [] items = r.split(" ");
        int count = 0;
        for (Integer i: value) {
            matching = Integer.parseInt(items[count]) == i;
            if(!matching) {
                return matching;
            }
        }
        return matching;

    };

   public String toString() {
       StringBuilder result = new StringBuilder();
       for (Integer i: value) {
           result.append(i.toString() + " ");
       }
       return result.toString().trim();
   }

    public ArrayList<Integer> getValue() {
        return value;
    }

    private ArrayList<Integer> value;

}
