import java.io.*;
import java.util.ArrayList;

public class FileIOManager {

    public FileIOManager() {};

//    public ObjectInputStream readData(String fileName) {
//        FileInputStream fileIn = null;
//        ObjectInputStream in = null;
//        try {
//             fileIn = new FileInputStream(fileName);
//             in = new ObjectInputStream(fileIn);
//             fileIn.close();
//        }
//        catch (Exception e) {
//
//         }
//        return in;
//    };


    public void saveResponse(SurveyResponse surveyResponse) {}

    public SurveyResponse getResponse(String fileName, int i) {
        return new SurveyResponse();
    }

}
