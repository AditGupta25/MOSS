import java.io.Serializable;

public abstract class QuestionResponse implements Serializable {

    private static final long serialVersionUID = 8428L;


    public QuestionResponse() {}

    public abstract boolean equals(String r);

    public abstract String toString();

    private String displayVal;

    public String getDisplayVal() {
        return displayVal;
    }

    public void setDisplayVal(String displayVal) {
        this.displayVal = displayVal;
    }
}
