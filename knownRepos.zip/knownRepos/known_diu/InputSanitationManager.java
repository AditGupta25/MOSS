public class InputSanitationManager {

    public static IO io = IO.getInstance();
    public static boolean checkString(String input) {return true;}

    public static String getTitle() {
        String response = io.prompt();
        boolean isValid = !response.contains(".") && response.length() > 0;
        while (!isValid) {
            io.show("Titles must be at least 1 character and cannot include '.' characters. Please enter another response.");
            response = io.prompt();
            isValid = !response.contains(".") && response.length() > 0;
        }
        return response;
    }

    public static boolean checkInt(String input, int min, int max) {
        try {
            int value = Integer.parseInt(input);
            return value >= min && value <= max;
        } catch (Exception e) {
            return false;
        }
    }

    public static String getCharLimitedString(int charLimit) {
        String response = io.prompt();
        boolean isValid = response.length() > 0 && response.length() < charLimit;
        while (!isValid) {
            io.show("Value invalid or exceeds character limit. Please enter a text value less " +
                    "than " + charLimit + " characters.");
            response = io.prompt();
            isValid = response.length() > 0 && response.length() < charLimit;
        }
        return response;
    }

    public static int getIntValue(int min, int max) {
        String response = io.prompt();
        boolean isValid = checkInt(response, min, max);
        while (!isValid) {
            io.show("Value inputted not recognized or out of bounds. " +
                    "Please enter a number between " + min + " and " + max + ".");
            response = io.prompt();
            isValid = checkInt(response, min, max);
        }
        return Integer.parseInt(response);
    }


    public static boolean getTrueFalse() {
        String response = io.prompt();
        boolean isValid = response.toLowerCase().equals("t") || response.toLowerCase().equals("f");
        while (!isValid) {
            io.show("Value not recognized. Please enter T for True or F for False");
            response = io.prompt();
            isValid = response.toLowerCase().equals("t") || response.toLowerCase().equals("f");
        }
        boolean result = response.toLowerCase().equals('t');
        return result;
    }

    public static Character getMatchingResponse(int intLimit) {
        final int ASCII_OFFSET = 64;
        char charLimit = (char) (intLimit + ASCII_OFFSET);
        String response = getString();
        Character charValue = response.charAt(0);
        boolean isValid =  response.length() == 1 && Character.isLetter(charValue) && charValue <=  charLimit;
        while (!isValid) {
            io.show("Value not valid. Please enter a character between " + (char) (ASCII_OFFSET + 1) +
                    " and " + charLimit);
            response = io.prompt();
            charValue = response.charAt(0);
            isValid = response.length() == 1 && Character.isLetter(charValue) && charValue <=  charLimit;
        }
        return charValue;
    }

    public static String getString() {
        String response = io.prompt();
        boolean isValid = response.length() > 0;
        while (!isValid) {
            io.show("No input detected. Please enter a text value.");
            response = io.prompt();
            isValid = response.length() > 0;
        }
        return response;
    }
}
