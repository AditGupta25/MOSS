import java.io.Serializable;

public class BooleanResponse extends QuestionResponse implements Serializable {

    private static final long serialVersionUID = 701L;

    public BooleanResponse(boolean val) {
        this.value = val;
    }

    public boolean equals(String s){
        String strVal = this.toString();
        return strVal.toLowerCase().equals(s.toLowerCase());
    };

    public String toString() {
       return Boolean.toString(this.value);
    }

    public boolean getValue() {
        return value;
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    private boolean value;
}
