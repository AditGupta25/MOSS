import java.util.ArrayList;

public class SurveyManager extends DisplayManager {

    public SurveyManager() {};
    public SurveyManager(String surveyName) {};
    private static SurveyFileManager fileManager = new SurveyFileManager();
    private Survey survey;

    private boolean isLoaded() {
        return this.survey != null;
    }

    public boolean showMainMenu() {
        ArrayList<String> surveyMenuItems = new ArrayList<>();
        surveyMenuItems.add("Create a new Survey");
        surveyMenuItems.add("Display a Survey");
        surveyMenuItems.add("Load a Survey");
        surveyMenuItems.add("Save a Survey");
        surveyMenuItems.add("Go Back to first menu");
        surveyMenuItems.add("Quit");
        int response = -1;
        boolean done = false;
        boolean quitFlag = false;
        while (!done) {
            for (int i = 1; i <= surveyMenuItems.size(); i++) {
                io.show((i) + ". " + surveyMenuItems.get(i - 1));
            }
            response = InputSanitationManager.getIntValue(1, surveyMenuItems.size());
            switch (response) {
                case 1:
                    create();
                    break;
                case 2:
                    display();
                    break;
                case 3:
                    load();
                    break;
                case 4:
                    save();
                    break;
                case 5:
                    done = true;
                    break;
                case 6:
                    done = true;
                    quitFlag = true;
                    break;
            }
        }
        return quitFlag;
    }
    public void load() {
        ArrayList<String> surveys = fileManager.getCurrentSurveyNames();
        if(surveys.size() > 0) {
            io.show("Select a survey to load.");
            for (int i = 0; i < surveys.size(); i++) {
                io.show(i + 1 + ") " + surveys.get(i));
            }
            int response = InputSanitationManager.getIntValue(1, surveys.size());

            String selection = surveys.get(response - 1);
            this.survey = fileManager.loadSurvey(selection);
            io.show("Loaded survey: " + selection);
        }
        else {
            io.show("No surveys to load.");
        }
    };

    public void display() {
        if(isLoaded()) {
            int questionNum = 0;
            for (Question question : survey.getQuestions()) {
                questionNum++;
                io.show(questionNum + ") " + question.toString() + '\n');
            }
        }
        else {
            io.show("No survey currently loaded. Please load a survey before trying to display it.");
        }
    };

    public void save() {
        if (isLoaded()) {
            fileManager.saveSurvey(this.survey);
            io.show("Saved survey: " + this.survey.getTitle());
        } else {
            io.show("No survey to save. Please load or create a survey before trying to save it.");
        }
    };


    public void create() {
        try {
            io.show("Enter a name for the new survey.");
            String title = InputSanitationManager.getTitle();
            boolean surveyExists = fileManager.surveyExists(title);
            while (surveyExists) {
                io.show("Survey with name: " + title + " already exists. Please enter another name");
                title = InputSanitationManager.getTitle();
                surveyExists = fileManager.surveyExists(title);
            }
            ArrayList<Question> questions = createQuestionsMenu();
            this.survey = new Survey(title, questions);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    //TODO: Below methods are for HW3
    public void modify() {
        //TODO
        //need logic for question types
        //change correct answer
    };

    public void take() {
        //TODO
        //return questions, offer prompt for each question type
    };

    public void tabulate() {
        //TODO
        //add tabulate functions in methods
    }
}
