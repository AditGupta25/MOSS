/**
 * Created by elee on 4/17/2017.
 */
public class Exit {
    public static void Exit()
    {
        System.exit(0);
    }
}
