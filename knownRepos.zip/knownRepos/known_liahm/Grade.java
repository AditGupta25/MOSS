/**
 * Created by elee on 4/17/2017.
 */
public class Grade {
    public static void TabulateSurvey() //HW3
    {
        System.out.println("Not ready until Homework 3");
        SurveyC.SurveyC();
    }

    public static void GradeTest() //HW3
    {
        System.out.println("Not ready until Homework 3");
        //choose file to Grade
        //give score
        //save score in another file
        //not sure how scoring works for now
        Test.Test();
    }

    public static void TabulateTest()
    {

    }
}
