/**
 * Created by elee on 4/17/2017.
 */
public class Take {
    public static void TakeSurvey() //HW3
    {
        System.out.println("Not ready until Homework 3");
        SurveyC.SurveyC();
    }

    public static void TakeTest() //HW3
    {
        System.out.println("Not ready until Homework 3");
        //Open selected test file
        //print the test name
        //print first question of the test.
        //wait for users response.
        //check if answer is the same. if Yes, add +1, if no nothing.
        //Loop it until eof
        //Give score that should be #questions / correct - or just don't since we have a gradetest, which should be only for essay
        Test.Test();

    }
}
