package SurveyTest;

import java.util.Vector;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Ranking extends Question implements java.io.Serializable {

	private static final long serialVersionUID = 1L;

	// Variables
	protected int numberOfChoices;
	protected Vector<String> answer = new Vector<String>();
	protected Vector<String> rankVector = new Vector<String>();
	
	// Constructors
	public Ranking() {}
	
	public Ranking(String question) {
		this.question = question;
	}
	
	public Ranking(String question, int numberOfChoices) {
		this.question = question;
		this.numberOfChoices = numberOfChoices;
	}
	
	public Ranking(String question, int numberOfChoices, Vector<String> answer) {
		this.question = question;
		this.numberOfChoices = numberOfChoices;
		this.answer = answer;
	}
	
	// Methods
	public void setAnswer() throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please enter your rank order, place #" + (answer.size() + 1) + ":");
		String rank = reader.readLine();
		answer.add(rank);
	}
	
	public Vector<String> getAnswer() {
		return answer;
	}
	
	public void setNumberOfChoices(int numberOfChoices) {
		this.numberOfChoices = numberOfChoices;
	}
	
	public int getNumberOfChoices() {
		return numberOfChoices;
	}
	
	public void addChoice() throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please enter choice #" + (rankVector.size() + 1) + ":");
		String choice = reader.readLine();
		rankVector.add(choice);
	}
	
	public void displayChoices() {
		for (int i = 0; i < rankVector.size(); i++)
			System.out.println("(" + (i + 1) + ")" + rankVector.get(i));
	}
	
	public void display() {
		System.out.println(question);
		for (int i = 0; i < rankVector.size(); i++)
			System.out.println("(" + (i + 1) + ")" + rankVector.get(i));
	}
	
	public void displayTest() {
		System.out.println(question);
		for (int i = 0; i < rankVector.size(); i++)
			System.out.println("(" + (i + 1) + ")" + rankVector.get(i));
		System.out.print("The correct answer is: ");
		for (int i = 0; i < answer.size(); i++)
			System.out.print("(" + (answer.get(i)) + ")" + rankVector.get(Integer.parseInt(answer.get(i))-1) + " ");
		System.out.println("");
	}
	
}
