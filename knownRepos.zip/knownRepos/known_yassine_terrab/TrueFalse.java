package SurveyTest;

public class TrueFalse extends Question implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	// Variables
	protected int answer;
	
	// Constructors
	public TrueFalse() {}
	
	public TrueFalse(String question) {
		this.question = question;
	}
	
	public TrueFalse(String question, int answer) {
		this.question = question;
		this.answer = answer;
	}
	
	// Methods
	public void setAnswer(int answer) {
		this.answer = answer;
	}
	
	public String getAnswer() {
		if (answer == 1)
			return "(1)True";
		else
			return "(2)False";
	}
	
	public void display() {
		System.out.println(question);
		System.out.println("(1)True");
		System.out.println("(2)False");
	}
	
	public void displayTest() {
		System.out.println(question);
		System.out.println("(1)True");
		System.out.println("(2)False");
		if (answer == 1)
			System.out.println("The correct answer is: " + "(1)True");
		else
			System.out.println("The correct answer is: " + "(2)False");
	}

}
