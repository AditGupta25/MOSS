package SurveyTest;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Test extends Survey implements java.io.Serializable{
	
	private static final long serialVersionUID = 1L;

	// Constructors
	public Test() {
		name = "Untitled Test";
	}
	
	public Test(String name) {
		this.name = name;
	}
	
	//Methods
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void clear() {
		name = "Untitled Test";
		questionVector.clear();
	}
	
	public void addQuestion() throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What question type would you like to create?");
		System.out.println("	(1)True/False");
		System.out.println("	(2)Multiple Choice");
		System.out.println("	(3)Short Answer");
		System.out.println("	(4)Essay");
		System.out.println("	(5)Rank Choice");	
		System.out.println("	(6)Matching");
		int j = Integer.parseInt(reader.readLine());
		
		String input;
		switch (j) {
			// (1)True/False
			case 1:
				System.out.println("Please enter your True/False question:");
				input = reader.readLine();
				TrueFalse trueFalseObj = new TrueFalse(input);
				System.out.println("Please enter the number of the answer to your question: (1 for True or 2 for False)");
				j = Integer.parseInt(reader.readLine());
				trueFalseObj.setAnswer(j);
				questionVector.add(trueFalseObj);
				break;
				
			// (2)Multiple Choice
			case 2:
				System.out.println("Please enter your Multiple Choice question:");
				input = reader.readLine();
				MultipleChoice multipleChoiceObj = new MultipleChoice(input);
				System.out.println("Please enter the desired number of choices:");
				j = Integer.parseInt(reader.readLine());
				for(int i = 0; i < j; i++)
					multipleChoiceObj.addChoice();
				System.out.println("Please enter the number of the answer to your question: ");
				j = Integer.parseInt(reader.readLine());
				multipleChoiceObj.setAnswer(j);
				questionVector.add(multipleChoiceObj);
				break;
		
			// (3)Short Answer
			case 3:
				System.out.println("Please enter your Short Answer question:");
				input = reader.readLine();
				ShortAnswer shortAnswerObj = new ShortAnswer(input);
				System.out.println("Please enter your answer to the question:");
				input = reader.readLine();
				shortAnswerObj.setAnswer(input);
				questionVector.add(shortAnswerObj);
				break;
				
			// (4)Essay
			case 4:
				System.out.println("Enter your Essay question: ");
				input = reader.readLine();
				Essay essayObj = new Essay(input);
				questionVector.add(essayObj);
				break;
				
			// (5)Rank Choice
			case 5:
				System.out.println("Please enter your Ranking question:");
				input = reader.readLine();
				Ranking rankingObj = new Ranking(input);
				System.out.println("Please enter the desired number of choices:");
				j = Integer.parseInt(reader.readLine());
				for(int i = 0; i < j; i++)
					rankingObj.addChoice();
				System.out.println("Your choices are:");
				rankingObj.displayChoices();
				for(int i = 0; i < j; i++)
					rankingObj.setAnswer();
				questionVector.add(rankingObj);
				break;
				
			// (6)Rank Choice
			case 6:
				System.out.println("Please enter your Matching question:");
				input = reader.readLine();
				Matching matchingObj = new Matching(input);
				System.out.println("Please enter the desired number of choices:");
				j = Integer.parseInt(reader.readLine());
				for(int i = 0; i < j; i++)
					matchingObj.addChoice1();
				for(int i = 0; i < j; i++)
					matchingObj.addChoice2();
				System.out.println("Your choices are:");
				matchingObj.displayChoices();
				matchingObj.setAnswer();
				questionVector.add(matchingObj);
				break;

			// Invalid Input
			default:
				System.out.println("Invalid Input");
				break;
		} 
	}
	
	public void display() {
		System.out.println("");
		System.out.println(name);
		System.out.println("");
		for (int i = 0; i < questionVector.size(); i++) {
			System.out.println((i + 1) + ".");
			questionVector.get(i).displayTest();
			System.out.println("");
		}
	}
	
}
