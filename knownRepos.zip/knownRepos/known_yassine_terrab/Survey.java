package SurveyTest;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectOutputStream;
import java.util.Vector;

public class Survey implements java.io.Serializable{

	private static final long serialVersionUID = 1L;
	
	// Variables
	protected String name;
	protected Vector<Question> questionVector = new Vector<Question>();
	
	// Constructors
	public Survey() {
		name = "Untitled Survey";
	}
	
	public Survey(String name) {
		this.name = name;
	}
	
	//Methods
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void clear() {
		name = "Untitled Survey";
		questionVector.clear();
	}
	
	public void addQuestion() throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("What question type would you like to create?");
		System.out.println("	(1)True/False");
		System.out.println("	(2)Multiple Choice");
		System.out.println("	(3)Short Answer");
		System.out.println("	(4)Essay");
		System.out.println("	(5)Rank Choice");	
		System.out.println("	(6)Matching");
		int j = Integer.parseInt(reader.readLine());
		
		String input;
		switch (j) {
			// (1)True/False
			case 1:
				System.out.println("Please enter your True/False question:");
				input = reader.readLine();
				TrueFalse trueFalseObj = new TrueFalse(input);
				questionVector.add(trueFalseObj);
				break;
				
			// (2)Multiple Choice
			case 2:
				System.out.println("Please enter your Multiple Choice question:");
				input = reader.readLine();
				MultipleChoice multipleChoiceObj = new MultipleChoice(input);
				System.out.println("Please enter the desired number of choices:");
				j = Integer.parseInt(reader.readLine());
				for(int i = 0; i < j; i++)
					multipleChoiceObj.addChoice();
				questionVector.add(multipleChoiceObj);
				break;
		
			// (3)Short Answer
			case 3:
				System.out.println("Please enter your Short Answer question:");
				input = reader.readLine();
				ShortAnswer shortAnswerObj = new ShortAnswer(input);
				questionVector.add(shortAnswerObj);
				break;
				
			// (4)Essay
			case 4:
				System.out.println("Enter your Essay question: ");
				input = reader.readLine();
				Essay essayObj = new Essay(input);
				questionVector.add(essayObj);
				break;
				
			// (5)Rank Choice
			case 5:
				System.out.println("Please enter your Ranking question:");
				input = reader.readLine();
				Ranking rankingObj = new Ranking(input);
				System.out.println("Please enter the desired number of choices:");
				j = Integer.parseInt(reader.readLine());
				for(int i = 0; i < j; i++)
					rankingObj.addChoice();
				questionVector.add(rankingObj);
				break;
				
			// (6)Rank Choice
			case 6:
				System.out.println("Please enter your Matching question:");
				input = reader.readLine();
				Matching matchingObj = new Matching(input);
				System.out.println("Please enter the desired number of choices:");
				j = Integer.parseInt(reader.readLine());
				for(int i = 0; i < j; i++)
					matchingObj.addChoice1();
				for(int i = 0; i < j; i++)
					matchingObj.addChoice2();
				questionVector.add(matchingObj);
				break;

			// Invalid Input
			default:
				System.out.println("Invalid Input");
				break;
		} 
	}
	
	public void display() {
		System.out.println("");
		System.out.println(name);
		System.out.println("");
		for (int i = 0; i < questionVector.size(); i++) {
			System.out.println((i + 1) + ".");
			questionVector.get(i).display();
			System.out.println("");
		}
	}
	
	public void save(Survey survey, String dir) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please enter a name for the file: (no file type needed)");
		String fileName = reader.readLine();
		try {
			FileOutputStream fileOut =	new FileOutputStream(dir + fileName + ".ser");
			ObjectOutputStream out = new ObjectOutputStream(fileOut);
			out.writeObject(survey);
			out.close();
			fileOut.close();
			System.out.printf("Saved successfully as " + fileName + ".ser");
			System.out.printf("");
		} catch(IOException i1) {
			System.out.println("Error saving file...");
		}
	}
	
}
