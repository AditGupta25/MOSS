package SurveyTest;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.util.Vector;

public class Main {
	
	public static void main(String[]args) throws IOException, ClassNotFoundException{
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		
		// Menu System
		MainMenuLoop: while(true){
			Survey survey = new Survey();
			Test test = new Test();
			System.out.println("Would you like to access Survey or Test?");
			System.out.println("	(1)Survey");
			System.out.println("	(2)Test");
			System.out.println("	(3)Exit");
			int j = Integer.parseInt(reader.readLine());
			
			String input;
			switch (j) {
				// (1)Survey
				case 1:
					SurveyMenuLoop: while(true){
						System.out.println("Please select an option:");
						System.out.println("	(1)Create a new Survey");
						System.out.println("	(2)Display a Survey");
						System.out.println("	(3)Load a Survey");
						System.out.println("	(4)Save the current Survey");
						System.out.println("	(5)Back");
						int x = Integer.parseInt(reader.readLine());
						
						switch (x) {
							// (1)Create a new Survey
							case 1:
								survey.clear();
								System.out.println("Would you like to name this survey? (y/n)");
								input = reader.readLine();
								if (input.equalsIgnoreCase("y")) {
									System.out.println("Please enter your desired survey name:");
									input = reader.readLine();
									survey.setName(input);
								}
								System.out.println("How many questions would you like to create?");
								x = Integer.parseInt(reader.readLine());
								for(int i = 0; i < x; i++) 
									survey.addQuestion();
								break;
							
							// (2)Display a Survey
							case 2:
								survey.display();
								break;
								
							// (3)Load a Survey
							case 3:
								System.out.println("Please select a file to load: ");
								Vector<String> fileNames = new Vector<String>();
								File dir = new File("./surveys");
								int count = 1;
								for (File file : dir.listFiles()) {
									System.out.println("(" + count + ")" + file.getName());
									fileNames.add(file.getName());
									count++;
								}
								x = Integer.parseInt(reader.readLine());
								try {
									FileInputStream fileIn = new FileInputStream("./surveys/" + fileNames.get(x-1));
									ObjectInputStream in = new ObjectInputStream(fileIn);
							        survey = (Survey) in.readObject();
							        in.close();
							        fileIn.close();
								} catch(IOException i1) {
									System.out.println("Error loading file...");
								} catch(ClassNotFoundException c) {
									System.out.println("Error loading survey object...");
								}
								break;
								
							// (4)Save the current Survey
							case 4:
								survey.save(survey, "./surveys/");
								break;
								
							// (5)Back
							case 5:
								System.out.println("Going back to previous menu...");
								break SurveyMenuLoop;
								
							// Invalid Input
							default:
								System.out.println("Invalid Input");
								break;
						}
					}
					break;
					
				// (2)Test
				case 2:
					TestMenuLoop: while(true){
						System.out.println("Please select an option:");
						System.out.println("	(1)Create a new Test");
						System.out.println("	(2)Display a Test");
						System.out.println("	(3)Load a Test");
						System.out.println("	(4)Save the current Test");
						System.out.println("	(5)Back");
						int x = Integer.parseInt(reader.readLine());
						
						switch (x) {
							// (1)Create a new Test
							case 1:
								test.clear();
								System.out.println("Would you like to name this test? (y/n)");
								input = reader.readLine();
								if (input.equalsIgnoreCase("y")) {
									System.out.println("Please enter your desired test name:");
									input = reader.readLine();
									test.setName(input);
								}
								System.out.println("How many questions would you like to create?");
								x = Integer.parseInt(reader.readLine());
								for(int i = 0; i < x; i++) 
									test.addQuestion();
								break;
							
							// (2)Display a Test
							case 2:
								test.display();
								break;
								
							// (3)Load a Test
							case 3:
								System.out.println("Please select a file to load: ");
								Vector<String> fileNames = new Vector<String>();
								File dir = new File("./tests");
								int count = 1;
								for (File file : dir.listFiles()) {
									System.out.println("(" + count + ")" + file.getName());
									fileNames.add(file.getName());
									count++;
								}
								x = Integer.parseInt(reader.readLine());
								try {
									FileInputStream fileIn = new FileInputStream("./tests/" + fileNames.get(x-1));
									ObjectInputStream in = new ObjectInputStream(fileIn);
							        test = (Test) in.readObject();
							        in.close();
							        fileIn.close();
								} catch(IOException i1) {
									System.out.println("Error loading file...");
								} catch(ClassNotFoundException c) {
									System.out.println("Error loading survey object...");
								}
								break;
								
							// (4)Save the current Test
							case 4:
								survey.save(test, "./tests/");
								break;
								
							// (5)Back
							case 5:
								System.out.println("Going back to previous menu...");
								break TestMenuLoop;
								
							// Invalid Input
							default:
								System.out.println("Invalid Input");
								break;
						}
					}
					break;
				
				// (3)Exit
				case 3:
					System.out.println("Exiting Program...");
					break MainMenuLoop;
			}
		}
	}
				
}
