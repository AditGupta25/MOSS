package SurveyTest;

import java.util.Vector;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Matching extends Ranking implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	// Variables
	protected Vector<String> matchVector = new Vector<String>();
	
	// Constructors
	public Matching() {}
	
	public Matching(String question) {
		this.question = question;
	}
	
	public Matching(String question, int numberOfChoices) {
		this.question = question;
		this.numberOfChoices = numberOfChoices;
	}
	
	public Matching(String question, int numberOfChoices, Vector<String> answer) {
		this.question = question;
		this.numberOfChoices = numberOfChoices;
		this.answer = answer;
	}
	
	// Methods
	public void setAnswer() throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		for (int i = 0; i < rankVector.size(); i++) {
			System.out.println("Please enter the match for (" + (i + 1) + ")" + rankVector.get(i) + ":");
			String match = reader.readLine();
			answer.add(match);
		}
	}
	
	public Vector<String> getAnswer() {
		return answer;
	}
	
	public void setNumberOfChoices(int numberOfChoices) {
		this.numberOfChoices = numberOfChoices;
	}
	
	public int getNumberOfChoices() {
		return numberOfChoices;
	}
	
	public void addChoice1() throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("First Column. Please enter choice #" + (rankVector.size() + 1) + ":");
		String choice = reader.readLine();
		rankVector.add(choice);
	}
	
	public void addChoice2() throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Second Column. Please enter choice #" + (matchVector.size() + 1) + ":");
		String choice = reader.readLine();
		matchVector.add(choice);
	}
	
	public void displayChoices() {
		System.out.printf("%-30s %-30s\n", "Column 1", "Column 2");
		for (int i = 0; i < rankVector.size(); i++)
			System.out.printf("%-30s %-30s\n", "(" + (i + 1) + ")" + rankVector.get(i), "(" + (i + 1) + ")" + matchVector.get(i));
	}
	
	public void display() {
		System.out.println(question);
		System.out.printf("%-30s %-30s\n", "Column 1", "Column 2");
		for (int i = 0; i < rankVector.size(); i++)
			System.out.printf("%-30s %-30s\n", "(" + (i + 1) + ")" + rankVector.get(i), "(" + (i + 1) + ")" + matchVector.get(i));
	}
	
	public void displayTest() {
		System.out.println(question);
		System.out.printf("%-30s %-30s\n", "Column 1", "Column 2");
		for (int i = 0; i < rankVector.size(); i++)
			System.out.printf("%-30s %-30s\n", "(" + (i + 1) + ")" + rankVector.get(i), "(" + (i + 1) + ")" + matchVector.get(i));
		System.out.print("The correct answer is: ");
		for (int i = 0; i < answer.size(); i++)
			System.out.print("(" + (i + 1) + ")" + rankVector.get(i) + "->(" + (answer.get(i)) + ")" + matchVector.get(Integer.parseInt(answer.get(i))-1) + " ");
		System.out.println("");
	}

}
