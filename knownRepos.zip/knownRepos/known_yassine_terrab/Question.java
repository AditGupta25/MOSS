package SurveyTest;

public class Question implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	// Variables
	protected String question;
	
	// Constructors
	public Question() {}
	
	// Methods	
	public void setQuestion(String question) {
		this.question = question;
	}
	
	public String getQuestion() {
		return question;
	}
	
	public void display() {}
	
	public void displayTest() {}
	
}
