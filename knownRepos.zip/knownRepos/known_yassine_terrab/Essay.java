package SurveyTest;

public class Essay extends Question implements java.io.Serializable {

	private static final long serialVersionUID = 1L;
	
	// Variables
	protected String response;
	
	// Constructors
	public Essay() {}
	
	public Essay(String question) {
		this.question = question;
	}
	
	// Methods
	public void setResponse(String response) {
		this.response = response;
	}
	
	public String getResponse() {
		return response;
	}
	
	public void display() {
		System.out.println(question);
		System.out.println("");
	}
	
	public void displayTest() {
		System.out.println(question);
		System.out.println("No correct answer. Essays must be graded by a human.");
	}
}
