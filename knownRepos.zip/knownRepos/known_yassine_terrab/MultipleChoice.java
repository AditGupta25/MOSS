package SurveyTest;

import java.util.Vector;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class MultipleChoice extends TrueFalse implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	// Variables
	protected int numberOfChoices;
	protected Vector<String> choiceVector = new Vector<String>();
	
	// Constructors
	public MultipleChoice() {}
	
	public MultipleChoice(String question) {
		this.question = question;
	}
	
	public MultipleChoice(String question, int numberOfChoices) {
		this.question = question;
		this.numberOfChoices = numberOfChoices;
	}
	
	public MultipleChoice(String question, int numberOfChoices, int answer) {
		this.question = question;
		this.numberOfChoices = numberOfChoices;
		this.answer = answer;
	}
	
	// Methods
	public void setAnswer(int answer) {
		this.answer = answer;
	}
	
	public String getAnswer() {
		return "(" + answer + ")" + choiceVector.get(answer-1);
	}
	
	public void setNumberOfChoices(int numberOfChoices) {
		this.numberOfChoices = numberOfChoices;
	}
	
	public int getNumberOfChoices() {
		return numberOfChoices;
	}
	
	public void addChoice () throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("Please enter choice #" + (choiceVector.size() + 1) + ":");
		String choice = reader.readLine();
		choiceVector.add(choice);
	}
	
	public void modifyChoice (int choiceNumber, String choice) {
		choiceVector.set(choiceNumber-1, choice);
	}
	
	public void display() {
		System.out.println(question);
		for (int i = 0; i < choiceVector.size(); i++)
			System.out.println("(" + (i + 1) + ")" + choiceVector.get(i));
	}
	
	public void displayTest() {
		System.out.println(question);
		for (int i = 0; i < choiceVector.size(); i++)
			System.out.println("(" + (i + 1) + ")" + choiceVector.get(i));
		System.out.println("The correct answer is: (" + answer + ")" + choiceVector.get(answer-1));
	}
	
}
