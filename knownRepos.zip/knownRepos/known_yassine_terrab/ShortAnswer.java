package SurveyTest;

public class ShortAnswer extends Essay implements java.io.Serializable {
	
	private static final long serialVersionUID = 1L;
	
	// Variables
	protected String answer;
	
	// Constructors
	public ShortAnswer() {}
	
	public ShortAnswer(String question) {
		this.question = question;
	}
	
	public ShortAnswer(String question, String answer) {
		this.question = question;
		this.answer = answer;
	}
	
	// Methods
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	
	public String getAnswer() {
		return answer;
	}
	
	public void displayTest() {
		System.out.println(question);
		System.out.println("The correct answer is: " + answer);
	}
	
}
