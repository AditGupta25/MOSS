//Russell Wiley
//CS 350
//Professor Salvage
package DataSystem;

//Display inputed Strings to console
public class ConsoleIO extends InputOutput
{
	private static final long serialVersionUID = 2799701966978977127L;

	public void display(String stream)
	{
		System.out.print(stream);
	}
}
